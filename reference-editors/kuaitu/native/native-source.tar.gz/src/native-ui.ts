import { inject } from 'vue';
import type { NativeController } from './native-controller';
export function useNativeUi() {
  const host = inject<NativeController>('creatorosHost');
  if (!host) throw Error('图片工作台缺少宿主');
  const message = (value: string | {content?: string}, kind = 'info') => host.notice(typeof value === 'string' ? value : value.content || '', kind);
  return {
    Message: {success: (v: any) => message(v), error: (v: any) => message(v, 'error'), warning: (v: any) => message(v)},
    Modal: {confirm: (settings: any) => void host.confirm(settings.title || '确认操作', settings.content || '确认继续？').then(yes => {
      if (yes) return settings.onOk?.(); else return settings.onCancel?.();
    }).catch(e => host.error(e))},
    Spin: {show: () => host.spin(true), hide: () => host.spin(false)},
    ImagePreview: {show: ({previewList}: {previewList: string[]}) => host.showPreview(previewList)},
  };
}
