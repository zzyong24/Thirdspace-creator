import { createRouter, createWebHashHistory } from 'vue-router';
import routes from './routes';
import { referenceSession } from '@/creatoros-bridge';
if (referenceSession && !location.hash.startsWith('#/')) {
  history.replaceState(
    null,
    '',
    `${location.pathname}${location.search}#/?session=${encodeURIComponent(referenceSession)}`
  );
}

export default createRouter({
  routes,
  history: createWebHashHistory(),
  scrollBehavior() {
    return { top: 0 };
  },
});
