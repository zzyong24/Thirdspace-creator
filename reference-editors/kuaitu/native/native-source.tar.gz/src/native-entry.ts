import {createApp, markRaw} from 'vue';
import Home from './views/home/index.vue';
import ViewUiPlus, {Modal as VendorModal} from 'view-ui-plus';
import {createI18n} from 'vue-i18n';
import zh from 'view-ui-plus/dist/locale/zh-CN';
import CN from './language/zh.json';
import {VueMasonryPlugin} from 'vue-masonry';
import VueLazyLoad from 'vue3-lazyload';
import {NativeController} from './native-controller';
import {fabric} from 'fabric';
import type {NativeOptions} from './native-types';
import 'view-ui-plus/dist/styles/viewuiplus.css';
import './styles/index.less';
import './native-theme.css';

const activeOwners=new Set<NativeController>();
export async function mount(container:HTMLElement,options:NativeOptions){
  if(!(container instanceof HTMLElement)||options.signal.aborted)throw Error('图片工作台挂载已取消');
  const host=markRaw(new NativeController(container,options));
  activeOwners.add(host);
  const app=createApp(Home,{nativeHost:host});
  app.config.errorHandler=error=>host.fail(error);
  app.use(createI18n({legacy:false,allowComposition:true,globalInjection:true,locale:'zh',messages:{zh:Object.assign({},CN,zh)}}));
  app.use(VueMasonryPlugin);app.use(VueLazyLoad,{});app.use(ViewUiPlus,{transfer:false});
  const original:any=VendorModal;
  const NativeModal={...original,inject:['creatorosHost'],methods:{...original.methods,
    addScrollEffect(){},removeScrollEffect(){},
    EscClose(this:any,event:KeyboardEvent){if(!this.creatorosHost.disposed&&this.creatorosHost.active())original.methods.EscClose.call(this,event);},
  },beforeUnmount(this:any){clearTimeout(this.timer);original.beforeUnmount.call(this);}};
  app.component('Modal',NativeModal);app.component('iModal',NativeModal);
  let closed=false;
  const dispose=async()=>{if(closed)return;closed=true;options.signal.removeEventListener('abort',abort);host.close();app.unmount();container.replaceChildren();activeOwners.delete(host);if(activeOwners.size===0){const shared:any=fabric;const backend=shared.filterBackend;try{backend?.gl?.getExtension?.("WEBGL_lose_context")?.loseContext();}catch{}backend?.dispose?.();if(backend?.resources)backend.resources={};shared.filterBackend=undefined;}};
  const abort=()=>void dispose();
  options.signal.addEventListener('abort',abort,{once:true});
  try{app.mount(container);await host.ready;if(host.disposed||options.signal.aborted)throw Error('图片工作台挂载已取消');
    return {request:(operation:string,payload?:unknown,requestOptions?:{requestId?:string;signal?:AbortSignal})=>host.request(operation,payload,requestOptions),update:(value:Parameters<NativeController['update']>[0])=>host.update(value),dispose};
  }catch(error){await dispose();throw error;}
}
