export interface NativeTheme {
  mode: 'light' | 'dark'; tokens: Record<string, string>;
  fontFamily: string; fontSize: string; density: string;
}
export interface NativeOptions {
  owner: {groupId:string|null;accountId:string|null;projectId:string;outputId:string;sourceVersionId:string};
  theme: NativeTheme; portalContainer: HTMLElement; signal: AbortSignal;
  onChanged: (event?:{kind:'native-context';contextEpoch:number;outputId:string;sceneId:string|null;selectedElements:unknown[];documentChanged:boolean}) => void; onError: (message: string) => void;
  importMedia: (file: File) => Promise<{mediaId: string}>;
}
export const missingPixel = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4//8/AwAI/AL+p5qgoAAAAABJRU5ErkJggg==';
// SEMANTIC_BOUNDARY_ALLOW: exact media references and URL schemes only; no content choice.
export function walkImages(value: any, visit: (image: any) => void) {
  if (!value || typeof value !== 'object') return;
  if (value.type === 'image') visit(value);
  if (Array.isArray(value.objects)) value.objects.forEach((item: any) => walkImages(item, visit));
  for (const key of ['backgroundImage', 'overlayImage', 'clipPath']) if (value[key]) walkImages(value[key], visit);
}
export function walkObjects(value:any, visit:(object:any)=>void) {
  if(!value||typeof value!=='object')return;
  if(typeof value.type==='string')visit(value);
  if(Array.isArray(value.objects))value.objects.forEach((object:any)=>walkObjects(object,visit));
  for(const key of ['backgroundImage','overlayImage','clipPath'])if(value[key])walkObjects(value[key],visit);
}
export function restoreMissing(document: any) {
  const clone = JSON.parse(JSON.stringify(document));
  walkImages(clone,item=>{
    if(typeof item.data?.creatorosMissingSource==='string') {
      // Only host-verified exact references retain their real identity; unknown sources stay safe metadata.
      const id=item.data.creatorosMediaId;
      const known=item.data.creatorosMissingKnownRef===true && typeof id==='string' && item.data.creatorosMissingSource===`creatoros-media://${id}`;
      item.src=known?item.data.creatorosMissingSource:missingPixel;
      if(id&&!known){item.data.creatorosMissingMediaId=id;delete item.data.creatorosMediaId;}
    }
  });
  const restorePaint=(item:any)=>{
    if(!Array.isArray(item.data?.creatorosMissingPatterns))return;
    for(const missing of item.data.creatorosMissingPatterns){
      // SEMANTIC_BOUNDARY_ALLOW: metadata may only restore own Fabric paint slots; never prototype keys.
      if(!missing || !['fill','stroke','background','overlay'].includes(missing.key) || !Object.prototype.hasOwnProperty.call(item,missing.key))continue;
      const paint=item[missing.key];if(paint&&typeof paint==='object')paint.source=missing.source;
    }
    const {creatorosMissingPatterns,creatorosPatternDataPresent,...data}=item.data;
    if(!creatorosPatternDataPresent && Object.keys(data).length===0)delete item.data;else item.data=data;
  };
  restorePaint(clone);walkObjects(clone,restorePaint);
  return clone;
}
export function deepActive(root: Document | ShadowRoot): Element | null {
  let active = root.activeElement;
  while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
  return active;
}
export function isTextTarget(target: EventTarget | null) {
  return target instanceof Element && !!target.closest('input,textarea,select,[contenteditable="true"]');
}

export function nativeOwnerKey(owner: NativeOptions['owner']) { return JSON.stringify([owner.groupId?['group',owner.groupId]:['account',owner.accountId],owner.projectId,owner.outputId,owner.sourceVersionId]); }
