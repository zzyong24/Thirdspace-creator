import type {fabric} from 'fabric';
/** Narrow host port for the real Home-owned upstream Editor; not a replacement document schema. */
export interface NativeEngine {
  readonly fabricCanvas: fabric.Canvas | null;
  getJson(): any;
  loadJSON(document: any, callback?: () => void): Promise<void>;
  getPlugin(name: string): any;
  clear(): void;
  setSize(width: number, height: number): void;
  createImgByElement(element: HTMLImageElement): Promise<fabric.Object>;
  addBaseType(object: fabric.Object, options: {scale: boolean}): void;
  previewDocument(): Promise<{dataUrl: string; document: any}>;
}
