import type {NativeEngine} from './native-engine';
import type { NativeOptions, NativeTheme } from './native-types';
import { deepActive, isTextTarget, missingPixel, restoreMissing, walkImages, walkObjects } from './native-types';

export class NativeController {
  editor?: NativeEngine;
  workspaceEl?: HTMLElement;
  disposed = false; disabled = false; loading = false; locked = false;
  private epoch = 0; private baseline = ''; private timer?: ReturnType<typeof setTimeout>;
  private timers = new Set<ReturnType<typeof setTimeout>>();
  private cleanup = new Set<() => void>(); private jobs = new Set<() => void>(); private urls = new Set<string>();
  private known = new Map<string, string>(); private knownReferences=new Set<string>(); private sequence: Promise<unknown> = Promise.resolve();
  private requests = new Map<string, Promise<any>>(); private title = '图文设计';private currentTheme?:NativeTheme;
  private spinNode?: HTMLElement;
  private readyResolve!: () => void; private readyReject!: (error: unknown) => void;
  readonly ready = new Promise<void>((resolve, reject) => {this.readyResolve = resolve; this.readyReject = reject;});
  private abort = new AbortController();
  constructor(readonly root: HTMLElement, readonly options: NativeOptions) {
    root.tabIndex = 0; root.dataset.creatorosEditor = 'kuaitu';
    const portal=options.portalContainer;portal.dataset.creatorosEditor='kuaitu';portal.style.position='absolute';portal.style.inset='0';portal.style.pointerEvents='none';
    this.updateTheme(options.theme);
    const cancel = () => this.close(); options.signal.addEventListener('abort', cancel, {once: true});
    this.cleanup.add(() => options.signal.removeEventListener('abort', cancel));
    const focus = (e: Event) => { if (!isTextTarget(e.composedPath()[0]) && (e.target as Element)?.closest('.canvas-container')) root.focus({preventScroll: true}); };
    root.addEventListener('pointerdown', focus); this.cleanup.add(() => root.removeEventListener('pointerdown', focus));
    const drag = (e: DragEvent) => {if (e.dataTransfer?.types.includes('Files')) {e.preventDefault();}};
    const drop = (e: DragEvent) => {if (!e.dataTransfer?.files.length) return; e.preventDefault();
      for (const file of Array.from(e.dataTransfer.files)) if (file.type.startsWith('image/')) void this.importFile(file).catch(err => this.error(err));};
    root.addEventListener('dragover', drag); root.addEventListener('drop', drop);
    this.cleanup.add(() => {root.removeEventListener('dragover', drag); root.removeEventListener('drop', drop);});
  }
  get signal() {return this.abort.signal;}
  currentEpoch() {return this.epoch;}
  active() {const node = deepActive(document); return !!node && (this.root.contains(node) || this.options.portalContainer.contains(node));}
  accepts(e: Event) {return !this.disposed && !this.disabled && !this.locked && this.active() && !isTextTarget(e.composedPath()[0]);}
  check(epoch = this.epoch, signal?: AbortSignal) {if (this.disposed || this.signal.aborted || this.options.signal.aborted || signal?.aborted || epoch !== this.epoch) throw Error('已切换作品，原编辑操作停止');}
  attach(editor: NativeEngine, workspaceEl: HTMLElement) {
    this.check(); this.editor = editor; this.workspaceEl = workspaceEl;
    const publish = () => this.publish();
    const canvas = editor.fabricCanvas;
    const events = ['object:added','object:modified','object:removed','text:changed','path:created','after:render'];
    events.forEach(event => canvas?.on(event, publish));
    const setTextarea=(event: any)=>{if(event.target){event.target.hiddenTextareaContainer=this.root;this.themeSelection(event.target);}};
    canvas?.on('object:added',setTextarea);
    this.cleanup.add(()=>canvas?.off('object:added',setTextarea));
    this.cleanup.add(() => events.forEach(event => canvas?.off(event, publish)));
    this.baseline = JSON.stringify(editor.getJson()); this.readyResolve();
  }
  fail(e: unknown) {this.readyReject(e); this.error(e);}
  error(e: unknown) {if (!this.disposed) this.options.onError(e instanceof Error ? e.message : String(e));}
  publish() {
    if (this.disposed || this.loading || this.locked || !this.editor) return;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {if (this.disposed || this.loading || this.locked || !this.editor) return;
      const json = JSON.stringify(restoreMissing(this.editor.getJson()));
      // SEMANTIC_BOUNDARY_ALLOW: exact JSON comparison deduplicates render events only.
      if (json !== this.baseline) {this.baseline = json; this.options.onChanged();}
    }, 180);
  }
  themeSelection(object:any){const color=this.currentTheme?.tokens['--creatoros-brand'];if(color)object.set?.({borderColor:color,cornerStrokeColor:color,cornerColor:color});if(object.getObjects)object.getObjects().forEach((child:any)=>this.themeSelection(child));}
  updateTheme(theme: NativeTheme) {
    this.currentTheme=theme;
    for (const node of [this.root, this.options.portalContainer]) {
      for (const [key,value] of Object.entries(theme.tokens)) if (/^--[a-zA-Z0-9-]+$/.test(key)) node.style.setProperty(key,value);
      node.style.fontFamily = theme.fontFamily; node.style.fontSize = theme.fontSize;
      node.dataset.theme = theme.mode; node.dataset.density = theme.density;node.style.setProperty('--native-control-height',theme.density==='compact'?'28px':'32px');
    }
    if(this.editor?.fabricCanvas){this.editor.fabricCanvas.selectionBorderColor=theme.tokens['--creatoros-brand']||'#6d4aff';this.editor.fabricCanvas.getObjects().forEach(object=>this.themeSelection(object));this.editor.fabricCanvas.requestRenderAll();}
  }
  update(value: {theme?: NativeTheme; disabled?: boolean}) {
    if (this.disposed) return; if (value.theme) this.updateTheme(value.theme);
    if (typeof value.disabled === 'boolean') {this.disabled = value.disabled; this.root.inert = value.disabled; this.options.portalContainer.inert = value.disabled;}
  }
  notice(text: string, kind = 'info') {
    if (this.disposed) return;
    const node = document.createElement('div'); node.className = `native-notice ${kind}`; node.setAttribute('role', kind === 'error' ? 'alert' : 'status'); node.textContent = text;
    this.options.portalContainer.appendChild(node);
    const timer = setTimeout(() => {node.remove(); this.timers.delete(timer);}, 4000); this.timers.add(timer); this.cleanup.add(() => node.remove());
  }
  spin(show: boolean) {this.spinNode?.remove(); this.spinNode = undefined; if (show && !this.disposed) {
    const node = document.createElement('div'); node.className = 'native-notice'; node.textContent = '处理中…'; this.options.portalContainer.appendChild(node); this.spinNode = node;
  }}
  confirm(title: string, content: string): Promise<boolean> {
    if (this.disposed) return Promise.resolve(false);
    return new Promise(resolve => {
      const previous = deepActive(document) as HTMLElement | null;
      const overlay = document.createElement('div'); overlay.className = 'native-modal-shade';
      const dialog = document.createElement('section'); dialog.className = 'native-modal'; dialog.setAttribute('role','alertdialog'); dialog.setAttribute('aria-modal','true');
      const label = document.createElement('h3'); label.textContent = title; label.id = `native-confirm-${crypto.randomUUID()}`; dialog.setAttribute('aria-labelledby', label.id);
      const body = document.createElement('p'); const plain = new DOMParser().parseFromString(content, 'text/html'); body.textContent = plain.body.textContent;
      const actions = document.createElement('div'); const cancel = document.createElement('button'); cancel.textContent = '取消'; const ok = document.createElement('button'); ok.textContent = '确认'; ok.className = 'primary';
      let done = false; const finish = (yes: boolean) => {if (done) return; done = true; overlay.remove(); this.cleanup.delete(close); if (previous?.isConnected && !this.disposed) previous.focus(); resolve(yes);};
      const close = () => finish(false); this.cleanup.add(close);
      cancel.onclick = () => finish(false); ok.onclick = () => finish(true);
      dialog.addEventListener('keydown', e => {if (e.key === 'Escape') {e.stopPropagation(); finish(false);} if(e.key === 'Tab') {e.preventDefault(); (deepActive(document) === cancel ? ok : cancel).focus();}});
      actions.append(cancel,ok); dialog.append(label,body,actions); overlay.append(dialog); this.options.portalContainer.append(overlay); cancel.focus();
    });
  }
  showPreview(list: string[]) {
    if (this.disposed) return;
    const overlay = document.createElement('div'); overlay.className = 'native-modal-shade';
    const box = document.createElement('section'); box.className = 'native-modal native-image-preview';
    const close = document.createElement('button'); close.textContent = '关闭预览'; close.onclick = () => overlay.remove(); box.append(close);
    for (const src of list) if (/^data:image\//.test(src) || this.urls.has(src)) {const image = new Image(); image.src = src; box.append(image);}
    overlay.append(box); this.options.portalContainer.append(overlay); this.cleanup.add(() => overlay.remove()); close.focus();
  }
  private lock() {
    this.locked = true; clearTimeout(this.timer);
    const overlay = document.createElement('div'); overlay.className = 'native-export-lock'; overlay.setAttribute('role','status'); overlay.textContent = '正在处理当前设计…'; this.root.append(overlay);
    const stop = (e: Event) => {if(e.cancelable) e.preventDefault(); e.stopImmediatePropagation();};
    const names = ['keydown','keyup','beforeinput','input','paste','cut','drop','dragstart','pointerdown','pointerup','click','wheel'];
    for (const name of names) {this.root.addEventListener(name,stop,{capture:true,passive:false}); this.options.portalContainer.addEventListener(name,stop,{capture:true,passive:false});}
    const release = () => {for(const name of names){this.root.removeEventListener(name,stop,true);this.options.portalContainer.removeEventListener(name,stop,true);} overlay.remove(); this.locked = false; this.cleanup.delete(release); this.publish();};
    this.cleanup.add(release); return release;
  }
  private advanceEpoch(){this.epoch++;for(const cancel of Array.from(this.jobs))cancel();return this.epoch;}
  private ownedJob<T>(work:Promise<T>,epoch:number,signal?:AbortSignal):Promise<T>{
    return new Promise((resolve,reject)=>{
      let done=false;const signals=Array.from(new Set([this.signal,signal].filter((value):value is AbortSignal=>!!value)));
      const finish=(value:unknown,failed:boolean)=>{if(done)return;done=true;this.jobs.delete(cancel);signals.forEach(current=>current.removeEventListener('abort',cancel));if(failed)reject(value);else resolve(value as T);};
      const cancel=()=>finish(Error('已切换作品，原编辑操作停止'),true);
      this.jobs.add(cancel);signals.forEach(current=>current.addEventListener('abort',cancel,{once:true}));
      work.then(value=>{try{this.check(epoch,signal);finish(value,false);}catch(error){finish(error,true);}},error=>finish(error,true));
      try{this.check(epoch,signal);}catch(error){finish(error,true);}
    });
  }
  private decodeImage(src:string,epoch:number,signal?:AbortSignal):Promise<HTMLImageElement>{
    return new Promise((resolve,reject)=>{
      const image=new Image();let done=false;const signals=Array.from(new Set([this.signal,signal].filter((value):value is AbortSignal=>!!value)));
      const finish=(error?:unknown)=>{if(done)return;done=true;image.onload=null;image.onerror=null;this.jobs.delete(cancel);signals.forEach(current=>current.removeEventListener('abort',cancel));
        if(error){if(typeof image.removeAttribute==='function')image.removeAttribute('src');else image.src='';reject(error);}else resolve(image);};
      const cancel=()=>finish(Error('已切换作品，原编辑操作停止'));
      image.onload=()=>{try{this.check(epoch,signal);finish();}catch(error){finish(error);}};image.onerror=()=>finish(Error('图片加载失败'));
      this.jobs.add(cancel);signals.forEach(current=>current.addEventListener('abort',cancel,{once:true}));
      try{this.check(epoch,signal);image.src=src;}catch(error){finish(error);}
    });
  }
  async readImage(file: File, epoch: number,signal?:AbortSignal) {
    this.check(epoch,signal); if(!file.type.startsWith('image/') || !file.size || file.size > 40*1024*1024) throw Error('请选择 40 MB 以内的图片');
    const answer = await this.ownedJob(this.options.importMedia(file),epoch,signal); this.check(epoch,signal);
    if (!answer || typeof answer.mediaId !== 'string' || !answer.mediaId) throw Error('图片尚未获得素材归属回执');
    const src = URL.createObjectURL(file); this.urls.add(src);
    try{const image=await this.decodeImage(src,epoch,signal);this.check(epoch,signal);this.known.set(answer.mediaId,src);return {image,mediaId:answer.mediaId,src};}
    catch(error){if(this.urls.delete(src))URL.revokeObjectURL(src);throw error;}
  }
  importFile(file: File, mediaId?: string,signal?:AbortSignal):Promise<any> {
    const epoch=this.epoch;const work=(async()=>{
      this.check(epoch,signal);await this.ready;this.check(epoch,signal);
      if(this.disabled || this.locked) throw Error('当前设计正在处理，请稍后插入图片');
      let image:HTMLImageElement,id:string;
      if(mediaId){
        if(!file.type.startsWith('image/') || !file.size || file.size>40*1024*1024)throw Error('图片文件无效');
        const src=URL.createObjectURL(file);this.urls.add(src);
        try{image=await this.decodeImage(src,epoch,signal);this.check(epoch,signal);this.known.set(mediaId,src);id=mediaId;}
        catch(error){if(this.urls.delete(src))URL.revokeObjectURL(src);throw error;}
      }else{const loaded=await this.readImage(file,epoch,signal);image=loaded.image;id=loaded.mediaId;}
      const object=await this.editor!.createImgByElement(image);this.check(epoch,signal);if(this.locked)throw Error('当前设计正在导出，请重新插入图片');
      object.set('data',{creatorosMediaId:id});this.editor!.addBaseType(object,{scale:true});this.publish();return this.snapshot();
    })();return this.ownedJob(work,epoch,signal);
  }
  async replaceImage(object: any, file: File) {
    const epoch = this.epoch; const loaded = await this.readImage(file,epoch);this.check(epoch);
    if(this.locked || !this.editor!.fabricCanvas!.getObjects().includes(object))throw Error('当前图片已切换，请重新选择');
    const width=object.width*object.scaleX, height=object.height*object.scaleY;
    await new Promise<void>(resolve=>object.setSrc(loaded.src,resolve)); this.check(epoch);
    object.set({scaleX:width/loaded.image.width,scaleY:height/loaded.image.height,data:{...(object.data||{}),creatorosMediaId:loaded.mediaId}});
    delete object.data.creatorosMissingSource;delete object.data.creatorosMissingMediaId;delete object.data.creatorosMissingDataPresent;delete object.data.creatorosMissingKnownRef;this.editor!.fabricCanvas!.renderAll();this.publish();
  }
  snapshot() {this.check();return {document:restoreMissing(this.editor!.getJson())};}
  private async registerImages(epoch: number,signal?:AbortSignal) {
    const native=this.editor!.getJson();const images:any[]=[];walkImages(native,item=>images.push(item));
    for(const item of images){this.check(epoch,signal);const src=String(item.src||'');if(item.data?.creatorosMissingSource)continue;
      if(item.data?.creatorosMediaId && this.known.get(item.data.creatorosMediaId)===src)continue;
      if(!/^data:image\//.test(src)){if(item.data?.creatorosMediaId)continue;throw Error('图片缺少原素材关联，请替换后保存');}
      const response=await fetch(src);this.check(epoch,signal);const blob=await response.blob();this.check(epoch,signal);
      const loaded=await this.readImage(new File([blob],`${item.id||'generated'}.png`,{type:blob.type}),epoch,signal);this.check(epoch,signal);
      const find=(objects:any[]):any=>{for(const object of objects){if(object.id===item.id)return object;if(object.getObjects){const found=find(object.getObjects());if(found)return found;}}};
      const object=find(this.editor!.fabricCanvas!.getObjects());if(!object)throw Error('图片图层已切换，请重新保存');
      object.set('data',{...(object.data||{}),creatorosMediaId:loaded.mediaId});
      // Preserve the current pixel source and record the exact upload for the host snapshot.
      this.known.set(loaded.mediaId,src);
    }
  }
  async preview(){const result=await this.request('export',{format:'png'});this.check();return new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(Error('预览读取失败'));reader.readAsDataURL(result.blob);});}
  async exportLocal(kind:string){
    let blob:Blob;let extension:string;
    if(kind==='saveImg'||kind==='clipboardBase64'){const result=await this.request('export',{format:'png'});this.check();if(kind==='clipboardBase64'){const value=await this.preview();this.check();await navigator.clipboard.writeText(value);this.check();this.notice('图片文本已复制');return;}blob=result.blob;extension='png';}
    else if(kind==='saveSvg'){const epoch=this.epoch;const release=this.lock();try{await this.registerImages(epoch);this.check(epoch);const result=await this.editor!.getPlugin('ServersPlugin').previewSvgDocument();this.check(epoch);blob=new Blob([result.svg],{type:'image/svg+xml'});extension='svg';}finally{release();}}
    else{const result=await this.request('snapshot');this.check();const text=JSON.stringify(result.document,null,2);if(kind==='clipboard'){await navigator.clipboard.writeText(text);this.check();this.notice('图层 JSON 已复制');return;}blob=new Blob([text],{type:'application/json'});extension='json';}
    const src=URL.createObjectURL(blob!);this.urls.add(src);const anchor=document.createElement('a');anchor.href=src;anchor.download=`${this.title.replace(/[\\/:*?"<>|]/g,'_')}.${extension!}`;this.options.portalContainer.append(anchor);anchor.click();anchor.remove();
  }
  private async sanitize(input: any, trusted: boolean, epoch: number,signal?:AbortSignal) {
    const value=JSON.parse(JSON.stringify(input));if(!value||!Array.isArray(value.objects))throw Error('图层稿件格式不正确');
    const images: any[]=[];walkImages(value,item=>images.push(item));let missing=0;
    for(const item of images){this.check(epoch,signal); const src=typeof item.src==='string'?item.src:'';const id=item.data?.creatorosMediaId;
      if(typeof item.data?.creatorosMissingSource==='string' && src===missingPixel){
        const exact=typeof id==='string' && item.data.creatorosMissingSource===`creatoros-media://${id}`;
        if(trusted&&exact)this.knownReferences.add(id);
        item.data.creatorosMissingKnownRef=exact&&this.knownReferences.has(id);
        if(id&&!item.data.creatorosMissingKnownRef){item.data.creatorosMissingMediaId=id;delete item.data.creatorosMediaId;}
        missing++;continue;
      }
      if(id && this.known.has(id)){item.src=this.known.get(id);delete item.data.creatorosMissingSource;delete item.data.creatorosMissingMediaId;delete item.data.creatorosMissingKnownRef;continue;}
      if(trusted && id && src.startsWith('blob:')){this.known.set(id,src);this.knownReferences.add(id);delete item.data.creatorosMissingSource;delete item.data.creatorosMissingMediaId;delete item.data.creatorosMissingKnownRef;continue;}
      if(trusted && typeof id==='string' && src===`creatoros-media://${id}`)this.knownReferences.add(id);
      if(/^data:image\//.test(src)){try{const response=await fetch(src);this.check(epoch,signal);const blob=await response.blob();this.check(epoch,signal);const loaded=await this.readImage(new File([blob],`${item.id||'image'}.png`,{type:blob.type}),epoch,signal);item.src=loaded.src;item.data={...(item.data||{}),creatorosMediaId:loaded.mediaId};continue;}catch(e){this.check(epoch,signal);this.error(e);}}
      item.data={...(item.data||{}),creatorosMissingDataPresent:Object.prototype.hasOwnProperty.call(item,'data'),creatorosMissingSource:src,creatorosMissingKnownRef:typeof id==='string'&&this.knownReferences.has(id)&&src===`creatoros-media://${id}`};
      if(id&&!item.data.creatorosMissingKnownRef){item.data.creatorosMissingMediaId=id;delete item.data.creatorosMediaId;}
      item.src=missingPixel; missing++;
    }
    const sanitizePaint=(item:any,keys:string[])=>{const patterns:any[]=[];for(const key of keys){
      const pattern=item[key];if(!pattern || typeof pattern!=='object' || !pattern.source)continue;
      // SEMANTIC_BOUNDARY_ALLOW: match Fabric5 enlivenPatterns/_initPattern's truthy source rule regardless of type; validate resources only.
      // External URLs and function strings never reach Fabric's image loader. Preserve pure colors and gradients.
      if(typeof pattern.source==='string' && /^data:image\/(png|jpeg|webp|gif);base64,/.test(pattern.source))continue;
      patterns.push({key,source:pattern.source});pattern.source=missingPixel;missing++;
    }if(patterns.length)item.data={...(item.data||{}),creatorosPatternDataPresent:Object.prototype.hasOwnProperty.call(item,'data'),creatorosMissingPatterns:patterns};};
    walkObjects(value,item=>sanitizePaint(item,['fill','stroke']));
    sanitizePaint(value,['background','overlay']);
    if(missing)this.notice(`${missing} 张图片缺少原始素材，图层结构已保留，请替换图片。`,'error');return value;
  }
  loadDocument(input:any,trusted=false,signal?:AbortSignal):Promise<any>{
    const epoch=this.advanceEpoch();const work=(async()=>{
      await this.ready;this.check(epoch,signal);this.loading=true;clearTimeout(this.timer);
      try{const doc=await this.sanitize(input,trusted,epoch,signal);this.check(epoch,signal);
        await new Promise<void>((resolve,reject)=>{
          const signals=Array.from(new Set([this.signal,signal].filter((value):value is AbortSignal=>!!value)));
          const clean=()=>{clearTimeout(timer);this.timers.delete(timer);signals.forEach(current=>current.removeEventListener('abort',stop));};
          const stop=()=>{clean();reject(Error('已切换作品，原读取停止'));};
          const timer=setTimeout(()=>{clean();reject(Error('图层读取超时，原稿已保留'));},30000);this.timers.add(timer);signals.forEach(current=>current.addEventListener('abort',stop,{once:true}));
          Promise.resolve(this.editor!.loadJSON(doc,()=>{clean();try{this.check(epoch,signal);resolve();}catch(error){reject(error);}})).catch(error=>{clean();reject(error);});
        });this.check(epoch,signal);this.editor!.getPlugin('HistoryPlugin')?.clearAndSaveState?.();this.baseline=JSON.stringify(this.snapshot().document);
      }finally{if(epoch===this.epoch || this.disposed)this.loading=false;clearTimeout(this.timer);}return this.snapshot();
    })();return this.ownedJob(work,epoch,signal);
  }
  async importJson(file: File) {const epoch=this.epoch;const text=await file.text();this.check(epoch);const resume=this.lock();try{await this.loadDocument(JSON.parse(text),false);this.options.onChanged();}finally{resume();}}
  async reset(width:number,height:number){if(!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1||width>10000||height>10000)throw Error('尺寸应为 1 至 10000');
    if(this.editor!.fabricCanvas!.getObjects().some(o=>o.id!=='workspace') && !(await this.confirm('重新创建设计','将清空当前图层并设置新尺寸。尚未保存的修改会被移除。')))return;
    this.check();this.advanceEpoch();this.editor!.clear();this.editor!.setSize(width,height);this.editor!.getPlugin('HistoryPlugin')?.clearAndSaveState?.();this.publish();
  }
  request(operation:string,payload?:any,options?:{requestId?:string;signal?:AbortSignal}):Promise<any>{
    this.check(this.epoch,options?.signal);const id=options?.requestId;if(id&&this.requests.has(id))return this.requests.get(id)!;
    const result=this.sequence.then(async()=>{await this.ready;this.check(this.epoch,options?.signal);
      switch(operation){case 'load':{this.title=typeof payload?.title==='string'?payload.title:'图文设计';if(payload?.document!=null)return this.loadDocument(payload.document,true,options?.signal);const w=Number(payload?.width)||900,h=Number(payload?.height)||1200;if(w<1||h<1||w>10000||h>10000)throw Error('图文尺寸超出范围');this.advanceEpoch();this.editor!.clear();this.editor!.setSize(w,h);this.editor!.getPlugin('HistoryPlugin')?.clearAndSaveState?.();this.baseline=JSON.stringify(this.snapshot().document);return this.snapshot();}
        case 'snapshot':{const epoch=this.epoch;const release=this.lock();try{await this.registerImages(epoch,options?.signal);this.check(epoch,options?.signal);return this.snapshot();}finally{release();}}
        case 'insert-media':if(typeof payload?.mediaId!=='string'||!payload.mediaId)throw Error('图片缺少素材关联');return this.importFile(payload.file,payload.mediaId,options?.signal);
        case 'export': {if(payload?.format!=='png')throw Error('暂支持 PNG 导出');const epoch=this.epoch;const resume=this.lock();try{await this.registerImages(epoch,options?.signal);this.check(epoch,options?.signal);const result=await this.editor!.previewDocument();this.check(epoch,options?.signal);const response=await fetch(result.dataUrl);this.check(epoch,options?.signal);const blob=await response.blob();this.check(epoch,options?.signal);return {blob,document:restoreMissing(result.document),fileName:`${this.title.replace(/[\\/:*?"<>|]/g,'_').slice(0,100)||'图文设计'}.png`};}finally{resume();}}
        default:throw Error('当前编辑器不支持此操作');}
    });this.sequence=result.catch(()=>undefined);const signals=[this.signal,options?.signal].filter((value):value is AbortSignal=>!!value);
    const exposed=new Promise<any>((resolve,reject)=>{const cancel=()=>reject(Error('已切换作品，原操作停止'));signals.forEach(signal=>signal.addEventListener('abort',cancel,{once:true}));result.then(resolve,reject).finally(()=>signals.forEach(signal=>signal.removeEventListener('abort',cancel))).catch(()=>{});});
    if(id){this.requests.set(id,exposed);void exposed.finally(()=>this.requests.delete(id)).catch(()=>{});}return exposed;
  }
  close(){if(this.disposed)return;this.disposed=true;this.advanceEpoch();this.abort.abort();clearTimeout(this.timer);this.timers.forEach(clearTimeout);this.timers.clear();this.readyReject(Error('图片编辑器已关闭'));this.cleanup.forEach(fn=>{try{fn();}catch{}});this.cleanup.clear();this.urls.forEach(URL.revokeObjectURL);this.urls.clear();this.spinNode?.remove();this.known.clear();this.knownReferences.clear();this.editor=undefined;}
}
