// Historical iframe bridge superseded by src/native-entry.ts. No native consumer.
