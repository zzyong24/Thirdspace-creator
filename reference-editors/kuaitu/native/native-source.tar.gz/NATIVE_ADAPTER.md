# 快图原生适配（T-1053）

本目录从冻结 MIT 源 `b3bdcfb0bd6d8f98e7483cf561ac03ba56c0d889` 的既有离线归档复制。
原归档 SHA256：`6c953a34d6e9deb2a53897da3e346ed292a9869bebcf9f3b4e8585a7d3858294`。
原文件版权与 root LICENSE、core ISC 声明保留；直接和传递依赖具体许可见 `dependency-license-inventory.csv` 与完整声明。

## 挂载

`native-dist/native.js` 为本地 ESM，导出 `mount(container, options)`。CreatorOS 提供同一文档 ShadowRoot 中的实际容器、portal 容器和 `native.css`；此入口不加载旧 index.html、router、iframe 或 postMessage。
实际工作面继续 `src/views/home/index.vue`、原 Vue 控件、Fabric 5.3.0 与原插件。没有以手写简化画布替换引擎。

options：owner（accountId/outputId/sourceVersionId）、theme（mode/tokens/fontFamily/fontSize/density）、portalContainer、signal、onChanged、onError、importMedia。
handle：request(load/snapshot/insert-media/export)、update(theme/disabled)、dispose。
snapshot 返回 `{document}`；PNG 导出返回 `{blob,document,fileName}`；正式稿件、素材归属和 CAS 保存由原 CreatorOS 服务持有。

## 原生改动

- 每实例直接 controller、串行 request、真实 DOM refs、精确 JSON 脏状态去重；公开 importFile/loadDocument 的上传与图片解码通过受管作业，epoch/owner/request abort 和卸载立即结清、清 src/handler、移除回执 listener，迟到回执不创建 URL/图层；卸载中断等待、迟到回执校验、清理 timer/observer/listener/URL/原插件/Fabric。最后一个实例释放共享 filter backend，单个 Image 的 GPU texture 由原 Fabric.dispose 清理。
- 原快捷键绑定实例 root/portal，文本输入和编辑器外部保留本来行为；图片导入、拖放、粘贴、替换和裁剪结果先调用 importMedia，再附真实 mediaId。生成图片在 snapshot/export 前确认素材回执。
- JSON 图层保持原结构；已有 exact blob 图片按宿主映射载入。缺失/任意外链图片与图案函数以安全空图展示、提醒缺失，snapshot 为宿主已核实的缺图保留原 scheme 和真实 creatorosMediaId；未知引用保留合同允许的安全 PNG 与原 source/MissingMediaId 元数据，避免合法剩余图层无法保存；图案恢复原资源字段；不执行源函数、不访问任意外链、不丢其余合法图层。
- 导出只锁本实例 root/portal；使用原 previewDocument 同次捕获 PNG 与 JSON。保留原 JSON/SVG/PNG、预览与 Clipboard 按钮，文件交付在实例 portal；不锁应用 body。
- 原程序式 UI 提示/确认/预览改为实例 portal。原 ViewUI Modal 仍复用实际组件，在实例 Teleport 内，禁用 body 滚动副作用，ESC 检查当前实例焦点。实际 Fabric 文本编辑隐藏 textarea 位于当前 root。
- 原云“创建设计”改为同稿 reset/尺寸和实际确认。删掉原全页 lang/hash/router/session 路径。CSS 构建以 AST 将 html/body/:root 改为 ShadowRoot :host；UI 使用 CreatorOS tokens，作品自身颜色/字体不被 UI theme 写入。实际 Fabric 选框和控制点从公共 --creatoros-brand 读取，真实 Rect.toObject 前后相等回归通过。

## 重建

按已有 `pnpm-lock.yaml` 安装冻结依赖（`--frozen-lockfile --ignore-scripts`，原离线准备使用 pnpm 8.15.9）。
执行 `node native-build.mjs`。构建写 native.js/native.css、实际模块图、源码与产物 hash、LICENSE/完整声明。
运行命令自身使用当前 Node、现有 Vite，不获取新运行时或依赖。独立静态 ESM 构建在编译期固定 process.env.NODE_ENV 为 production，避免 Vue 库模式把 Node 环境全局留给浏览器。CommonJS strictRequires 固定为 true，保留原依赖按需求值顺序，避免自动循环检测因转换次序造成重建字节漂移。

## 验证边界

当前新宿主 TS 文件检查通过；Vite 实际原组件/引擎构建通过；controller 和原 Editor/Resize/Workspace 生命周期 JSDOM 夹具 29 项通过。
真实 Fabric5 enlivenPatterns/Pattern 边界回归确认无 type 的 fill/stroke 与画布 background/overlay 外链及函数字符串被阻断，正常 data 图案和纯色保留；本次图层两项及画布一项真实红测日志保留。第一次 controller 回归暴露缺图恢复额外添加空 data 的问题，已修复；两项异步夹具等待时序与一项 destroy 夹具漏 canvas 已分别修复，原失败日志保留。
原生 PNG 渲染、真实浏览器像素、系统 Clipboard 和完整实际 Fabric 交互尚未运行，不能把上述夹具当作真机证据。
原初次广泛 TypeScript 读取了既有 upstream core 类型错误；新宿主通过窄的真实 engine port 单独检查，未宣称全部 upstream TypeScript 全绿。
