/*
 * @Author: 秦少卫
 * @Date: 2024-05-27 16:09:29
 * @LastEditors: 秦少卫
 * @LastEditTime: 2024-06-08 18:31:24
 * @Description: PSD插件
 */
import { fabric } from 'fabric';
import { selectFiles } from '../utils/utils';
import psdToJson from '../utils/psd';
import Psd from '@webtoon/psd';
import type { IEditor, IPluginTempl } from '@kuaitu/core';

type IPlugin = Pick<PsdPlugin, 'insertPSD'>;

declare module '@kuaitu/core' {
  // eslint-disable-next-line @typescript-eslint/no-empty-interface
  interface IEditor extends IPlugin {}
}

class PsdPlugin implements IPluginTempl {
  static pluginName = 'PsdPlugin';
  static apis = ['insertPSD'];
  constructor(public canvas: fabric.Canvas, public editor: IEditor) {}

  async insertPSD(callback?: () => void) {
    const host=this.editor.host;const epoch=host.currentEpoch();
    const files=await selectFiles({accept:'.psd'});host.check(epoch);if(!files?.length)return;
    const result=await files[0].arrayBuffer();host.check(epoch);
    const json=await psdToJson(Psd.parse(result));host.check(epoch);
    await host.loadDocument(JSON.parse(json),false);host.check();host.options.onChanged();callback?.();
  }

  loadJSON(json: string, callback?: () => void) {
    this.editor.host.loadDocument(JSON.parse(json),false).then(()=>callback?.()).catch((error:any)=>this.editor.host.error(error));
  }
}

export default PsdPlugin;
