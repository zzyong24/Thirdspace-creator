#!/usr/bin/env node
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,copyFileSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
const vite=path.join(root,'node_modules/.bin/vite');
if(!existsSync(vite))throw Error('请按 pnpm-lock.yaml 安装冻结依赖后重建，不执行安装脚本。');
const build=spawnSync(vite,['build','--config','native.vite.config.ts'],{cwd:root,stdio:'inherit'});
if(build.status!==0)throw Error(`快图原生构建失败 (${build.status})`);
const output=path.join(root,'native-dist');
copyFileSync(path.join(root,'LICENSE'),path.join(output,'LICENSE'));
const notices=path.join(root,'THIRD_PARTY_REFERENCE_NOTICES.txt');
if(existsSync(notices))copyFileSync(notices,path.join(output,'THIRD_PARTY_NOTICES.txt'));
const graph=JSON.parse(readFileSync(path.join(output,'native-graph.json'),'utf8'));
const files=Object.fromEntries(['native.js','native.css','native-graph.json','LICENSE',...(existsSync(notices)?['THIRD_PARTY_NOTICES.txt']:[])].map(name=>[name,createHash('sha256').update(readFileSync(path.join(output,name))).digest('hex')]));
writeFileSync(path.join(output,'native-meta.json'),JSON.stringify({source:'https://github.com/ikuaitu/vue-fabric-editor',commit:'b3bdcfb0bd6d8f98e7483cf561ac03ba56c0d889',sourceArchiveSha256:'6c953a34d6e9deb2a53897da3e346ed292a9869bebcf9f3b4e8585a7d3858294',entry:'src/native-entry.ts',interface:'creatoros.native-editor@1',files,moduleCount:graph.modules.length,verification:'类型与生命周期夹具另列；不声明真实浏览器像素或 PNG'},null,2)+'\n');
