import {defineConfig} from 'vite';
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx';
import vueSetupExtend from 'vite-plugin-vue-setup-extend-plus';
import autoImports from 'unplugin-auto-import/vite';
import svgLoader from 'vite-svg-loader';
import {resolve} from 'node:path';
export default defineConfig({
  base:'./',envPrefix:'APP_',define:{'process.env.NODE_ENV':JSON.stringify('production')},
  plugins:[vue(),vueJsx(),vueSetupExtend(),svgLoader(),autoImports({imports:['vue'],dts:false,eslintrc:{enabled:false}}),{name:'creatoros-native-graph',generateBundle(){const modules=Array.from(this.getModuleIds()).filter((name)=>!name.startsWith('\0')).map(name=>name.startsWith(__dirname)?name.slice(__dirname.length+1):name.replace(/^.*\/node_modules\//,'node_modules/')).sort();this.emitFile({type:'asset',fileName:'native-graph.json',source:JSON.stringify({entry:'src/native-entry.ts',modules},null,2)+'\n'});}}],
  resolve:{extensions:['.ts','.tsx','.js','.mjs','.vue','.json','.less','.css'],alias:[{find:/^@kuaitu\/core$/,replacement:resolve(__dirname,'packages/core/index.ts')},{find:/^@\//,replacement:resolve(__dirname,'src')+'/'},{find:/^~/,replacement:''},{find:/^vue-i18n$/,replacement:'vue-i18n/dist/vue-i18n.cjs.js'}]},
  css:{preprocessorOptions:{less:{javascriptEnabled:true,additionalData:`@import '${resolve(__dirname,'src/styles/variable.less')}';`}},postcss:{plugins:[{postcssPlugin:'creatoros-shadow-root',Rule(rule:any){if(rule.selector)rule.selector=rule.selector.replace(/(^|[\s,>+~])(html|body|:root)(?=$|[\s,.#:[>+~])/g,'$1:host');}}]}},
  build:{target:'es2022',commonjsOptions:{strictRequires:true},outDir:'native-dist',emptyOutDir:true,assetsInlineLimit:8192,lib:{entry:resolve(__dirname,'src/native-entry.ts'),formats:['es'],fileName:()=> 'native.js'},rollupOptions:{output:{chunkFileNames:'chunks/[name]-[hash].js',assetFileNames:asset=>asset.name?.endsWith('.css')?'native.css':'assets/[name]-[hash][extname]'}}},
});
