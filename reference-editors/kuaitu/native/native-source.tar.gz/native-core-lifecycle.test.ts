import {it,expect,vi} from 'vitest';
vi.mock('./packages/core/ServersPlugin',()=>({default:class {static pluginName='ServersPlugin';static events=[];static apis=[];destroy=vi.fn();}}));
import Editor from './packages/core/Editor';
import hotkeys from 'hotkeys-js';
import ResizePlugin from './packages/core/plugin/ResizePlugin';
import WorkspacePlugin from './packages/core/plugin/WorkspacePlugin';
vi.mock('fabric',()=>({fabric:{}}));
it('原 Editor 销毁调用插件/菜单/Fabric，精确解绑同一快捷键回调',()=>{
  const root=document.createElement('div'),workspace=document.createElement('div');root.append(workspace);document.body.append(root);root.tabIndex=0;
  const canvas:any={wrapperEl:workspace,on:vi.fn(),off:vi.fn(),dispose:vi.fn()};const host={accepts:vi.fn(()=>false),error:vi.fn(),options:{portalContainer:workspace}};
  const editor=new Editor();editor.init(canvas,{root,workspaceEl:workspace,host});
  const destroyed=vi.fn();class TestPlugin {static pluginName='TestPlugin';static apis=[];static events=[];hotkeys=['ctrl+q'];destroy=destroyed;hotkeyEvent=vi.fn();}
  const unbind=vi.spyOn(hotkeys,'unbind');editor.use(TestPlugin as any);const menu=editor.contextMenu!;const uninstall=vi.spyOn(menu,'uninstall');
  editor.destory();expect(destroyed).toHaveBeenCalledOnce();expect(canvas.off).toHaveBeenCalled();expect(canvas.dispose).toHaveBeenCalledOnce();expect(uninstall).toHaveBeenCalledOnce();expect(unbind.mock.calls[0][0]).toBe('ctrl+q');expect(typeof unbind.mock.calls[0][1]).toBe('function');
  const next=new Editor();next.init(canvas,{root,workspaceEl:workspace,host});next.use(TestPlugin as any);next.destory();expect(destroyed).toHaveBeenCalledTimes(2);unbind.mockRestore();root.remove();
});
it('原 Resize/Workspace destroy 实际断开 observer、取消 throttle、解绑原 document handler',()=>{
  const workspace=document.createElement('div');const bar=document.createElement('div');bar.dataset.resize='left';workspace.append(bar);
  const resize=Object.create(ResizePlugin.prototype);Object.assign(resize,{resizeObserver:{disconnect:vi.fn()},resizeHandler:{cancel:vi.fn()},canvas:{off:vi.fn()},eventHandler:{render:vi.fn(),onDragging:vi.fn()},onMouseUp:vi.fn(),workspaceEl:workspace});
  const remove=vi.spyOn(document,'removeEventListener');resize.destroy();expect(resize.resizeObserver.disconnect).toHaveBeenCalledOnce();expect(resize.resizeHandler.cancel).toHaveBeenCalledOnce();expect(remove).toHaveBeenCalledWith('mousemove',resize.eventHandler.onDragging);expect(remove).toHaveBeenCalledWith('mouseup',resize.onMouseUp);expect(workspace.childElementCount).toBe(0);remove.mockRestore();
  const original=Object.create(WorkspacePlugin.prototype);Object.assign(original,{resizeObserver:{disconnect:vi.fn()},resizeHandler:{cancel:vi.fn()},canvas:{off:vi.fn()}});original.destroy();expect(original.resizeObserver.disconnect).toHaveBeenCalledOnce();expect(original.resizeHandler.cancel).toHaveBeenCalledOnce();
});
