import { test, expect, mock } from "bun:test";
// 编码与画布端口为fixture，仅检验真实SceneExporter的finally，不签媒体/GPU PASS。
let cancelled = 0,
  closedVideo = 0,
  closedAudio = 0,
  cleared = 0,
  drained = 0,
  fail = false;
mock.module("@/wasm", () => ({ TICKS_PER_SECOND: 120000 }));
mock.module("opencut-wasm", () => ({
  mediaTimeToSeconds: ({ time }: any) => time / 120000,
}));
mock.module("@/fps/utils", () => ({
  frameRateToFloat: (fps: any) => fps.numerator / fps.denominator,
}));
mock.module("@/services/video-cache/service", () => ({
  VideoCache: class {
    clearAll() {
      cleared++;
    }
    async drain() {
      drained++;
    }
  },
}));
mock.module("@/services/renderer/canvas-renderer", () => ({
  CanvasRenderer: class {
    fps: any;
    canvas = { width: 10, height: 10 };
    constructor(options: any) {
      this.fps = options.fps;
    }
    getOutputCanvas() {
      return {};
    }
    dispose() {}
    async render() {}
  },
}));
mock.module("mediabunny", () => ({
  QUALITY_LOW: 1,
  QUALITY_MEDIUM: 2,
  QUALITY_HIGH: 3,
  QUALITY_VERY_HIGH: 4,
  Mp4OutputFormat: class {},
  WebMOutputFormat: class {},
  BufferTarget: class {
    buffer = new Uint8Array([1]).buffer;
  },
  Output: class {
    target: any;
    constructor(options: any) {
      this.target = options.target;
    }
    addVideoTrack() {}
    addAudioTrack() {}
    async start() {}
    async finalize() {}
    async cancel() {
      cancelled++;
    }
  },
  CanvasSource: class {
    async add() {
      if (fail) throw Error("encode failed");
    }
    close() {
      closedVideo++;
    }
  },
  AudioBufferSource: class {
    async add() {}
    close() {
      closedAudio++;
    }
  },
}));
const { SceneExporter } = await import("@/services/renderer/scene-exporter");
function fixture() {
  cancelled = closedVideo = closedAudio = cleared = drained = 0;
  fail = false;
  return new SceneExporter({
    width: 10,
    height: 10,
    fps: { numerator: 30, denominator: 1 },
    format: "mp4",
    quality: "high",
  });
}
test("SceneExporter取消关闭未finalize输出、视频源并释放独立decode cache", async () => {
  const e = fixture();
  e.cancel();
  expect(await e.export({ rootNode: { duration: 120000 } as any })).toBeNull();
  expect(cancelled).toBe(1);
  expect(closedVideo).toBe(1);
  expect(cleared).toBeGreaterThanOrEqual(1);
  expect(drained).toBe(1);
});
test("SceneExporter编码错误仍关闭源/取消输出/排空decode cache", async () => {
  const e = fixture();
  fail = true;
  await expect(
    e.export({ rootNode: { duration: 120000 } as any }),
  ).rejects.toThrow("encode failed");
  expect(cancelled).toBe(1);
  expect(closedVideo).toBe(1);
  expect(cleared).toBeGreaterThanOrEqual(1);
  expect(drained).toBe(1);
});
test("SceneExporter成功保留真实buffer但释放独立decode cache，不cancel已finalize输出", async () => {
  const e = fixture();
  expect(
    (await e.export({ rootNode: { duration: 120000 } as any }))?.byteLength,
  ).toBe(1);
  expect(cancelled).toBe(0);
  expect(closedVideo).toBe(1);
  expect(cleared).toBeGreaterThanOrEqual(1);
  expect(drained).toBe(1);
});
