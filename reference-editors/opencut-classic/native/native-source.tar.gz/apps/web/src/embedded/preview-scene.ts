import type { EditorCore } from "@/core";
import type { TProject } from "@/project/types";
import type { SceneTracks } from "@/timeline/types";
import type { MediaAsset } from "@/media/types";
import { mediaTime, TICKS_PER_SECOND } from "@/wasm";
import { storageService } from "@/services/storage/service";
import { clearImageSourcesForUrls } from "@/services/renderer/nodes/image-node";
import {
  nativeHost,
  currentNativeContextEpoch,
  currentNativeContextSignal,
  type NativeOwner,
} from "./native-host";
import {
  NativeOperationError,
  nativeJson,
  canonicalNative,
  nativeDigest,
} from "./native-operations";
import { CURRENT_PROJECT_VERSION } from "./native-version";
type PreviewMedia = {
  mediaId: string;
  assetId: string;
  assetFileId: string;
  file: File;
  name: string;
  type: string;
  size: number;
  lastModified: number;
  width?: number;
  height?: number;
  duration?: number;
  fps?: number;
  hasAudio?: boolean;
};
export type PreviewSceneRequest = {
  owner: NativeOwner;
  targetSceneId: string;
  baseContextEpoch: number;
  beforeDigest: string;
  candidateDigest: string;
  tracks: SceneTracks;
  media: PreviewMedia[];
};
const conflict: (message: string) => never = (message) => {
  throw new NativeOperationError(message);
};
const tick = (value: unknown) =>
  Number.isSafeInteger(value) && Number(value) >= 0;
// SEMANTIC_BOUNDARY_ALLOW: 只验证真实归属、完整摘要、媒体文件与合法tick，预览用户给定候选，不选择内容。
function validateTracks(
  after: SceneTracks,
  before: SceneTracks,
  media: Map<string, PreviewMedia>,
) {
  if (
    !after?.main ||
    !Array.isArray(after.overlay) ||
    !Array.isArray(after.audio) ||
    after.main.id !== before.main.id
  )
    conflict("候选轨道结构已改变。");
  const oldTracks = [before.main, ...before.overlay, ...before.audio],
    ids = new Set<string>(),
    elementIds = new Set<string>();
  let duration = 0;
  for (const track of [after.main, ...after.overlay, ...after.audio]) {
    if (
      !track ||
      typeof track.id !== "string" ||
      !track.id ||
      ids.has(track.id) ||
      !Array.isArray(track.elements)
    )
      conflict("候选轨道ID或元素集合无效。");
    ids.add(track.id);
    const original = oldTracks.find((row) => row.id === track.id);
    for (const item of track.elements) {
      if (
        ![
          "video",
          "image",
          "audio",
          "text",
          "sticker",
          "graphic",
          "effect",
        ].includes(item?.type)
      ) {
        if (
          !original?.elements.some(
            (old) => canonicalNative(nativeJson(old)) === canonicalNative(item),
          )
        )
          conflict("未知图层只能保留原值。");
        if (
          tick(item?.startTime) &&
          tick(item?.duration) &&
          Number.isSafeInteger(item.startTime + item.duration)
        )
          duration = Math.max(duration, item.startTime + item.duration);
        continue;
      }
      if (
        !item ||
        typeof item.id !== "string" ||
        !item.id ||
        elementIds.has(item.id) ||
        !tick(item.startTime) ||
        !tick(item.duration) ||
        !Number.isSafeInteger(item.startTime + item.duration)
      )
        conflict("候选片段ID或时间范围无效。");
      elementIds.add(item.id);
      const old = original?.elements.find((row) => row.id === item.id);
      if (
        ![
          "video",
          "image",
          "audio",
          "text",
          "sticker",
          "graphic",
          "effect",
        ].includes(item.type)
      ) {
        if (!old || canonicalNative(nativeJson(old)) !== canonicalNative(item))
          conflict("未知图层只能保留原值。");
      }
      if (
        item.type === "video" ||
        item.type === "image" ||
        (item.type === "audio" && item.sourceType === "upload")
      ) {
        const asset = media.get(item.mediaId);
        if (
          !asset ||
          asset.type !== (item.type === "audio" ? "audio" : item.type)
        )
          conflict("候选引用的真实素材文件缺失或类型不匹配。");
      }
      if (
        "retime" in item &&
        item.retime &&
        (!Number.isFinite(item.retime.rate) || item.retime.rate <= 0)
      )
        conflict("候选播放速度无效。");
      for (const key of ["trimStart", "trimEnd", "sourceDuration"] as const)
        if (key in item && !tick(item[key])) conflict("候选原声时间范围无效。");
      duration = Math.max(duration, item.startTime + item.duration);
    }
  }
  return mediaTime({ ticks: duration });
}
export async function previewNativeScene(
  editor: EditorCore,
  payload: PreviewSceneRequest,
  signal?: AbortSignal,
) {
  if (payload && typeof payload === "object")
    payload = {
      ...payload,
      owner: { ...payload.owner },
      tracks: structuredClone(payload.tracks),
      media: Array.isArray(payload.media)
        ? payload.media.map((item) => ({ ...item }))
        : payload.media,
    };
  const host = nativeHost(),
    epoch = currentNativeContextEpoch(),
    contextSignal = currentNativeContextSignal(),
    urls: string[] = [];
  const cancelled = () =>
    host.lifetime.signal.aborted ||
    !!signal?.aborted ||
    contextSignal.aborted ||
    nativeHost() !== host ||
    currentNativeContextEpoch() !== epoch;
  const check = () => {
    host.lifetime.assertCurrent();
    if (cancelled())
      throw new DOMException("原候选预览已停止或上下文已改变。", "AbortError");
    if (canonicalNative(host.owner) !== canonicalNative(payload?.owner))
      conflict("候选作品归属已改变。");
  };
  check();
  if (
    !payload ||
    !Number.isSafeInteger(payload.baseContextEpoch) ||
    payload.baseContextEpoch !== epoch ||
    !Array.isArray(payload.media)
  )
    conflict("候选预览上下文已改变。");
  const live = editor.project.getActive(),
    original = live.scenes.find((scene) => scene.id === payload.targetSceneId);
  if (live.metadata.id !== host.owner.outputId || !original)
    conflict("候选目标场景不存在或作品已改变。");
  const before = canonicalNative(nativeJson(original.tracks));
  if ((await nativeDigest(original.tracks)) !== payload.beforeDigest)
    conflict("候选时间轴前值已改变。");
  check();
  // 摘要严格对应宿主context返回的完整序列化scene，不以runtime资源或autosave Date替代候选基准。
  const snapshot = storageService.snapshot(),
    serialized = snapshot.document.scenes.find(
      (scene) => scene.id === payload.targetSceneId,
    );
  if (
    !serialized ||
    canonicalNative(serialized.tracks) !== before ||
    (await nativeDigest({ ...serialized, tracks: payload.tracks })) !==
      payload.candidateDigest
  )
    conflict("候选完整场景摘要不匹配。");
  check();
  const files = new Map<string, PreviewMedia>();
  for (const item of payload.media) {
    if (
      !item ||
      typeof item.mediaId !== "string" ||
      !item.mediaId ||
      files.has(item.mediaId) ||
      typeof item.assetId !== "string" ||
      !item.assetId ||
      typeof item.assetFileId !== "string" ||
      !item.assetFileId ||
      !(item.file instanceof File) ||
      !["video", "audio", "image"].includes(item.type) ||
      item.file.size !== item.size ||
      item.file.lastModified !== item.lastModified
    )
      conflict("候选素材必须携带唯一真实文件与精确文件描述。");
    const existing = editor.media
      .getAssets()
      .find((asset) => asset.id === item.mediaId);
    if (
      existing &&
      (existing.type !== item.type ||
        existing.file.size !== item.file.size ||
        existing.file.lastModified !== item.file.lastModified ||
        ((existing as MediaAsset & { assetId?: string }).assetId !==
          undefined &&
          (existing as MediaAsset & { assetId?: string }).assetId !==
            item.assetId) ||
        ((existing as MediaAsset & { assetFileId?: string }).assetFileId !==
          undefined &&
          (existing as MediaAsset & { assetFileId?: string }).assetFileId !==
            item.assetFileId))
    )
      conflict("候选原片文件版本已改变。");
    files.set(item.mediaId, item);
  }
  const tracks = structuredClone(payload.tracks),
    duration = validateTracks(tracks, original.tracks, files);
  if (TICKS_PER_SECOND !== 120000) conflict("原生时间基准不匹配。");
  const project = nativeJson(live) as TProject;
  project.metadata.createdAt = new Date(project.metadata.createdAt);
  project.metadata.updatedAt = new Date(project.metadata.updatedAt);
  project.scenes = project.scenes.map((scene) => ({
    ...scene,
    createdAt: new Date(scene.createdAt),
    updatedAt: new Date(scene.updatedAt),
  }));
  project.scenes.find((scene) => scene.id === payload.targetSceneId)!.tracks =
    tracks;
  // 不切换活动场景、暂停播放/保存或落command；frozen的目标tracks决定当前场景导出范围。
  const assertUnchanged = () => {
    check();
    if (
      editor.project.getActive().metadata.id !== host.owner.outputId ||
      canonicalNative(
        nativeJson(
          editor.project
            .getActive()
            .scenes.find((scene) => scene.id === payload.targetSceneId)?.tracks,
        ),
      ) !== before
    )
      conflict("原工程在预览时发生变化。");
  };
  try {
    assertUnchanged();
    const mediaAssets: MediaAsset[] = [...files.values()].map((item) => {
      const url = URL.createObjectURL(item.file);
      urls.push(url);
      return {
        ...item,
        id: item.mediaId,
        type: item.type as MediaAsset["type"],
        url,
      };
    });
    const result = await editor.renderer.exportProject({
      options: {
        format: "mp4",
        quality: "high",
        includeAudio: true,
        fps: project.settings.fps,
      },
      onCancel: cancelled,
      frozen: { tracks, project, mediaAssets, duration },
    });
    assertUnchanged();
    if (result.cancelled)
      throw new DOMException("原候选预览已停止。", "AbortError");
    if (!result.success || !result.buffer || !result.buffer.byteLength)
      throw Error(result.error || "候选预览未生成可播放文件。");
    return {
      blob: new Blob([result.buffer], { type: "video/mp4" }),
      fileName: `${project.metadata.name}-候选预览.mp4`,
      sceneId: payload.targetSceneId,
      candidateDigest: payload.candidateDigest,
      contextEpoch: epoch,
      documentVersion: CURRENT_PROJECT_VERSION,
    };
  } finally {
    clearImageSourcesForUrls(urls);
    for (const url of urls) URL.revokeObjectURL(url);
  }
}
