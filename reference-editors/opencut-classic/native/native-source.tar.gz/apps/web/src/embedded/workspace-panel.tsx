import {useLayoutEffect,useSyncExternalStore,type ReactNode} from 'react';
import {nativeWorkspaceSnapshot,subscribeNativeWorkspace,openNativeAddon,nativeHost,syncNativeInteractivity,type NativeAddonPanel} from './native-host';
import {isExportLocked} from './edit-lock';
export function WorkspacePanel({side,children}:{side:'left'|'right';children:ReactNode}){
 const state=useSyncExternalStore(subscribeNativeWorkspace,nativeWorkspaceSnapshot,nativeWorkspaceSnapshot);
 useLayoutEffect(()=>syncNativeInteractivity(nativeHost(),isExportLocked()),[state]);
 const selected=state.split(':')[side==='left'?0:1];
 const core:NativeAddonPanel=side==='left'?'assets':'properties',addon:NativeAddonPanel=side==='left'?'transcript':'director';
 const panels=side==='left'?[[core,'素材'],[addon,'转录']]:[[addon,'编导'],[core,'属性']];
 return <div className="native-workspace-panel"><div role="tablist" aria-label={side==='left'?'素材与转录':'编导与属性'} className="native-workspace-tabs">{panels.map(([panel,label])=><button key={panel} id={`native-tab-${panel}`} type="button" role="tab" aria-selected={selected===panel} aria-controls={`native-panel-${panel}`} tabIndex={selected===panel?0:-1} onClick={()=>openNativeAddon({panel})} onKeyDown={event=>{if(event.key!=='ArrowLeft'&&event.key!=='ArrowRight'&&event.key!=='Home'&&event.key!=='End')return;event.preventDefault();const next=event.key==='Home'?panels[0][0]:event.key==='End'?panels[1][0]:panels.find(([id])=>id!==selected)![0];openNativeAddon({panel:next});event.currentTarget.parentElement?.querySelector<HTMLButtonElement>(`#native-tab-${next}`)?.focus();}}>{label}</button>)}</div><div id={`native-panel-${core}`} role="tabpanel" aria-labelledby={`native-tab-${core}`} data-native-core-panel hidden={selected!==core} inert={selected!==core} className="native-workspace-content">{children}</div><div id={`native-panel-${addon}`} role="tabpanel" aria-labelledby={`native-tab-${addon}`} hidden={selected!==addon} inert={selected!==addon} className="native-workspace-content native-workspace-addon"><slot name={`creatoros-${addon}`}/></div></div>;
}
