import { test, expect, mock } from "bun:test";
import {
  installNativeHost,
  currentNativeContextEpoch,
  invalidateNativeContext,
  nativeHost,
} from "../native-host";
import { NativeLifetime } from "../native-lifecycle";
// 真实 public controller 分发与隔离边界测试；模拟编码端口不证明 GPU、MP4 或音视频解码。
let editor: any,
  stored: any,
  assets: any[] = [],
  renderCalls: any[] = [],
  created: string[] = [],
  revoked: string[] = [],
  render: ((args: any) => Promise<any>) | undefined;
const noop = () => {};
mock.module("@/wasm", () => ({
  TICKS_PER_SECOND: 120000,
  ZERO_MEDIA_TIME: 0,
  mediaTime: (v: any) => v.ticks ?? v.time ?? 0,
}));
mock.module("@/core", () => ({
  EditorCore: { getInstance: () => editor, reset: noop },
}));
mock.module("@/services/renderer/nodes/image-node", () => ({
  clearImageSources: noop,
  clearImageSourcesForUrls: noop,
}));
mock.module("@/services/video-cache/service", () => ({
  videoCache: { drain: async () => {}, clearVideo: noop },
}));
mock.module("@/services/renderer/compositor/wasm-compositor", () => ({
  wasmCompositor: { dispose: noop },
}));
mock.module("@/services/renderer/gpu-renderer", () => ({
  initializeGpuRenderer: async () => {},
  isGpuAvailable: () => true,
}));
mock.module("@/timeline/scenes", () => ({
  buildDefaultScene: () => ({ id: "new-scene", tracks: tracks() }),
}));
mock.module("@/fps/defaults", () => ({
  DEFAULT_FPS: { numerator: 30, denominator: 1 },
}));
mock.module("@/canvas/sizes", () => ({
  DEFAULT_CANVAS_SIZE: { width: 1280, height: 720 },
}));
mock.module("@/media/processing", () => ({
  processMediaAssets: async () => [],
}));
mock.module("../media-registration", () => ({
  resetMediaRegistration: noop,
  rememberMediaFile: noop,
  cancelPendingMediaImports: noop,
  readOriginalAudioRange: async () => ({ status: "manual_review" }),
}));
for (const path of [
  "@/components/editor/panels/assets/assets-panel-store",
  "@/timeline/timeline-store",
  "@/actions/keybindings-store",
])
  mock.module(path, () =>
    Object.fromEntries(
      ["useAssetsPanelStore", "useTimelineStore", "useKeybindingsStore"].map(
        (key) => [key, { setState: noop }],
      ),
    ),
  );
mock.module("@/services/storage/service", () => ({
  storageService: {
    hostReset: noop,
    hostLoaded: noop,
    saveProject: async ({ project }: any) => {
      stored = project;
    },
    saveMediaAsset: async ({ mediaAsset }: any) => {
      assets.push(mediaAsset);
    },
    snapshot: () => ({
      document: JSON.parse(JSON.stringify(stored)),
      mediaMetadata: assets.map((a) => ({
        mediaId: a.id,
        name: a.name,
        type: a.type,
        size: a.file.size,
        lastModified: a.file.lastModified,
        duration: a.duration,
        hasAudio: a.hasAudio,
      })),
    }),
  },
}));
mock.module("@/commands/timeline/native-tracks-snapshot", () => ({
  NativeTracksSnapshotCommand: class {
    constructor(public input: any) {}
  },
}));
const { createNativeController } = await import("../native-controller");
const { nativeDigest } = await import("../native-operations");
function tracks() {
  return {
    main: {
      id: "main",
      name: "视频",
      type: "video",
      muted: false,
      hidden: false,
      elements: [
        {
          id: "clip",
          name: "原片",
          type: "video",
          mediaId: "media",
          startTime: 17,
          duration: 120001,
          trimStart: 0,
          trimEnd: 0,
          params: {},
        },
      ],
    },
    overlay: [
      {
        id: "caption",
        name: "文字",
        type: "text",
        hidden: false,
        elements: [
          {
            id: "title",
            name: "保留文字",
            type: "text",
            startTime: 0,
            duration: 240017,
            trimStart: 0,
            trimEnd: 0,
            params: {},
            opaque: { preserve: true },
          },
        ],
      },
    ],
    audio: [],
  };
}
async function fixture() {
  const parent = new AbortController(),
    life = new NativeLifetime(parent.signal);
  assets = [];
  renderCalls = [];
  created = [];
  revoked = [];
  render = undefined;
  const owner = {
    groupId: "group",
    accountId: null,
    projectId: "project",
    outputId: "output",
    sourceVersionId: "version",
  };
  const detach = installNativeHost({
    container: {} as HTMLElement,
    portalContainer: {} as HTMLElement,
    owner,
    lifetime: life,
    disabled: false,
    theme: {
      mode: "light",
      tokens: {},
      fontFamily: "system-ui",
      fontSize: "14px",
      density: "comfortable",
    },
    onChanged: noop,
    onError: noop,
    importMedia: async () => ({ mediaId: "media" }),
  });
  const forbidden = () => {
    throw Error("预览不得修改活动工程");
  };
  editor = {
    project: {
      getActive: () => stored,
      loadProject: async () => {},
      subscribe: () => noop,
    },
    save: { stop: noop, pause: noop, flush: forbidden, resume: forbidden },
    audio: { dispose: async () => {} },
    playback: {
      pause: noop,
      dispose: noop,
      getIsPlaying: () => false,
      getCurrentTime: () => 17,
      onSeek: () => noop,
      subscribe: () => noop,
      seek: forbidden,
    },
    media: {
      clearAllAssets: () => {
        assets = [];
      },
      getAssets: () => assets,
    },
    scenes: {
      getScenes: () => stored.scenes,
      getActiveScene: () =>
        stored.scenes.find((s: any) => s.id === stored.currentSceneId),
      subscribe: () => noop,
      switchToScene: forbidden,
    },
    timeline: { subscribe: () => noop, getTotalDuration: () => 240017 },
    selection: {
      getSelectedElements: () => [{ trackId: "main", elementId: "clip" }],
      subscribe: () => noop,
    },
    command: { execute: forbidden, undo: forbidden },
    renderer: {
      setDegraded: noop,
      exportProject: async (args: any) => {
        renderCalls.push(args);
        return render
          ? render(args)
          : { success: true, buffer: new Uint8Array([1, 2, 3]).buffer };
      },
    },
  };
  const originalCreate = URL.createObjectURL,
    originalRevoke = URL.revokeObjectURL;
  URL.createObjectURL = () => {
    const url = `blob:preview-test-${created.length}`;
    created.push(url);
    return url;
  };
  URL.revokeObjectURL = (url) => revoked.push(url);
  const controller = createNativeController(noop),
    file = new File(["unit-fixture-is-not-mp4"], "original.mp4", {
      type: "video/mp4",
      lastModified: 1,
    });
  const source = {
    version: 31,
    currentSceneId: "a",
    metadata: {
      id: "output",
      name: "视频",
      duration: 240017,
      createdAt: "2026-10-14T00:00:00.000Z",
      updatedAt: "2026-10-14T00:00:00.000Z",
    },
    settings: {
      fps: { numerator: 24, denominator: 1 },
      canvasSize: { width: 1280, height: 720 },
      background: { type: "color", color: "#000" },
    },
    scenes: ["a", "b"].map((id) => ({
      id,
      name: id,
      isMain: id === "a",
      tracks: tracks(),
      bookmarks: [],
      createdAt: "2026-10-14T00:00:00.000Z",
      updatedAt: "2026-10-14T00:00:00.000Z",
    })),
  };
  await controller.request("load", {
    outputId: "output",
    document: source,
    media: [
      { mediaId: "media", file, type: "video", duration: 10, hasAudio: false },
    ],
  });
  const candidate = structuredClone(stored.scenes[0]);
  candidate.tracks.main.elements[0].duration = 100001;
  const payload = {
    owner,
    targetSceneId: "a",
    baseContextEpoch: currentNativeContextEpoch(),
    beforeDigest: await nativeDigest(stored.scenes[0].tracks),
    candidateDigest: await nativeDigest(candidate),
    tracks: candidate.tracks,
    media: [
      {
        mediaId: "media",
        assetId: "asset",
        assetFileId: "asset-file",
        file,
        name: file.name,
        type: "video",
        size: file.size,
        lastModified: file.lastModified,
        duration: 10,
        hasAudio: false,
      },
    ],
  };
  return {
    controller,
    payload,
    life,
    source,
    before: JSON.stringify(stored),
    selection: JSON.stringify(editor.selection.getSelectedElements()),
    async close() {
      life.cancel();
      await life.drain();
      controller.clear();
      detach();
      URL.createObjectURL = originalCreate;
      URL.revokeObjectURL = originalRevoke;
    },
  };
}
test("preview-scene public 命令使用候选独立 frozen 实际编码端口，活动工程/撤销/选区/epoch不变", async () => {
  const f = await fixture();
  try {
    const epoch = currentNativeContextEpoch(),
      result: any = await f.controller.request("preview-scene", f.payload);
    expect(renderCalls).toHaveLength(1);
    const args = renderCalls[0];
    expect(args.frozen.project).not.toBe(stored);
    expect(args.frozen.tracks).toEqual(f.payload.tracks);
    expect(args.frozen.project.scenes[1]).toEqual(stored.scenes[1]);
    expect(args.frozen.duration).toBe(240017);
    expect(args.options.fps).toEqual({ numerator: 24, denominator: 1 });
    expect(args.frozen.mediaAssets[0].file).toBe(f.payload.media[0].file);
    expect(result).toMatchObject({
      operation: "preview-scene",
      sceneId: "a",
      candidateDigest: f.payload.candidateDigest,
      contextEpoch: epoch,
      documentVersion: 31,
    });
    expect(result.blob).toBeInstanceOf(Blob);
    expect(result.blob.size).toBe(3);
    expect(JSON.stringify(stored)).toBe(f.before);
    expect(JSON.stringify(editor.selection.getSelectedElements())).toBe(
      f.selection,
    );
    expect(currentNativeContextEpoch()).toBe(epoch);
    expect(revoked).toEqual(created.slice(1));
  } finally {
    await f.close();
  }
});
for (const field of [
  "owner",
  "epoch",
  "before",
  "candidate",
  "scene",
  "file",
  "duplicate media",
  "missing media",
] as const)
  test(`preview-scene ${field}拒绝在编码前，保留活动稿件`, async () => {
    const f = await fixture();
    try {
      const p: any = { ...f.payload, media: [...f.payload.media] };
      if (field === "owner")
        p.owner = { ...p.owner, sourceVersionId: "foreign" };
      if (field === "epoch") p.baseContextEpoch++;
      if (field === "before") p.beforeDigest = "sha256:wrong";
      if (field === "candidate") p.candidateDigest = "sha256:wrong";
      if (field === "scene") p.targetSceneId = "missing";
      if (field === "file")
        p.media[0] = { ...p.media[0], file: new Blob(["fake"]) };
      if (field === "duplicate media") p.media.push(p.media[0]);
      if (field === "missing media") p.media = [];
      await expect(
        f.controller.request("preview-scene", p),
      ).rejects.toMatchObject({ code: "ConflictError" });
      expect(renderCalls).toHaveLength(0);
      expect(JSON.stringify(stored)).toBe(f.before);
    } finally {
      await f.close();
    }
  });
for (const kind of ["request", "selection epoch", "owner lifetime"] as const)
  test(`preview-scene ${kind}期间取消，迟到buffer不得返回且URL释放`, async () => {
    const f = await fixture(),
      abort = new AbortController();
    try {
      let finish!: () => void;
      render = (args) =>
        new Promise((resolve) => {
          finish = () =>
            resolve({ success: true, buffer: new Uint8Array([4]).buffer });
        });
      const pending = f.controller
        .request("preview-scene", f.payload, { signal: abort.signal })
        .catch((e) => e);
      for (let i = 0; i < 100 && !finish; i++)
        await new Promise((resolve) => setTimeout(resolve, 1));
      expect(finish).toBeDefined();
      if (kind === "request") abort.abort();
      else if (kind === "owner lifetime") f.life.cancel();
      else
        invalidateNativeContext({
          sceneId: "a",
          selectedElements: [],
          documentChanged: false,
        });
      expect(renderCalls[0].onCancel()).toBe(true);
      finish();
      expect(await pending).toMatchObject({ name: "AbortError" });
      expect(revoked).toEqual(created.slice(1));
      expect(JSON.stringify(stored)).toBe(f.before);
    } finally {
      await f.close();
    }
  });
test("preview-scene 编码失败不能伪造Blob，临时URL释放且旧seek/read命令仍可达", async () => {
  const f = await fixture();
  try {
    render = async () => ({ success: false, error: "真实编码失败" });
    await expect(
      f.controller.request("preview-scene", f.payload),
    ).rejects.toThrow("真实编码失败");
    expect(revoked).toEqual(created.slice(1));
    expect(
      await f.controller.request("read-original-audio-range", {}),
    ).toMatchObject({
      operation: "read-original-audio-range",
      status: "manual_review",
    });
    await expect(f.controller.request("unsupported")).rejects.toThrow(
      "尚不支持",
    );
  } finally {
    await f.close();
  }
});
test("原公共load/context/snapshot/seek/apply-tracks/export仍沿真实controller命令入口成功", async () => {
  const f = await fixture();
  try {
    let flushed = 0,
      paused = 0,
      resumed = 0,
      sought = -1;
    editor.save.flush = async () => {
      flushed++;
    };
    editor.save.resume = () => {
      resumed++;
    };
    editor.playback.pause = () => {
      paused++;
    };
    editor.playback.seek = ({ time }: any) => {
      sought = time;
    };
    const context: any = await f.controller.request("context");
    expect(context).toMatchObject({
      operation: "context",
      outputId: "output",
      sceneId: "a",
      ticksPerSecond: 120000,
    });
    expect(
      ((await f.controller.request("snapshot")) as any).document.version,
    ).toBe(31);
    await f.controller.request("seek", {
      outputId: "output",
      sceneId: "a",
      tick: 12347,
    });
    expect(sought).toBe(12347);
    const before = structuredClone(stored.scenes[0].tracks),
      after = structuredClone(before);
    after.main.elements[0].duration = 110003;
    editor.command.execute = ({ command }: any) => {
      stored.scenes[0].tracks = command.input.after;
    };
    await f.controller.request(
      "apply-tracks",
      {
        outputId: "output",
        sceneId: "a",
        expectedBeforeDigest: await nativeDigest(before),
        beforeTracks: before,
        afterTracks: after,
      },
      { requestId: "old-apply" },
    );
    expect(stored.scenes[0].tracks).toEqual(after);
    const result: any = await f.controller.request("export", { format: "mp4" });
    expect(result).toMatchObject({ operation: "export", fileName: "视频.mp4" });
    expect(result.blob.size).toBe(3);
    expect(renderCalls[0].frozen.duration).toBe(240017);
    expect(flushed).toBe(3);
    expect(paused).toBe(1);
    expect(resumed).toBe(1);
  } finally {
    await f.close();
  }
});
test("preview-scene保留旧未知只读层、无时间字段扩展和其他scene，不按未知内容猜媒体", async () => {
  const f = await fixture();
  try {
    stored.scenes[0].tracks.overlay.push({
      id: "legacy",
      type: "legacy-overlay",
      name: "原扩展",
      elements: [{ opaque: { label: "原值" } }],
    });
    const tracks = structuredClone(stored.scenes[0].tracks);
    tracks.main.elements[0].duration = 100001;
    f.payload.tracks = tracks;
    f.payload.beforeDigest = await nativeDigest(stored.scenes[0].tracks);
    f.payload.candidateDigest = await nativeDigest({
      ...stored.scenes[0],
      tracks,
    });
    const before = JSON.stringify(stored);
    await f.controller.request("preview-scene", f.payload);
    expect(renderCalls[0].frozen.tracks.overlay[1]).toEqual(
      stored.scenes[0].tracks.overlay[1],
    );
    expect(JSON.stringify(stored)).toBe(before);
  } finally {
    await f.close();
  }
});
test("preview-scene public 支持原video及其已分离upload原声音轨，仅改主轨时音轨完整保留", async () => {
  const f = await fixture();
  try {
    const source = stored.scenes[0].tracks.main.elements[0];
    source.isSourceAudioEnabled = false;
    assets[0].hasAudio = true;
    f.payload.media[0].hasAudio = true;
    stored.scenes[0].tracks.audio.push({
      id: "separated-audio-track",
      name: "已分离原声",
      type: "audio",
      muted: false,
      elements: [
        {
          ...structuredClone(source),
          id: "separated-original-audio",
          type: "audio",
          sourceType: "upload",
          params: { volume: 1, muted: false },
        },
      ],
    });
    const tracks = structuredClone(stored.scenes[0].tracks);
    tracks.main.elements[0].duration = 100001;
    f.payload.tracks = tracks;
    f.payload.beforeDigest = await nativeDigest(stored.scenes[0].tracks);
    f.payload.candidateDigest = await nativeDigest({
      ...stored.scenes[0],
      tracks,
    });
    const before = JSON.stringify(stored),
      epoch = currentNativeContextEpoch();
    const result: any = await f.controller.request("preview-scene", f.payload);
    expect(result).toMatchObject({
      operation: "preview-scene",
      contextEpoch: epoch,
      candidateDigest: f.payload.candidateDigest,
    });
    expect(renderCalls).toHaveLength(1);
    expect(renderCalls[0].frozen.tracks.audio).toEqual(
      stored.scenes[0].tracks.audio,
    );
    expect(renderCalls[0].frozen.tracks.audio[0].elements[0].mediaId).toBe(
      "media",
    );
    expect(renderCalls[0].frozen.mediaAssets[0].type).toBe("video");
    expect(JSON.stringify(stored)).toBe(before);
    expect(currentNativeContextEpoch()).toBe(epoch);
  } finally {
    await f.close();
  }
});
for (const invalid of ["audio-image", "video-audio", "image-video"] as const)
  test(`preview-scene public ${invalid}继续拒绝不兼容媒体类型`, async () => {
    const f = await fixture();
    try {
      const tracks = structuredClone(stored.scenes[0].tracks);
      if (invalid === "audio-image") {
        const source = tracks.main.elements[0];
        tracks.main.elements = [];
        tracks.audio.push({
          id: "audio",
          name: "原声",
          type: "audio",
          muted: false,
          elements: [
            {
              ...source,
              id: "audio-clip",
              type: "audio",
              sourceType: "upload",
            },
          ],
        });
        assets[0].type = "image";
        f.payload.media[0].type = "image";
      } else if (invalid === "video-audio") {
        assets[0].type = "audio";
        f.payload.media[0].type = "audio";
      } else {
        (tracks.main.elements[0] as any).type = "image";
      }
      f.payload.tracks = tracks;
      f.payload.beforeDigest = await nativeDigest(stored.scenes[0].tracks);
      f.payload.candidateDigest = await nativeDigest({
        ...stored.scenes[0],
        tracks,
      });
      const before = JSON.stringify(stored);
      await expect(
        f.controller.request("preview-scene", f.payload),
      ).rejects.toMatchObject({ code: "ConflictError" });
      expect(renderCalls).toHaveLength(0);
      expect(JSON.stringify(stored)).toBe(before);
    } finally {
      await f.close();
    }
  });
