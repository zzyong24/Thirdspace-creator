import { test, expect, mock } from "bun:test";
let parent = new AbortController(),
  images: any[] = [];
class ImageFixture {
  onload: any;
  onerror: any;
  src = "";
  constructor() {
    images.push(this);
  }
  removeAttribute() {
    this.src = "";
  }
  remove() {}
}
Object.assign(globalThis, {
  Image: ImageFixture,
  HTMLImageElement: ImageFixture,
});
mock.module("@/embedded/native-host", () => ({
  currentNativeHost: () => ({ lifetime: { signal: parent.signal } }),
}));
const { loadImageSource, clearImageSources } =
  await import("@/services/renderer/nodes/image-node");
test("候选自己的取消signal立即停止慢图片，不取消活动host寿命且迟到图片不返回", async () => {
  parent = new AbortController();
  images = [];
  const request = new AbortController(),
    pending = loadImageSource({
      url: "blob:preview-only",
      signal: request.signal,
    } as any).catch((e) => e);
  try {
    expect(images).toHaveLength(1);
    request.abort();
    expect(images[0].src).toBe("");
    expect(parent.signal.aborted).toBe(false);
    expect(await pending).toMatchObject({ name: "AbortError" });
  } finally {
    parent.abort();
    await pending;
    clearImageSources();
  }
});
