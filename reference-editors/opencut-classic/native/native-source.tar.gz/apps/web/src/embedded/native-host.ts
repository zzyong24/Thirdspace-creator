import type {NativeLifetime} from './native-lifecycle';
export type NativeTheme={mode:'light'|'dark';tokens:Record<string,string>;fontFamily:string;fontSize:string;density:string};
export type NativeOwner={groupId:string|null;accountId:string|null;projectId:string;outputId:string;sourceVersionId:string};
export type NativeContextEvent={kind:'native-context';contextEpoch:number;outputId:string;sceneId:string|null;selectedElements:unknown[];documentChanged:boolean};
export function nativeOwnerKey(owner:NativeOwner){return JSON.stringify([owner.groupId?["group",owner.groupId]:["account",owner.accountId],owner.projectId,owner.outputId,owner.sourceVersionId]);}
export type NativeHost={container:HTMLElement;portalContainer:HTMLElement;owner:NativeOwner;theme:NativeTheme;lifetime:NativeLifetime;disabled:boolean;visible?:boolean;workspaceAddons?:boolean;previewActive?:boolean;onImportActivity?:(pending:number)=>void;onDocumentChanged?:()=>void;readPreviewPlaying?:()=>boolean;onChanged:(event?:NativeContextEvent)=>void;onError:(message:string)=>void;importMedia:(file:File,options?:{signal?:AbortSignal})=>Promise<{mediaId:string}>};
let host:NativeHost|null=null;
export function installNativeHost(value:NativeHost){if(host)throw Error('旧剪辑实例尚未销毁。');contextController.abort();contextController=new AbortController();contextEpoch=0;lastNativeContext={sceneId:null,selectedElements:[],documentChanged:false};workspacePanels='assets:director';workspaceView='preview';previewReturnView=null;value.previewActive=false;host=value;return()=>{if(host===value){contextController.abort();workspaceListeners.clear();host=null;}};}
export function nativeHost(){if(!host)throw Error('剪辑组件尚未挂载。');return host;}
export function currentNativeHost(){return host;}
export function nativeChanged(){if(host&&!host.lifetime.signal.aborted){if(host.onDocumentChanged)host.onDocumentChanged();else invalidateNativeContext({...lastNativeContext,documentChanged:true});}}
export function nativePortal(){return nativeHost().portalContainer;}
export function nativeActiveElement():Element|null{const root=host?.container.getRootNode();return root instanceof ShadowRoot?root.activeElement:document.activeElement;}
function isHostAddon(node:unknown){return typeof Element!=='undefined'&&node instanceof Element&&!!node.closest('[data-creatoros-addon]');}
export function ownsNativeEvent(event:Event){if(!host||host.lifetime.signal.aborted||host.disabled||host.previewActive||host.visible===false)return false;const path=event.composedPath();if(path.some(isHostAddon))return false;return path.includes(host.container)||path.includes(host.portalContainer)||path.some(node=>node instanceof Node&&(host!.container.contains(node)||host!.portalContainer.contains(node)));}
export function nativeFocused(){if(!host||host.lifetime.signal.aborted||host.disabled||host.previewActive||host.visible===false)return false;const active=nativeActiveElement();return !!active&&!isHostAddon(active)&&(host.container.contains(active)||host.portalContainer.contains(active));}
const appliedTokens=new WeakMap<HTMLElement,Set<string>>();
export function applyNativeTheme(target:HTMLElement,theme:NativeTheme){const next=new Set(Object.keys(theme.tokens).filter(key=>/^--creatoros-[a-z0-9-]+$/i.test(key)));for(const key of appliedTokens.get(target)??[])if(!next.has(key))target.style.removeProperty(key);for(const key of next)target.style.setProperty(key,theme.tokens[key]);appliedTokens.set(target,next);target.style.fontFamily=theme.fontFamily;target.style.fontSize=theme.fontSize;target.dataset.density=theme.density;target.classList.toggle('dark',theme.mode==='dark');target.dataset.theme=theme.mode;}

let lastNativeContext={sceneId:null as string|null,selectedElements:[] as unknown[],documentChanged:false};let contextEpoch=0;let contextController=new AbortController();
export function currentNativeContextEpoch(){return contextEpoch;}
export function currentNativeContextSignal(){return contextController.signal;}
export function invalidateNativeContext(value:Omit<NativeContextEvent,'kind'|'contextEpoch'|'outputId'>){contextController.abort();contextController=new AbortController();contextEpoch++;lastNativeContext=value;const h=currentNativeHost();if(h&&!h.lifetime.signal.aborted)h.onChanged({kind:'native-context',contextEpoch,outputId:h.owner.outputId,...value});}

export type NativeContextPort={
 read:()=>{documentFingerprint:string;sceneId:string;selectedElements:unknown[];playing:boolean};
 onDocument:(listener:()=>void)=>()=>void;onSelection:(listener:()=>void)=>()=>void;onSeek:(listener:()=>void)=>()=>void;onPlayback:(listener:()=>void)=>()=>void;
};
// SEMANTIC_BOUNDARY_ALLOW: exact document/selection/state changes invalidate local stale operations only.
export function bindNativeContext(port:NativeContextPort){
 const h=nativeHost();let previous=port.read();let live=true;
 const observe=(seek=false)=>{if(!live||h.lifetime.signal.aborted)return;const next=port.read();const documentChanged=next.documentFingerprint!==previous.documentFingerprint;
  const changed=seek||documentChanged||next.sceneId!==previous.sceneId||JSON.stringify(next.selectedElements)!==JSON.stringify(previous.selectedElements)||next.playing!==previous.playing;previous=next;
  if(changed)invalidateNativeContext({sceneId:next.sceneId,selectedElements:next.selectedElements,documentChanged});
 };
 const document=()=>observe();const playing=()=>port.read().playing;h.onDocumentChanged=document;h.readPreviewPlaying=playing;
 const stops=[port.onDocument(document),port.onSelection(()=>observe()),port.onSeek(()=>observe(true)),port.onPlayback(()=>observe())];
 return()=>{if(!live)return;live=false;stops.forEach(stop=>stop());if(h.onDocumentChanged===document)delete h.onDocumentChanged;if(h.readPreviewPlaying===playing)delete h.readPreviewPlaying;};
}

// SEMANTIC_BOUNDARY_ALLOW: 显式宿主请求暂停真实预览，不选择/变速/更改工程。
export function pauseNativePlaybackForContext(playback:{pause:()=>void},assertCurrent:()=>void){assertCurrent();playback.pause();assertCurrent();return currentNativeContextEpoch();}
// 原声仅在原预览已暂停时读取。read回调才分配Input；不暗暂停并沿用旧epoch。
export function withNativeOriginalAudioPreviewGuard<T>(read:()=>T|Promise<T>,manual:()=>T):T|Promise<T>{const h=nativeHost();h.lifetime.assertCurrent();if(h.readPreviewPlaying?.()===true)return manual();return read();}

// T1274: 页签只属于宿主布局；不生成工程修改、选区epoch或持久化状态。
export type NativeAddonPanel='assets'|'transcript'|'director'|'properties';
let workspacePanels='assets:director';
export type NativeWorkspaceView='left'|'preview'|'timeline'|'right';
let workspaceView:NativeWorkspaceView='preview';
let previewReturnView:NativeWorkspaceView|null=null;
export function nativeWorkspaceViewSnapshot(){return workspaceView;}
export function openNativeWorkspaceView(view:NativeWorkspaceView){nativeHost().lifetime.assertCurrent();if(workspaceView===view)return;workspaceView=view;for(const listener of workspaceListeners)listener();}
export function syncNativePreviewWorkspace(active:boolean){if(active&&previewReturnView===null){previewReturnView=workspaceView;openNativeWorkspaceView('preview');}else if(!active&&previewReturnView!==null){const restore=previewReturnView;previewReturnView=null;openNativeWorkspaceView(restore);}}
const workspaceListeners=new Set<()=>void>();
export function nativeWorkspaceSnapshot(){return workspacePanels;}
export function subscribeNativeWorkspace(listener:()=>void){nativeHost().lifetime.assertCurrent();workspaceListeners.add(listener);return()=>{workspaceListeners.delete(listener);};}
export function openNativeAddon(payload:unknown):{panel:NativeAddonPanel}{
 const h=nativeHost();h.lifetime.assertCurrent();
 if(!h.workspaceAddons)throw Error('当前工作台未启用扩展面板。');
 if(!payload||typeof payload!=='object'||Array.isArray(payload)||Object.keys(payload).length!==1||!Object.hasOwn(payload,'panel'))throw Error('请选择真实工作区面板。');
 const panel=(payload as {panel:unknown}).panel;
 if(panel!=='assets'&&panel!=='transcript'&&panel!=='director'&&panel!=='properties')throw Error('此工作区面板不存在。');
 const [left,right]=workspacePanels.split(':');
 const next=panel==='assets'||panel==='transcript'?`${panel}:${right}`:`${left}:${panel}`;
 const view=panel==='assets'||panel==='transcript'?'left':'right';
 if(next!==workspacePanels||workspaceView!==view){workspacePanels=next;workspaceView=view;for(const listener of workspaceListeners)listener();}
 return {panel};
}
export function syncNativeInteractivity(h:NativeHost,exportLocked:boolean){
 const coreDisabled=h.disabled||exportLocked||Boolean(h.previewActive),hidden=h.visible===false;
 h.container.inert=hidden||(!h.workspaceAddons&&coreDisabled);
 h.portalContainer.inert=hidden||coreDisabled;
 if(h.workspaceAddons)for(const panel of h.container.querySelectorAll<HTMLElement>('[data-native-core-panel]'))panel.inert=hidden||coreDisabled||Boolean(panel.hidden)||panel.getAttribute?.("data-native-addon-covered")==="true";
}
