import {test,expect,mock} from 'bun:test';
import {createCanvas} from '@napi-rs/canvas';
Object.assign(globalThis,{location:{href:'http://localhost/'}});
mock.module('@/embedded/native-host',()=>({currentNativeHost:()=>undefined}));
mock.module('@/wasm',()=>({TICKS_PER_SECOND:120000,ZERO_MEDIA_TIME:0,...Object.fromEntries(['addMediaTime','subMediaTime','maxMediaTime','minMediaTime','clampMediaTime','roundFrameTime','roundFrameTicks','snapSeekMediaTime','lastFrameMediaTime','parseMediaTimecode'].map(name=>[name,(v:any)=>v.time??v.ticks??0])),roundMediaTime:({time}:any)=>Math.round(time),mediaTimeToSeconds:({time}:any)=>time/120000,mediaTimeFromSeconds:({seconds}:any)=>Math.round(seconds*120000),mediaTime:({ticks}:any)=>ticks}));
let cacheFrames:any[]=[];
class PixelSink {
 private pool:any[]=[];private poolIndex=0;
 constructor(private track:{input:PixelInput},private options:{poolSize?:number}={}){}
 async *canvases(time:number){
  let index=0;for(let i=0;i<cacheFrames.length;i++)if(cacheFrames[i].timestamp<=time)index=i;
  for(;index<cacheFrames.length;index++){
   if(this.track.input.disposed)throw Error('Input disposed');
   const frame=cacheFrames[index],size=this.options.poolSize??0;let canvas;
   if(size){const slot=this.poolIndex++%size;canvas=this.pool[slot]??(this.pool[slot]=createCanvas(2,2));}else canvas=createCanvas(2,2);
   const context=canvas.getContext('2d');context.fillStyle=`rgb(${index},0,0)`;context.fillRect(0,0,2,2);yield{...frame,canvas};
  }
 }
}
class PixelInput {disposed=false;async getPrimaryVideoTrack(){return{input:this,canDecode:async()=>true};}dispose(){this.disposed=true;}}
mock.module('mediabunny',()=>({Input:PixelInput,CanvasSink:PixelSink,BlobSource:class{},ALL_FORMATS:[]}));
const {VideoCache}=await import('@/services/video-cache/service');
const cacheFrame=(index:number)=>({timestamp:index/24,duration:1/24});
// 真resolveRenderTree并发同素材节点 + 可读像素canvas；仅解码端口为fixture。
// CanvasSink池语义核于锁定mediabunny/src/media-sink.ts：0禁池、正整数环形复用；未签GPU/MP4。
const {resolveRenderTree}=await import('@/services/renderer/resolve');
const {VideoNode}=await import('@/services/renderer/nodes/video-node');
const {BaseNode}=await import('@/services/renderer/nodes/base-node');
test('T1274 private export同asset不同sourceTime多节点保留各自真实canvas像素，不被后续迭代池覆写',async()=>{
 cacheFrames=Array.from({length:74},(_,index)=>cacheFrame(index));
 const cache=new VideoCache({exact:true}),file=new File(['canvas-port-not-mp4'],'pixels.bin');
 const params={url:'fixture',file,mediaId:'same-asset',duration:120000,timeOffset:0,trimEnd:0,transform:{position:{x:0,y:0},scaleX:1,scaleY:1,rotate:0},opacity:1};
 const first=new VideoNode({...params,trimStart:120000}),second=new VideoNode({...params,trimStart:240000}),root=new BaseNode();root.add(first).add(second);
 const red=(source:any)=>source.getContext('2d').getImageData(0,0,1,1).data[0];
 try{
  await resolveRenderTree({node:root,renderer:{videoCache:cache,width:2,height:2} as any,time:0});
  expect(first.resolved).not.toBeNull();expect(second.resolved).not.toBeNull();
  expect(red(first.resolved!.source)).toBe(24);expect(red(second.resolved!.source)).toBe(48);
  expect(first.resolved!.source).not.toBe(second.resolved!.source);
  await cache.getFrameAt({mediaId:'same-asset',file,time:3});
  expect(red(first.resolved!.source)).toBe(24);expect(red(second.resolved!.source)).toBe(48);
 }finally{cache.clearAll();await cache.drain();}
});
