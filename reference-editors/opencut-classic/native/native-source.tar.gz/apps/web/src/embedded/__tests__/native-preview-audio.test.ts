import { test, expect, mock } from "bun:test";
let closed = 0;
class Context {
  sampleRate = 44100;
  async close() {
    closed++;
  }
}
Object.assign(globalThis, { window: { AudioContext: Context } });
mock.module("@/wasm", () => ({ TICKS_PER_SECOND: 120000 }));
mock.module("@/retime", () => ({
  getSourceTimeAtClipTime: () => 0,
  renderRetimedBuffer: async () => null,
}));
mock.module("@/retime/rate", () => ({ shouldMaintainPitch: () => false }));
mock.module("@/timeline", () => ({ canTrackHaveAudio: () => false }));
mock.module("@/media/audio-mastering", () => ({
  applyAudioMasteringToBuffer: async ({ audioBuffer }: any) => audioBuffer,
}));
mock.module("@/timeline/audio-state", () => ({
  hasAnimatedVolume: () => false,
  isElementMuted: () => false,
  resolveEffectiveAudioGain: () => 1,
}));
mock.module("@/timeline/audio-separation", () => ({
  doesElementHaveEnabledAudio: () => false,
}));
mock.module("@/timeline/element-utils", () => ({
  canElementHaveAudio: () => false,
  hasMediaId: () => false,
}));
mock.module("@/media/media-utils", () => ({ mediaSupportsAudio: () => false }));
const { createTimelineAudioBuffer } = await import("@/media/audio");
const tracks = {
  main: { type: "video", elements: [] },
  overlay: [],
  audio: [],
} as any;
test("空音轨导出关闭自行创建的临时AudioContext，真实空保持null", async () => {
  closed = 0;
  expect(
    await createTimelineAudioBuffer({
      tracks,
      mediaAssets: [],
      duration: 120000,
    }),
  ).toBeNull();
  expect(closed).toBe(1);
});
test("调用方的AudioContext不由导出关闭", async () => {
  closed = 0;
  expect(
    await createTimelineAudioBuffer({
      tracks,
      mediaAssets: [],
      duration: 120000,
      audioContext: new Context() as any,
    }),
  ).toBeNull();
  expect(closed).toBe(0);
});
test("原取消回调已取消时不分配context，不进入音频准备", async () => {
  closed = 0;
  await expect(
    createTimelineAudioBuffer({
      tracks,
      mediaAssets: [],
      duration: 120000,
      onCancel: () => true,
    } as any),
  ).rejects.toMatchObject({ name: "AbortError" });
  expect(closed).toBe(0);
});
