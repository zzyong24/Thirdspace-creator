import { useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { nativeHost, syncNativeInteractivity } from "./native-host";
import { isExportLocked } from "./edit-lock";
/** 只投影宿主明确启用的候选DOM；不选择候选、不改变工程或播放状态。 */
export function PreviewWorkspace({ children }: { children: ReactNode }) {
  const [active, setActive] = useState(false),
    slot = useRef<HTMLSlotElement>(null);
  const host = nativeHost();
  useLayoutEffect(() => {
    const outlet = slot.current;
    if (!outlet || host.lifetime.signal.aborted) return;
    let live = true;
    const observer = new MutationObserver(() => sync());
    const sync = () => {
      if (!live || host.lifetime.signal.aborted) return;
      const assigned = outlet.assignedElements();
      observer.disconnect();
      for (const element of assigned)
        observer.observe(element, {
          attributes: true,
          childList: true,
          subtree: true,
          attributeFilter: [
            "data-creatoros-addon",
            "data-creatoros-preview-active",
            "hidden",
          ],
        });
      const next = assigned.some(
        (element) =>
          element.getAttribute("data-creatoros-addon") === "preview" &&
          element.getAttribute("data-creatoros-preview-active") === "true" &&
          !element.hasAttribute("hidden") &&
          element.childElementCount > 0,
      );
      host.previewActive = next;
      syncNativeInteractivity(host, isExportLocked());
      setActive(next);
    };
    const cleanup = () => {
      if (!live) return;
      live = false;
      observer.disconnect();
      host.previewActive = false;
      if (!host.lifetime.signal.aborted)
        syncNativeInteractivity(host, isExportLocked());
      outlet.removeEventListener("slotchange", sync);
      host.lifetime.signal.removeEventListener("abort", cleanup);
    };
    outlet.addEventListener("slotchange", sync);
    host.lifetime.signal.addEventListener("abort", cleanup, { once: true });
    sync();
    return cleanup;
  }, [host]);
  useLayoutEffect(() => {
    if (!host.lifetime.signal.aborted)
      syncNativeInteractivity(host, isExportLocked());
  }, [active, host]);
  return (
    <div className="native-workspace-preview">
      <div
        data-native-core-panel
        data-native-addon-covered={active ? "true" : undefined}
        aria-hidden={active ? true : undefined}
        inert={active}
        className="native-workspace-preview-core"
      >
        {children}
      </div>
      <div
        className="native-workspace-preview-projection"
        role="region"
        aria-label="候选画面比较"
        hidden={!active}
        inert={!active}
      >
        <slot ref={slot} name="creatoros-preview" />
      </div>
    </div>
  );
}
