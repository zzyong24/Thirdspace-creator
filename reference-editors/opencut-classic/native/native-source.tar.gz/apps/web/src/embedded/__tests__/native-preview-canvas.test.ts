import { test, expect, mock } from "bun:test";
// 真CanvasRenderer机械隔离，用渲染端口模拟WASM，不代表GPU画面验收。
let compositorFrame = 0,
  selectedFrame = 0,
  disposed = 0;
class Canvas {
  width = 10;
  height = 10;
  frame = 0;
  getContext() {
    return {
      drawImage: (source: Canvas) => {
        this.frame = source.frame;
      },
    };
  }
  remove() {
    disposed++;
  }
}
const shared = new Canvas();
Object.assign(globalThis, { document: { createElement: () => new Canvas() } });
mock.module("@/embedded/native-host", () => ({
  nativeHost: () => ({
    lifetime: { assertCurrent() {}, run: async (task: any) => task() },
  }),
}));
mock.module("@/services/video-cache/service", () => ({ videoCache: {} }));
mock.module("@/services/renderer/canvas-utils", () => ({
  createCanvasSurface: () => ({ canvas: new Canvas(), context: {} }),
}));
mock.module("@/services/renderer/compositor/frame-descriptor", () => ({
  buildFrameDescriptor: async () => ({
    frame: { id: selectedFrame },
    textures: [],
  }),
}));
mock.module("@/services/renderer/resolve", () => ({
  resolveRenderTree: async ({ time }: any) => {
    selectedFrame = time;
  },
}));
mock.module("@/services/renderer/compositor/wasm-compositor", () => ({
  wasmCompositor: {
    ensureInitialized() {},
    getCanvas: () => shared,
    syncTextures() {},
    render: (frame: any) => {
      compositorFrame = frame.id;
      shared.frame = compositorFrame;
    },
  },
}));
mock.module("@/diagnostics/render-perf", () => ({
  measureSpanAsync: async ({ fn }: any) => fn(),
  measureSpanSync: ({ fn }: any) => fn(),
  onRenderPerfFrameComplete() {},
}));
const { CanvasRenderer } = await import("@/services/renderer/canvas-renderer");
test("活动预览和候选编码输出画布实例不同，后续render不覆盖前一实例完成帧", async () => {
  const a = new CanvasRenderer({
      width: 10,
      height: 10,
      fps: { numerator: 24, denominator: 1 },
    }),
    b = new CanvasRenderer({
      width: 10,
      height: 10,
      fps: { numerator: 30, denominator: 1 },
    });
  const ac = a.getOutputCanvas() as any,
    bc = b.getOutputCanvas() as any;
  expect(ac).not.toBe(bc);
  expect(ac).not.toBe(shared);
  await a.render({ node: {} as any, time: 17 });
  expect(ac.frame).toBe(17);
  await b.render({ node: {} as any, time: 240017 });
  expect(bc.frame).toBe(240017);
  expect(ac.frame).toBe(17);
});
