import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";
import { AssetsPanel } from "@/components/editor/panels/assets";
import { PropertiesPanel } from "@/components/editor/panels/properties";
import { Timeline } from "@/timeline/components";
import { PreviewPanel } from "@/preview/components";
import { usePanelStore } from "@/editor/panel-store";
import { usePasteMedia } from "@/media/use-paste-media";
import {
  useMemo,
  useLayoutEffect,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import {
  nativeWorkspaceViewSnapshot,
  subscribeNativeWorkspace,
  openNativeWorkspaceView,
  currentNativeHost,
  syncNativeInteractivity,
  type NativeWorkspaceView,
} from "./native-host";
import { useEditor } from "@/editor/use-editor";
import { isExportLocked } from "./edit-lock";
import {
  createPreviewOverlayControl,
  isPreviewOverlayVisible,
  mergePreviewOverlaySources,
} from "@/preview/overlays";
import { usePreviewStore } from "@/preview/preview-store";
import { getGuidePreviewOverlaySource } from "@/guides";
import {
  bookmarkNotesPreviewOverlay,
  getBookmarkPreviewOverlaySource,
} from "@/timeline/bookmarks/index";
import { WorkspacePanel } from "./workspace-panel";
import { PreviewWorkspace } from "./preview-workspace";
export function EditorLayout({
  workspaceAddons = false,
}: { workspaceAddons?: boolean } = {}) {
  usePasteMedia();
  const workspaceRef = useRef<HTMLDivElement>(null);
  const [layout, setLayout] = useState<"wide" | "compact" | "single">("wide");
  const [previewSpace, setPreviewSpace] = useState({
    width: 0,
    viewportHeight: 0,
  });
  const canvasSize = useEditor(
    (editor) => editor.project.getActive()?.settings.canvasSize,
  );
  const view = useSyncExternalStore(
    subscribeNativeWorkspace,
    nativeWorkspaceViewSnapshot,
    nativeWorkspaceViewSnapshot,
  );
  useLayoutEffect(() => {
    if (!workspaceAddons || !workspaceRef.current) return;
    const element = workspaceRef.current;
    // 使用布局CSS像素；getBoundingClientRect包含CSS zoom，不能决定断点。
    const update = (width: number) => {
      if (width > 0) {
        setLayout(width < 700 ? "single" : width < 1100 ? "compact" : "wide");
        // 只用屏幕/CSS宽度比换算可视高度；断点仍只读CSS像素。
        const scale = element.getBoundingClientRect().width / width || 1;
        setPreviewSpace({ width, viewportHeight: window.innerHeight / scale });
      }
    };
    update(element.clientWidth);
    const observer = new ResizeObserver((entries) => {
      const entry = entries.find((entry) => entry.target === element);
      update(entry?.contentRect.width ?? element.clientWidth);
    });
    observer.observe(element);
    const resizeViewport = () => update(element.clientWidth);
    window.addEventListener("resize", resizeViewport);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", resizeViewport);
    };
  }, [workspaceAddons]);
  // hidden随布局提交后，复用同一交互守卫恢复可见面板；不绕过候选/导出/宿主禁用锁。
  useLayoutEffect(() => {
    const host = currentNativeHost();
    if (workspaceAddons && host && !host.lifetime.signal.aborted) {
      syncNativeInteractivity(host, isExportLocked());
    }
  }, [workspaceAddons, layout, view]);
  const single = workspaceAddons && layout === "single",
    compact = workspaceAddons && layout === "compact";
  const leftVisible = !workspaceAddons || layout === "wide" || view === "left";
  const rightVisible =
    !workspaceAddons || layout === "wide" || view === "right";
  const previewVisible = !single || view === "preview";
  const mainVisible = !single || view !== "timeline";
  const timelineVisible = !single || view === "timeline";
  const previewRatio =
    canvasSize && canvasSize.width > 0 && canvasSize.height > 0
      ? canvasSize.width / canvasSize.height
      : 1;
  // 32px为两侧面板与画布原有留白，72px保留原播放工具栏与垂直留白。
  // 只缩小展示容器；实际工程画幅与渲染canvas保持原值。
  const fittedPreviewHeight =
    Math.min(
      Math.max(0, previewSpace.width - 32) / previewRatio,
      previewSpace.viewportHeight * 0.42,
    ) + 72;
  const views: [NativeWorkspaceView, string][] = [
    ["left", "素材/转录"],
    ["preview", "画面"],
    ["timeline", "时间轴"],
    ["right", "编导/属性"],
  ];
  const { panels, setPanel } = usePanelStore();
  const activeScene = useEditor((editor) =>
    editor.scenes.getActiveSceneOrNull(),
  );
  const currentTime = useEditor((editor) => editor.playback.getCurrentTime());
  const activeGuide = usePreviewStore((state) => state.activeGuide);
  const overlays = usePreviewStore((state) => state.overlays);
  const setOverlayVisibility = usePreviewStore(
    (state) => state.setOverlayVisibility,
  );
  const showBookmarkNotes = isPreviewOverlayVisible({
    overlay: bookmarkNotesPreviewOverlay,
    overlays,
  });

  const overlaySource = useMemo(
    () =>
      mergePreviewOverlaySources({
        sources: [
          getGuidePreviewOverlaySource({
            guideId: activeGuide,
          }),
          activeScene
            ? getBookmarkPreviewOverlaySource({
                bookmarks: activeScene.bookmarks,
                time: currentTime,
                isVisible: showBookmarkNotes,
              })
            : {
                definitions: [bookmarkNotesPreviewOverlay],
                instances: [],
              },
        ],
      }),
    [activeGuide, activeScene, currentTime, showBookmarkNotes],
  );

  const overlayControls = useMemo(
    () =>
      overlaySource.definitions.map((overlay) =>
        createPreviewOverlayControl({ overlay, overlays }),
      ),
    [overlaySource.definitions, overlays],
  );

  return (
    <div
      ref={workspaceRef}
      className={workspaceAddons ? "native-responsive-workspace" : "size-full"}
      data-workspace-layout={workspaceAddons ? layout : undefined}
      data-workspace-view={view}
    >
      {workspaceAddons && (
        <nav
          className="native-workspace-navigation"
          aria-label="剪辑工作区面板"
        >
          {views.map(([target, label]) => (
            <button
              type="button"
              key={target}
              aria-pressed={view === target}
              onClick={() => openNativeWorkspaceView(target)}
            >
              {label}
            </button>
          ))}
        </nav>
      )}
      <ResizablePanelGroup
        direction="vertical"
        className="size-full gap-[0.18rem] native-workspace-vertical"
        onLayout={(sizes) => {
          if (single) return;
          setPanel({
            panel: "mainContent",
            size: sizes[0] ?? panels.mainContent,
          });
          setPanel({
            panel: "timeline",
            size: sizes[1] ?? panels.timeline,
          });
        }}
      >
        <ResizablePanel
          defaultSize={panels.mainContent}
          minSize={30}
          maxSize={85}
          className="min-h-0 native-workspace-main"
          hidden={!mainVisible}
          inert={!mainVisible}
          style={{
            display: mainVisible ? undefined : "none",
            ...(single
              ? view === "preview" && previewSpace.width > 0
                ? {
                    flexGrow: 0,
                    flexShrink: 0,
                    flexBasis: fittedPreviewHeight,
                    maxHeight: "100%",
                  }
                : { flexGrow: 1, flexShrink: 1, flexBasis: 0 }
              : {}),
          }}
        >
          <ResizablePanelGroup
            direction="horizontal"
            className="size-full gap-[0.19rem] px-3 native-workspace-horizontal"
            onLayout={(sizes) => {
              if (workspaceAddons && layout !== "wide") return;
              setPanel({ panel: "tools", size: sizes[0] ?? panels.tools });
              setPanel({ panel: "preview", size: sizes[1] ?? panels.preview });
              setPanel({
                panel: "properties",
                size: sizes[2] ?? panels.properties,
              });
            }}
          >
            <ResizablePanel
              defaultSize={panels.tools}
              minSize={15}
              maxSize={40}
              className="min-w-0 native-workspace-left"
              hidden={!leftVisible}
              inert={!leftVisible}
              style={{
                display: leftVisible ? undefined : "none",
                ...(single
                  ? { flexGrow: 1, flexShrink: 1, flexBasis: 0 }
                  : compact
                    ? { flexGrow: 0, flexShrink: 0, flexBasis: 340 }
                    : {}),
              }}
            >
              {workspaceAddons ? (
                <WorkspacePanel side="left">
                  <AssetsPanel />
                </WorkspacePanel>
              ) : (
                <AssetsPanel />
              )}
            </ResizablePanel>

            <ResizableHandle
              withHandle
              hidden={workspaceAddons && layout !== "wide"}
              disabled={workspaceAddons && layout !== "wide"}
              style={{
                display:
                  workspaceAddons && layout !== "wide" ? "none" : undefined,
              }}
            />

            <ResizablePanel
              defaultSize={panels.preview}
              minSize={30}
              data-native-core-panel={workspaceAddons ? undefined : true}
              className="min-h-0 min-w-0 flex-1 native-workspace-center"
              hidden={!previewVisible}
              inert={!previewVisible}
              style={{
                display: previewVisible ? undefined : "none",
                ...(single || compact
                  ? { flexGrow: 1, flexShrink: 1, flexBasis: 0 }
                  : {}),
              }}
            >
              {workspaceAddons ? (
                <PreviewWorkspace>
                  <PreviewPanel
                    overlayControls={overlayControls}
                    overlayInstances={overlaySource.instances}
                    onOverlayVisibilityChange={setOverlayVisibility}
                  />
                </PreviewWorkspace>
              ) : (
                <PreviewPanel
                  overlayControls={overlayControls}
                  overlayInstances={overlaySource.instances}
                  onOverlayVisibilityChange={setOverlayVisibility}
                />
              )}
            </ResizablePanel>

            <ResizableHandle
              withHandle
              hidden={workspaceAddons && layout !== "wide"}
              disabled={workspaceAddons && layout !== "wide"}
              style={{
                display:
                  workspaceAddons && layout !== "wide" ? "none" : undefined,
              }}
            />

            <ResizablePanel
              defaultSize={panels.properties}
              minSize={15}
              maxSize={40}
              className="min-w-0 native-workspace-right"
              hidden={!rightVisible}
              inert={!rightVisible}
              style={{
                display: rightVisible ? undefined : "none",
                ...(single
                  ? { flexGrow: 1, flexShrink: 1, flexBasis: 0 }
                  : compact
                    ? { flexGrow: 0, flexShrink: 0, flexBasis: 340 }
                    : {}),
              }}
            >
              {workspaceAddons ? (
                <WorkspacePanel side="right">
                  <PropertiesPanel />
                </WorkspacePanel>
              ) : (
                <PropertiesPanel />
              )}
            </ResizablePanel>
          </ResizablePanelGroup>
        </ResizablePanel>

        <ResizableHandle
          withHandle
          hidden={single}
          disabled={single}
          style={{ display: single ? "none" : undefined }}
        />

        <ResizablePanel
          defaultSize={panels.timeline}
          minSize={15}
          maxSize={70}
          data-native-core-panel
          className="min-h-0 px-3 pb-3 native-workspace-timeline"
          hidden={!timelineVisible}
          style={{
            display: timelineVisible ? undefined : "none",
            ...(single ? { flexGrow: 1, flexShrink: 1, flexBasis: 0 } : {}),
            ...(single ? { overflow: "auto" } : {}),
          }}
        >
          <Timeline />
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}
