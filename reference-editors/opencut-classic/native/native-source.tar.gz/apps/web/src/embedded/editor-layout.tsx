import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";
import { AssetsPanel } from "@/components/editor/panels/assets";
import { PropertiesPanel } from "@/components/editor/panels/properties";
import { Timeline } from "@/timeline/components";
import { PreviewPanel } from "@/preview/components";
import { usePanelStore } from "@/editor/panel-store";
import { usePasteMedia } from "@/media/use-paste-media";
import {
  useMemo,
  useLayoutEffect,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import {
  nativeWorkspaceViewSnapshot,
  subscribeNativeWorkspace,
  openNativeWorkspaceView,
  type NativeWorkspaceView,
} from "./native-host";
import { useEditor } from "@/editor/use-editor";
import {
  createPreviewOverlayControl,
  isPreviewOverlayVisible,
  mergePreviewOverlaySources,
} from "@/preview/overlays";
import { usePreviewStore } from "@/preview/preview-store";
import { getGuidePreviewOverlaySource } from "@/guides";
import {
  bookmarkNotesPreviewOverlay,
  getBookmarkPreviewOverlaySource,
} from "@/timeline/bookmarks/index";
import { WorkspacePanel } from "./workspace-panel";
import { PreviewWorkspace } from "./preview-workspace";
export function EditorLayout({
  workspaceAddons = false,
}: { workspaceAddons?: boolean } = {}) {
  usePasteMedia();
  const workspaceRef = useRef<HTMLDivElement>(null);
  const [layout, setLayout] = useState<"wide" | "compact" | "single">("wide");
  const view = useSyncExternalStore(
    subscribeNativeWorkspace,
    nativeWorkspaceViewSnapshot,
    nativeWorkspaceViewSnapshot,
  );
  useLayoutEffect(() => {
    if (!workspaceAddons || !workspaceRef.current) return;
    const element = workspaceRef.current;
    const update = () => {
      const width = element.getBoundingClientRect().width;
      if (width > 0)
        setLayout(width < 700 ? "single" : width < 1100 ? "compact" : "wide");
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(element);
    return () => observer.disconnect();
  }, [workspaceAddons]);
  const single = workspaceAddons && layout === "single",
    compact = workspaceAddons && layout === "compact";
  const leftVisible = !workspaceAddons || layout === "wide" || view === "left";
  const rightVisible =
    !workspaceAddons || layout === "wide" || view === "right";
  const previewVisible = !single || view === "preview";
  const mainVisible = !single || view !== "timeline";
  const timelineVisible = !single || view === "timeline";
  const views: [NativeWorkspaceView, string][] = [
    ["left", "素材/转录"],
    ["preview", "画面"],
    ["timeline", "时间轴"],
    ["right", "编导/属性"],
  ];
  const { panels, setPanel } = usePanelStore();
  const activeScene = useEditor((editor) =>
    editor.scenes.getActiveSceneOrNull(),
  );
  const currentTime = useEditor((editor) => editor.playback.getCurrentTime());
  const activeGuide = usePreviewStore((state) => state.activeGuide);
  const overlays = usePreviewStore((state) => state.overlays);
  const setOverlayVisibility = usePreviewStore(
    (state) => state.setOverlayVisibility,
  );
  const showBookmarkNotes = isPreviewOverlayVisible({
    overlay: bookmarkNotesPreviewOverlay,
    overlays,
  });

  const overlaySource = useMemo(
    () =>
      mergePreviewOverlaySources({
        sources: [
          getGuidePreviewOverlaySource({
            guideId: activeGuide,
          }),
          activeScene
            ? getBookmarkPreviewOverlaySource({
                bookmarks: activeScene.bookmarks,
                time: currentTime,
                isVisible: showBookmarkNotes,
              })
            : {
                definitions: [bookmarkNotesPreviewOverlay],
                instances: [],
              },
        ],
      }),
    [activeGuide, activeScene, currentTime, showBookmarkNotes],
  );

  const overlayControls = useMemo(
    () =>
      overlaySource.definitions.map((overlay) =>
        createPreviewOverlayControl({ overlay, overlays }),
      ),
    [overlaySource.definitions, overlays],
  );

  return (
    <div
      ref={workspaceRef}
      className={workspaceAddons ? "native-responsive-workspace" : "size-full"}
      data-workspace-layout={workspaceAddons ? layout : undefined}
      data-workspace-view={view}
    >
      {workspaceAddons && (
        <nav
          className="native-workspace-navigation"
          aria-label="剪辑工作区面板"
        >
          {views.map(([target, label]) => (
            <button
              type="button"
              key={target}
              aria-pressed={view === target}
              onClick={() => openNativeWorkspaceView(target)}
            >
              {label}
            </button>
          ))}
        </nav>
      )}
      <ResizablePanelGroup
        direction="vertical"
        className="size-full gap-[0.18rem] native-workspace-vertical"
        onLayout={(sizes) => {
          setPanel({
            panel: "mainContent",
            size: sizes[0] ?? panels.mainContent,
          });
          setPanel({
            panel: "timeline",
            size: sizes[1] ?? panels.timeline,
          });
        }}
      >
        <ResizablePanel
          defaultSize={panels.mainContent}
          minSize={30}
          maxSize={85}
          className="min-h-0 native-workspace-main"
          hidden={!mainVisible}
          inert={!mainVisible}
          style={{
            display: mainVisible ? undefined : "none",
            flex: single ? "1 1 0" : undefined,
          }}
        >
          <ResizablePanelGroup
            direction="horizontal"
            className="size-full gap-[0.19rem] px-3 native-workspace-horizontal"
            onLayout={(sizes) => {
              setPanel({ panel: "tools", size: sizes[0] ?? panels.tools });
              setPanel({ panel: "preview", size: sizes[1] ?? panels.preview });
              setPanel({
                panel: "properties",
                size: sizes[2] ?? panels.properties,
              });
            }}
          >
            <ResizablePanel
              defaultSize={panels.tools}
              minSize={15}
              maxSize={40}
              className="min-w-0 native-workspace-left"
              hidden={!leftVisible}
              inert={!leftVisible}
              style={{
                display: leftVisible ? undefined : "none",
                flex: single ? "1 1 0" : compact ? "0 0 340px" : undefined,
              }}
            >
              {workspaceAddons ? (
                <WorkspacePanel side="left">
                  <AssetsPanel />
                </WorkspacePanel>
              ) : (
                <AssetsPanel />
              )}
            </ResizablePanel>

            <ResizableHandle
              withHandle
              hidden={workspaceAddons && layout !== "wide"}
              disabled={workspaceAddons && layout !== "wide"}
              style={{
                display:
                  workspaceAddons && layout !== "wide" ? "none" : undefined,
              }}
            />

            <ResizablePanel
              defaultSize={panels.preview}
              minSize={30}
              data-native-core-panel={workspaceAddons ? undefined : true}
              className="min-h-0 min-w-0 flex-1 native-workspace-center"
              hidden={!previewVisible}
              inert={!previewVisible}
              style={{
                display: previewVisible ? undefined : "none",
                flex: single || compact ? "1 1 0" : undefined,
              }}
            >
              {workspaceAddons ? (
                <PreviewWorkspace>
                  <PreviewPanel
                    overlayControls={overlayControls}
                    overlayInstances={overlaySource.instances}
                    onOverlayVisibilityChange={setOverlayVisibility}
                  />
                </PreviewWorkspace>
              ) : (
                <PreviewPanel
                  overlayControls={overlayControls}
                  overlayInstances={overlaySource.instances}
                  onOverlayVisibilityChange={setOverlayVisibility}
                />
              )}
            </ResizablePanel>

            <ResizableHandle
              withHandle
              hidden={workspaceAddons && layout !== "wide"}
              disabled={workspaceAddons && layout !== "wide"}
              style={{
                display:
                  workspaceAddons && layout !== "wide" ? "none" : undefined,
              }}
            />

            <ResizablePanel
              defaultSize={panels.properties}
              minSize={15}
              maxSize={40}
              className="min-w-0 native-workspace-right"
              hidden={!rightVisible}
              inert={!rightVisible}
              style={{
                display: rightVisible ? undefined : "none",
                flex: single ? "1 1 0" : compact ? "0 0 340px" : undefined,
              }}
            >
              {workspaceAddons ? (
                <WorkspacePanel side="right">
                  <PropertiesPanel />
                </WorkspacePanel>
              ) : (
                <PropertiesPanel />
              )}
            </ResizablePanel>
          </ResizablePanelGroup>
        </ResizablePanel>

        <ResizableHandle
          withHandle
          hidden={single}
          disabled={single}
          style={{ display: single ? "none" : undefined }}
        />

        <ResizablePanel
          defaultSize={panels.timeline}
          minSize={15}
          maxSize={70}
          data-native-core-panel
          className="min-h-0 px-3 pb-3 native-workspace-timeline"
          hidden={!timelineVisible}
          style={{
            display: timelineVisible ? undefined : "none",
            flex: single ? "1 1 0" : undefined,
            overflow: single ? "auto" : undefined,
          }}
        >
          <Timeline />
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}
