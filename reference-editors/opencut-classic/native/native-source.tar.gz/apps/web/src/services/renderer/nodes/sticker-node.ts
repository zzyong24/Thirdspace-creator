import { resolveStickerId } from "@/stickers";
import {
  VisualNode,
  type ResolvedVisualSourceNodeState,
  type VisualNodeParams,
} from "./visual-node";

export interface StickerNodeParams extends VisualNodeParams {
  stickerId: string;
  intrinsicWidth?: number;
  intrinsicHeight?: number;
}

interface CachedStickerSource {
  source: HTMLImageElement;
  width: number;
  height: number;
}

const scopedStickerCaches = new WeakMap<
  AbortSignal,
  Map<string, Promise<CachedStickerSource>>
>();
const stickerSourceCache = new Map<string, Promise<CachedStickerSource>>();

export function loadStickerSource({
  stickerId,
  signal,
}: {
  stickerId: string;
  signal?: AbortSignal;
}): Promise<CachedStickerSource> {
  let cache = stickerSourceCache;
  if (signal) {
    cache = scopedStickerCaches.get(signal) ?? new Map();
    scopedStickerCaches.set(signal, cache);
  }
  const cached = cache.get(stickerId);
  if (cached) return cached;

  const promise = (async (): Promise<CachedStickerSource> => {
    const url = resolveStickerId({
      stickerId,
      options: { width: 200, height: 200 },
    });

    const image = new Image();

    await new Promise<void>((resolve, reject) => {
      const abort = () => {
        image.onload = null;
        image.onerror = null;
        image.removeAttribute("src");
        image.remove();
        reject(new DOMException("原候选预览已停止。", "AbortError"));
      };
      signal?.addEventListener("abort", abort, { once: true });
      if (signal?.aborted) {
        abort();
        return;
      }
      image.onload = () => {
        image.onload = null;
        image.onerror = null;
        resolve();
      };
      image.onerror = () =>
        reject(new Error(`Failed to load sticker: ${stickerId}`));
      image.src = url;
    });

    return {
      source: image,
      width: image.naturalWidth,
      height: image.naturalHeight,
    };
  })();

  cache.set(stickerId, promise);
  return promise;
}

export class StickerNode extends VisualNode<
  StickerNodeParams,
  ResolvedVisualSourceNodeState
> {}
