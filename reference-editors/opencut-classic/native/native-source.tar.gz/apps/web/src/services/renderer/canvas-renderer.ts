import { videoCache, type VideoCache } from "@/services/video-cache/service";
import { nativeHost } from "@/embedded/native-host";
import type { FrameRate } from "opencut-wasm";
import type { AnyBaseNode } from "./nodes/base-node";
import { createCanvasSurface } from "./canvas-utils";
import { buildFrameDescriptor } from "./compositor/frame-descriptor";
import { wasmCompositor } from "./compositor/wasm-compositor";
import { resolveRenderTree } from "./resolve";
import {
  measureSpanAsync,
  measureSpanSync,
  onRenderPerfFrameComplete,
} from "@/diagnostics/render-perf";

export type CanvasRendererParams = {
  width: number;
  height: number;
  fps: FrameRate;
  videoCache?: VideoCache;
  signal?: AbortSignal;
};

export class CanvasRenderer {
  canvas: OffscreenCanvas;
  context: OffscreenCanvasRenderingContext2D;
  width: number;
  height: number;
  fps: FrameRate;
  readonly videoCache: VideoCache;
  readonly signal?: AbortSignal;
  private readonly outputCanvas: HTMLCanvasElement;

  constructor({
    width,
    height,
    fps,
    videoCache: cache,
    signal,
  }: CanvasRendererParams) {
    this.width = width;
    this.height = height;
    this.fps = fps;
    this.videoCache = cache ?? videoCache;
    this.signal = signal;
    this.outputCanvas = document.createElement("canvas");
    this.outputCanvas.width = width;
    this.outputCanvas.height = height;

    const surface = createCanvasSurface({ width, height });
    this.canvas = surface.canvas;
    this.context = surface.context;
  }

  getOutputCanvas(): HTMLCanvasElement {
    return this.outputCanvas;
  }
  dispose() {
    this.outputCanvas.width = 1;
    this.outputCanvas.height = 1;
    this.outputCanvas.remove();
    this.canvas.width = 1;
    this.canvas.height = 1;
  }

  setSize({ width, height }: { width: number; height: number }) {
    this.width = width;
    this.height = height;
    this.outputCanvas.width = width;
    this.outputCanvas.height = height;

    const surface = createCanvasSurface({ width, height });
    this.canvas = surface.canvas;
    this.context = surface.context;
  }

  async render({ node, time }: { node: AnyBaseNode; time: number }) {
    const host = nativeHost();
    return host.lifetime.run(async () => {
      await measureSpanAsync({
        name: "resolve",
        fn: () => resolveRenderTree({ node, renderer: this, time }),
      });
      host.lifetime.assertCurrent();
      const { frame, textures } = await measureSpanAsync({
        name: "buildFrame",
        fn: () => buildFrameDescriptor({ node, renderer: this }),
      });
      host.lifetime.assertCurrent();
      wasmCompositor.ensureInitialized({
        width: this.width,
        height: this.height,
      });
      measureSpanSync({
        name: "syncTextures",
        fn: () => wasmCompositor.syncTextures(textures),
      });
      measureSpanSync({
        name: "renderFrame",
        fn: () => {
          wasmCompositor.render(frame);
          // WASM compositor只有一个，完成帧必须在本同步段复制，活动播放与候选编码不共享输出。
          const output = this.outputCanvas.getContext("2d");
          if (!output) throw Error("真实渲染输出画布不可用。");
          output.drawImage(
            wasmCompositor.getCanvas(),
            0,
            0,
            this.width,
            this.height,
          );
        },
      });
    });
  }

  async renderToCanvas({
    node,
    time,
    targetCanvas,
  }: {
    node: AnyBaseNode;
    time: number;
    targetCanvas: HTMLCanvasElement;
  }) {
    await this.render({ node, time });

    const ctx = targetCanvas.getContext("2d");
    if (!ctx) {
      throw new Error("Failed to get target canvas context");
    }

    measureSpanSync({
      name: "drawImage",
      fn: () =>
        ctx.drawImage(
          this.outputCanvas,
          0,
          0,
          targetCanvas.width,
          targetCanvas.height,
        ),
    });
    onRenderPerfFrameComplete();
  }
}
