import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import wasm from "vite-plugin-wasm";
import { resolve } from "node:path";
import { referenceLicenses } from "./reference-license-plugin";
export default defineConfig({base:"./", plugins:[react(),tailwindcss(),wasm(),referenceLicenses()], resolve:{alias:{"@":resolve(__dirname,"src"),"next/image":resolve(__dirname,"src/embedded/next-image.tsx"),"next/link":resolve(__dirname,"src/embedded/next-link.tsx"),"next/navigation":resolve(__dirname,"src/embedded/next-navigation.ts")}},build:{outDir:"embedded-dist",emptyOutDir:true,target:"esnext"},server:{host:"127.0.0.1",port:4192},css:{postcss:{plugins:[]}}});
