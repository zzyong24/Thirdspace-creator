/** 单文档旧单例宿主的明确 lease。新实例只在旧实例完全关闭后取得写权。 */
export class NativeLease {
  private tail: Promise<void> = Promise.resolve()
  private active: (() => Promise<void>) | undefined
  async acquire(dispose: () => Promise<void>, signal?: AbortSignal): Promise<void> {
    const job=this.tail.then(async()=>{
      if(signal?.aborted)throw new Error('挂载已取消')
      if(this.active){const prior=this.active;this.active=undefined;await prior()}
      if(signal?.aborted)throw new Error('挂载已取消')
      this.active=dispose
    })
    this.tail=job.catch(()=>{})
    await job
  }
  release(dispose:()=>Promise<void>){if(this.active===dispose)this.active=undefined}
  async close(){await this.tail;const prior=this.active;this.active=undefined;await prior?.()}
}
