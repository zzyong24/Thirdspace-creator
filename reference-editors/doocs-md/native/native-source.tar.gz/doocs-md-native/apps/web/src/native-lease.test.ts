import {describe,it,expect} from 'vitest'
import {NativeLease} from './native-lease'
describe('Doocs 同文档原生 lease',()=>{
 it('下个实例要等旧 dispose 完成，并串行替换',async()=>{
  const lease=new NativeLease(); const log:string[]=[]; let close!:()=>void
  await lease.acquire(async()=>{log.push('a-close');await new Promise<void>(r=>{close=r});log.push('a-closed')})
  const acquired=lease.acquire(async()=>{log.push('b-close')}).then(()=>log.push('b'))
  await Promise.resolve();await Promise.resolve();expect(log).toEqual(['a-close']);close();await acquired
  expect(log).toEqual(['a-close','a-closed','b']);await lease.close();expect(log[log.length-1]).toBe('b-close')
 })
 it('被取消的等待挂载不取得新 lease',async()=>{
  const lease=new NativeLease();const cancel=new AbortController();cancel.abort()
  await expect(lease.acquire(async()=>{},cancel.signal)).rejects.toThrow('已取消')
 })
})
