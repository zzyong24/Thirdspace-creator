import {nativeHost} from '@/embedded/native-host';
import {stopped} from '@/embedded/native-lifecycle';
import {currentEditEpoch,currentEditSignal,assertImportEpoch,stampImportedAsset} from '@/embedded/edit-lock';
import { toast } from "sonner";
import { registerMediaFile } from "@/embedded/media-registration";
import { getMediaTypeFromFile } from "@/media/media-utils";
import { formatStorageBytes } from "@/services/storage/quota";
import { storageService } from "@/services/storage/service";
import type { MediaAsset } from "@/media/types";
import { readVideoFile } from "./mediabunny";
import type { VideoFileData } from "./mediabunny";
import { renderThumbnailDataUrl } from "./thumbnail";

export interface ProcessedMediaAsset extends Omit<MediaAsset, "id"> {}

const getUnsupportedVideoDescription = ({
	codec,
}: {
	codec: VideoFileData["codec"];
}): string => {
	const codecLabel = codec ? codec.toUpperCase() : "this video codec";

	return codec === "hevc"
		? `${codecLabel} cannot be decoded in this browser, so this clip may not preview correctly. Convert it to H.264 MP4 or try importing it in Safari.`
		: `${codecLabel} cannot be decoded in this browser, so this clip may not preview correctly. Convert it to H.264 MP4 and reimport it.`;
};

const getStorageLimitDescription = ({
	fileSize,
	availableBytes,
}: {
	fileSize: number;
	availableBytes: number | null;
}): string => {
	const fileSizeLabel = formatStorageBytes({ bytes: fileSize });

	if (availableBytes === null) {
		return `File size is ${fileSizeLabel}.`;
	}

	return `File size is ${fileSizeLabel}, but only ${formatStorageBytes({
		bytes: availableBytes,
	})} is safely available in browser storage.`;
};

async function generateImageThumbnail({
	imageFile,signal,
}: {
	imageFile: File;signal:AbortSignal;
}): Promise<{ thumbnailUrl: string; width: number; height: number }> {
	return new Promise((resolve, reject) => {
		const image = new window.Image();
		const objectUrl = URL.createObjectURL(imageFile);
        const cleanup=()=>{signal.removeEventListener('abort',abort);image.onload=null;image.onerror=null;image.removeAttribute('src');URL.revokeObjectURL(objectUrl);image.remove();};
        const abort=()=>{cleanup();reject(stopped());};signal.addEventListener('abort',abort,{once:true});if(signal.aborted){abort();return;}

		image.onload = () => {
			try {
				const thumbnailUrl = renderThumbnailDataUrl({
					width: image.naturalWidth,
					height: image.naturalHeight,
					draw: ({ context, width, height }) => {
						context.drawImage(image, 0, 0, width, height);
					},
				});
				resolve({
					thumbnailUrl,
					width: image.naturalWidth,
					height: image.naturalHeight,
				});
			} catch (error) {
				reject(
					error instanceof Error ? error : new Error("Could not render image"),
				);
			} finally {
				cleanup();
			}
		};

		image.onerror = () => {cleanup();reject(new Error("Could not load image"));};

		image.src = objectUrl;
	});
}

let activeImports=0;
export function processMediaAssets(options:{files:FileList|File[];onProgress?:({progress}:{progress:number})=>void;signal?:AbortSignal;onProcessed?:(asset:ProcessedMediaAsset)=>Promise<void>}){
 const host=nativeHost(),signal=AbortSignal.any([host.lifetime.signal,currentEditSignal(),...(options.signal?[options.signal]:[])]);
 activeImports++;host.onImportActivity?.(activeImports);
 return host.lifetime.run(()=>processCurrentMediaAssets({...options,signal},host)).finally(()=>{activeImports--;if(!host.lifetime.signal.aborted)host.onImportActivity?.(activeImports);});
}
async function processCurrentMediaAssets({
 files,
 onProgress,signal,onProcessed,
}: {
	files: FileList | File[];
	onProgress?: ({ progress }: { progress: number }) => void;signal:AbortSignal;onProcessed?:(asset:ProcessedMediaAsset)=>Promise<void>;
},host:ReturnType<typeof nativeHost>): Promise<ProcessedMediaAsset[]> {
 const check=()=>{host.lifetime.assertCurrent();if(signal.aborted)throw stopped();};check();
	const capturedEpoch=currentEditEpoch();
	check();assertImportEpoch(capturedEpoch);
	const fileArray = Array.from(files);
	const processedAssets: ProcessedMediaAsset[] = [];
 const adopted=new Set<ProcessedMediaAsset>();

	const total = fileArray.length;
	let completed = 0;

	for (const file of fileArray) {
		check();const fileType = getMediaTypeFromFile({ file });

		if (!fileType) {
			toast.error(`Unsupported file type: ${file.name}`);
			continue;
		}

		const storageCheck = await storageService.canStoreFile({
			size: file.size,
		});

		check();if (!storageCheck.canStore) {
			toast.error(`Not enough browser storage for ${file.name}`, {
				description: getStorageLimitDescription({
					fileSize: file.size,
					availableBytes: storageCheck.availableBytes,
				}),
			});
			continue;
		}

		const url = URL.createObjectURL(file);
		let thumbnailUrl: string | undefined;
		let duration: number | undefined;
		let width: number | undefined;
		let height: number | undefined;
		let fps: number | undefined;
		let hasAudio: boolean | undefined;

        const registration=registerMediaFile(file,{signal}).then(id=>({id}),error=>({error}));
		try {
			if (fileType === "image") {
				const result = await generateImageThumbnail({ imageFile: file,signal });
				thumbnailUrl = result.thumbnailUrl;
				width = result.width;
				height = result.height;
			} else if (fileType === "video") {
				try {
					const videoData = await readVideoFile({ file,signal,thumbnail:false });
					duration = videoData.duration;
					width = videoData.width;
					height = videoData.height;
					fps = Number.isFinite(videoData.fps)
						? Math.round(videoData.fps)
						: undefined;
					hasAudio = videoData.hasAudio;
					thumbnailUrl = videoData.thumbnailUrl ?? undefined;

					if (!videoData.canDecode) {
						toast.error(`Can't preview ${file.name}`, {
							description: getUnsupportedVideoDescription({
								codec: videoData.codec,
							}),
						});
					}
				} catch (error) {
                    check();
					const message =
						error instanceof Error
							? error.message
							: "Could not process video";

					toast.error(`Couldn't process ${file.name}`, {
						description: message,
					});
				}
			} else if (fileType === "audio") {
				duration = await getMediaDuration({ file,signal });
			}

			check();assertImportEpoch(capturedEpoch);
			const receipt=await registration;if("error" in receipt)throw receipt.error;
			check();assertImportEpoch(capturedEpoch);
			const processedAsset:ProcessedMediaAsset={
				name: file.name,
				type: fileType,
				file,
				url,
				thumbnailUrl,
				duration,
				width,
				height,
				fps,
				hasAudio,
			};
			stampImportedAsset(processedAsset,capturedEpoch);
			processedAssets.push(processedAsset);
            if(onProcessed){await onProcessed(processedAsset);adopted.add(processedAsset);check();assertImportEpoch(capturedEpoch);}

			await new Promise((resolve) => setTimeout(resolve, 0));check();

			completed += 1;
			if (onProgress) {
				const percent = Math.round((completed / total) * 100);
				onProgress({ progress: percent });
			}
		} catch (error) {
            if(!processedAssets.some(asset=>asset.url===url&&adopted.has(asset)))URL.revokeObjectURL(url);if(signal.aborted||host.lifetime.signal.aborted){for(const asset of processedAssets)if(asset.url&&!adopted.has(asset))URL.revokeObjectURL(asset.url);throw stopped();}
			console.error("Error processing file:", file.name, error);
			toast.error(`Failed to process ${file.name}`);
			URL.revokeObjectURL(url);
		}
	}

	check();assertImportEpoch(capturedEpoch);
	return processedAssets;
}

const getMediaDuration = ({ file,signal }: { file: File;signal:AbortSignal }): Promise<number> => {
	return new Promise((resolve, reject) => {
		const element = document.createElement(
			file.type.startsWith("video/") ? "video" : "audio",
		) as HTMLVideoElement;
		const objectUrl = URL.createObjectURL(file);
        const cleanup=()=>{signal.removeEventListener('abort',abort);element.onloadedmetadata=null;element.onerror=null;element.pause();element.removeAttribute('src');element.load();URL.revokeObjectURL(objectUrl);element.remove();};
        const abort=()=>{cleanup();reject(stopped());};signal.addEventListener('abort',abort,{once:true});if(signal.aborted){abort();return;}

		element.onloadedmetadata=()=>{const duration=element.duration;cleanup();resolve(duration);};

		element.onerror=()=>{cleanup();reject(new Error("Could not load media"));};

		element.src = objectUrl;
		element.load();
	});
};
