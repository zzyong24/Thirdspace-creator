export const REFERENCE_TYPE = 'creatoros.reference-editor';
export const REFERENCE_VERSION = 1;
export const session = new URLSearchParams(location.hash.includes('?') ? location.hash.split('?')[1] : location.hash.slice(1)).get('session') || location.hash.slice(1);
export function send(operation:string,payload:unknown={},requestId:string=crypto.randomUUID()){
 if (window.parent===window) return;
 window.parent.postMessage({type:REFERENCE_TYPE,version:REFERENCE_VERSION,session,requestId,operation,payload},location.origin);
}
export function validMessage(event:MessageEvent){const m=event.data;return window.parent!==window && event.source===window.parent && event.origin===location.origin && !!session && m?.type===REFERENCE_TYPE && m.version===1 && m.session===session && typeof m.requestId==='string' && m.requestId.length>0 && m.requestId.length<=256 && typeof m.operation==='string';}
