import type {NativeLifetime} from './native-lifecycle';
export type NativeTheme={mode:'light'|'dark';tokens:Record<string,string>;fontFamily:string;fontSize:string;density:string};
export type NativeOwner={accountId:string;outputId:string;sourceVersionId:string};
export type NativeHost={container:HTMLElement;portalContainer:HTMLElement;owner:NativeOwner;theme:NativeTheme;lifetime:NativeLifetime;disabled:boolean;onChanged:()=>void;onError:(message:string)=>void;importMedia:(file:File)=>Promise<{mediaId:string}>};
let host:NativeHost|null=null;
export function installNativeHost(value:NativeHost){if(host)throw Error('旧剪辑实例尚未销毁。');host=value;return()=>{if(host===value)host=null;};}
export function nativeHost(){if(!host)throw Error('剪辑组件尚未挂载。');return host;}
export function currentNativeHost(){return host;}
export function nativeChanged(){if(host&&!host.lifetime.signal.aborted)host.onChanged();}
export function nativePortal(){return nativeHost().portalContainer;}
export function nativeActiveElement():Element|null{const root=host?.container.getRootNode();return root instanceof ShadowRoot?root.activeElement:document.activeElement;}
export function ownsNativeEvent(event:Event){if(!host||host.lifetime.signal.aborted||host.disabled)return false;const path=event.composedPath();return path.includes(host.container)||path.includes(host.portalContainer)||path.some(node=>node instanceof Node&&(host!.container.contains(node)||host!.portalContainer.contains(node)));}
export function nativeFocused(){if(!host||host.lifetime.signal.aborted||host.disabled)return false;const active=nativeActiveElement();return !!active&&(host.container.contains(active)||host.portalContainer.contains(active));}
const appliedTokens=new WeakMap<HTMLElement,Set<string>>();
export function applyNativeTheme(target:HTMLElement,theme:NativeTheme){const next=new Set(Object.keys(theme.tokens).filter(key=>/^--creatoros-[a-z0-9-]+$/i.test(key)));for(const key of appliedTokens.get(target)??[])if(!next.has(key))target.style.removeProperty(key);for(const key of next)target.style.setProperty(key,theme.tokens[key]);appliedTokens.set(target,next);target.style.fontFamily=theme.fontFamily;target.style.fontSize=theme.fontSize;target.dataset.density=theme.density;target.classList.toggle('dark',theme.mode==='dark');target.dataset.theme=theme.mode;}
