import {test,expect} from 'bun:test';
import {NativeLifetime,DocumentLease} from '../native-lifecycle';
test('取消后不发布慢操作的结果；销毁等待原操作到达不可写状态',async()=>{
 const life=new NativeLifetime(new AbortController().signal);let release!:()=>void,finished=false;
 const work=life.run(async()=>{await new Promise<void>(r=>release=r);life.assertCurrent();finished=true;return 1;});
 const rejected=work.catch(e=>e);life.cancel();let drained=false;const drain=life.drain().then(()=>drained=true);await Promise.resolve();expect(drained).toBe(false);release();expect((await rejected).name).toBe('AbortError');await drain;expect(finished).toBe(false);expect(drained).toBe(true);
});
test('同文档lease交接必须等旧实例关闭；排队取消不取得资源',async()=>{
 const lease=new DocumentLease();let close!:()=>void;const first=new AbortController();await lease.acquire(first.signal,()=>new Promise<void>(r=>close=r));
 const next=new AbortController();let acquired=false;const take=lease.acquire(next.signal,async()=>{}).then(()=>acquired=true);await Promise.resolve();expect(acquired).toBe(false);close();await take;expect(acquired).toBe(true);
 next.abort();const dead=new AbortController();dead.abort();await expect(lease.acquire(dead.signal,async()=>{})).rejects.toThrow('已停止');
});
