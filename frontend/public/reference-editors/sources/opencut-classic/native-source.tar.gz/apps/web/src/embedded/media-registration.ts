import {Input,BlobSource,ALL_FORMATS,AudioBufferSink} from 'mediabunny';
import {nativeOwnerKey,currentNativeContextEpoch,currentNativeContextSignal,type NativeOwner,withNativeOriginalAudioPreviewGuard} from './native-host';
import {assertEditable} from './edit-lock';
import {nativeHost} from './native-host';
import {abortable} from './native-lifecycle';
let files=new WeakMap<File,string>();
const pending=new Set<AbortController>();
export function cancelPendingMediaImports(_reason:string){for(const controller of pending)controller.abort();pending.clear();}
export function resetMediaRegistration(){cancelPendingMediaImports('作品已切换。');files=new WeakMap();}
export function rememberMediaFile(file:File,id:string){if(!(file instanceof File)||!id)throw Error('素材文件或真实ID缺失。');files.set(file,id);}
export function getRegisteredMediaId(file:File){const id=files.get(file);if(!id)throw Error('素材尚未保存至作品。');return id;}
export async function registerMediaFile(file:File):Promise<string>{assertEditable();const h=nativeHost(),known=files.get(file);if(known)return known;const controller=new AbortController();pending.add(controller);const abort=()=>controller.abort();h.lifetime.signal.addEventListener('abort',abort,{once:true});const timer=setTimeout(abort,60000);try{return await h.lifetime.run(async()=>{const receipt=await abortable(h.importMedia(file),controller.signal);h.lifetime.assertCurrent();assertEditable();if(typeof receipt?.mediaId!=='string'||!receipt.mediaId)throw Error('素材上传未返回真实ID。');rememberMediaFile(file,receipt.mediaId);return receipt.mediaId;});}finally{clearTimeout(timer);pending.delete(controller);h.lifetime.signal.removeEventListener('abort',abort);}}

export type OriginalAudioRangeRequest={owner:NativeOwner;clipId:string;sceneId:string;contextEpoch:number;nonce:string;file:File;assetFileId:string;sourceId:string;sourceStartSeconds:number;sourceEndSeconds:number};
// SEMANTIC_BOUNDARY_ALLOW: 原文件连续样本/时钟/身份机械校验；不选择口误、停顿或创作内容。
export async function readOriginalAudioRange(p:OriginalAudioRangeRequest,signal:AbortSignal|undefined,assertSceneAndClip:()=>void){
 const host=nativeHost(),epoch=currentNativeContextEpoch(),contextSignal=currentNativeContextSignal();
 const base={owner:{...p.owner},clipId:p.clipId,sceneId:p.sceneId,contextEpoch:p.contextEpoch,nonce:p.nonce,assetFileId:p.assetFileId,sourceId:p.sourceId,rangeStartSeconds:p.sourceStartSeconds,rangeEndSeconds:p.sourceEndSeconds};
 const manual=(reason:string,videoFirstTimestamp:number|null=null,audioFirstTimestamp:number|null=null)=>({...base,status:'manual_review' as const,reason,videoFirstTimestamp,audioFirstTimestamp,chunks:[]});
 const assert=()=>{host.lifetime.assertCurrent();assertSceneAndClip();if(signal?.aborted||contextSignal.aborted||epoch!==currentNativeContextEpoch())throw new DOMException('原声复核上下文已改变。','AbortError');};
 assert();if(nativeOwnerKey(p.owner)!==nativeOwnerKey(host.owner)||p.contextEpoch!==epoch)throw new Error('原声复核归属或场景已改变。');
 if(!(p.file instanceof File)||!p.assetFileId||!p.sourceId||!p.nonce||!Number.isFinite(p.sourceStartSeconds)||!Number.isFinite(p.sourceEndSeconds)||p.sourceStartSeconds<0||p.sourceEndSeconds<=p.sourceStartSeconds)return manual('原文件或区间未能验证，请逐项手动复核。');
 return withNativeOriginalAudioPreviewGuard(async()=>{
 const input=new Input({formats:ALL_FORMATS,source:new BlobSource(p.file)});const abort=()=>{if(!input.disposed)input.dispose();};
 for(const s of [signal,contextSignal,host.lifetime.signal])s?.addEventListener('abort',abort,{once:true});
 let videoFirst:number|null=null,audioFirst:number|null=null;
 try{
  const video=await input.getPrimaryVideoTrack();assert();const audio=await input.getPrimaryAudioTrack();assert();
  if(video){videoFirst=await video.getFirstTimestamp();assert();}if(audio){audioFirst=await audio.getFirstTimestamp();assert();}
  // 视频零点与 AAC 负预滚是两个事实；绝不以音轨首PTS或固定延迟重签 source zero。
  if(!audio)return manual('此文件没有可解码音轨，保留手动复核。',videoFirst,audioFirst);
  if(videoFirst!==0)return manual('此文件视频零点与 source 秒映射未证，保留本项手动复核。',videoFirst,audioFirst);
  const chunks:Array<{buffer:AudioBuffer;timestamp:number}>=[];let sampleRate:number|undefined,channels:number|undefined,coveredStart:number|undefined,coveredEnd:number|undefined;
  const sink=new AudioBufferSink(audio);
  // 从原 Blob 的真实区间API连续读取；不读取retimed预览，也不为每个gap解码到全片末尾。
  for await(const wrapped of sink.buffers(p.sourceStartSeconds,p.sourceEndSeconds)){
   assert();const b=wrapped.buffer,t=wrapped.timestamp;
   if(!Number.isFinite(t)||!Number.isSafeInteger(b.length)||b.length<=0||!Number.isFinite(b.sampleRate)||b.sampleRate<=0||b.numberOfChannels<1)return manual('解码样本维度未证。',videoFirst,audioFirst);
   if(sampleRate!==undefined&&(sampleRate!==b.sampleRate||channels!==b.numberOfChannels))return manual('音轨采样率或通道变化，保留手动复核。',videoFirst,audioFirst);
   sampleRate=b.sampleRate;channels=b.numberOfChannels;
   let first=Math.max(0,Math.floor((p.sourceStartSeconds-t)*sampleRate));let end=Math.min(b.length,Math.ceil((p.sourceEndSeconds-t)*sampleRate));
   if(coveredEnd!==undefined)first=Math.max(first,Math.ceil((coveredEnd-t)*sampleRate-1e-7));
   if(end<=first)continue;
   const start=t+first/sampleRate,finish=t+end/sampleRate;
   if(coveredEnd!==undefined&&start-coveredEnd>1/sampleRate+1e-9)return manual('原声区间缺少连续样本，保留手动复核。',videoFirst,audioFirst);
   const cropped=new AudioBuffer({length:end-first,numberOfChannels:channels,sampleRate});
   for(let channel=0;channel<channels;channel++)cropped.copyToChannel(b.getChannelData(channel).subarray(first,end),channel);
   chunks.push({buffer:cropped,timestamp:start});coveredStart??=start;coveredEnd=finish;
  }
  assert();if(!sampleRate||coveredStart===undefined||coveredEnd===undefined||coveredStart>p.sourceStartSeconds+1e-9||coveredEnd<p.sourceEndSeconds-1e-9)return manual('原声起止样本覆盖未证，保留本项手动复核。',videoFirst,audioFirst);
  return {...base,status:'decoded' as const,videoFirstTimestamp:videoFirst,audioFirstTimestamp:audioFirst,chunks};
 }catch(error){assert();return manual('本项原声解码不可用，保留手动复核。',videoFirst,audioFirst);}
 finally{for(const s of [signal,contextSignal,host.lifetime.signal])s?.removeEventListener('abort',abort);abort();}
 },()=>manual('预览仍在播放，请先暂停并重新读取选区。'));
}
