import {assertEditable} from './edit-lock';
import {nativeHost} from './native-host';
import {abortable} from './native-lifecycle';
let files=new WeakMap<File,string>();
const pending=new Set<AbortController>();
export function cancelPendingMediaImports(_reason:string){for(const controller of pending)controller.abort();pending.clear();}
export function resetMediaRegistration(){cancelPendingMediaImports('作品已切换。');files=new WeakMap();}
export function rememberMediaFile(file:File,id:string){if(!(file instanceof File)||!id)throw Error('素材文件或真实ID缺失。');files.set(file,id);}
export function getRegisteredMediaId(file:File){const id=files.get(file);if(!id)throw Error('素材尚未保存至作品。');return id;}
export async function registerMediaFile(file:File):Promise<string>{assertEditable();const h=nativeHost(),known=files.get(file);if(known)return known;const controller=new AbortController();pending.add(controller);const abort=()=>controller.abort();h.lifetime.signal.addEventListener('abort',abort,{once:true});const timer=setTimeout(abort,60000);try{return await h.lifetime.run(async()=>{const receipt=await abortable(h.importMedia(file),controller.signal);h.lifetime.assertCurrent();assertEditable();if(typeof receipt?.mediaId!=='string'||!receipt.mediaId)throw Error('素材上传未返回真实ID。');rememberMediaFile(file,receipt.mediaId);return receipt.mediaId;});}finally{clearTimeout(timer);pending.delete(controller);h.lifetime.signal.removeEventListener('abort',abort);}}
