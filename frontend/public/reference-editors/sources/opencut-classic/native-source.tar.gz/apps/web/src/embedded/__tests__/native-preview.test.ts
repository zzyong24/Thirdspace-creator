import {test,expect,beforeEach,afterEach,mock} from 'bun:test';
import {NativeLifetime} from '../native-lifecycle';
import {installNativeHost,nativeHost,currentNativeContextEpoch,invalidateNativeContext} from '../native-host';
import {rememberMediaFile,resetMediaRegistration} from '../media-registration';
mock.module('@/wasm',()=>({TICKS_PER_SECOND:120000,ZERO_MEDIA_TIME:0,mediaTime:(v:any)=>v.ticks}));
let controllerEditor:any;
mock.module('@/core',()=>({EditorCore:{getInstance(){if(!controllerEditor)throw Error('fixture must not access global editor');return controllerEditor;},reset(){}}}));
const {nativeDigest,nativeJson}=await import('../native-operations');
import {isExportLocked} from '../edit-lock';
const {previewNativeScene}=await import('../native-preview');
let detach=()=>{};
const root=()=>({inert:false} as HTMLElement);
beforeEach(()=>{Object.assign(globalThis,{AudioBuffer:class{}});detach=installNativeHost({container:root(),portalContainer:root(),owner:{groupId:'group-fixture',accountId:null,projectId:'project-fixture',outputId:'output-fixture',sourceVersionId:'31'},theme:{mode:'dark',tokens:{},fontFamily:'system-ui',fontSize:'14px',density:'comfortable'},lifetime:new NativeLifetime(new AbortController().signal),disabled:false,onChanged(){},onError(){},importMedia:async()=>({mediaId:'media-fixture'})});});
afterEach(()=>{nativeHost().lifetime.cancel();resetMediaRegistration();detach();});
function fixture(){
 const file=new File(['real fixture bytes'],'fixture.mp4',{type:'video/mp4',lastModified:100});rememberMediaFile(file,'media-fixture');
 const tracks:any={main:{id:'main-fixture',name:'主轨',type:'video',muted:false,hidden:false,elements:[{id:'clip-fixture',name:'原片',type:'video',mediaId:'media-fixture',startTime:0,duration:240000,trimStart:0,trimEnd:0,sourceDuration:240000,params:{}}]},overlay:[],audio:[]};
 const scene:any={id:'scene-fixture',name:'主画面',isMain:true,bookmarks:[],createdAt:new Date(0),updatedAt:new Date(0),tracks};
 const project:any={version:31,metadata:{id:'output-fixture',name:'真实预览',createdAt:new Date(0),updatedAt:new Date(0),duration:240000},settings:{fps:{numerator:30,denominator:1},canvasSize:{width:1280,height:720},background:{type:'color',color:'#000000'}},currentSceneId:scene.id,scenes:[scene,{...structuredClone(scene),id:'other-scene'}]};
 const media:any={id:'media-fixture',assetId:'asset-fixture',assetFileId:'file-fixture',name:file.name,type:'video',file,url:'blob:registered',duration:2,hasAudio:true};
 let calls=0,frozen:any;let complete:(value:any)=>void=()=>{};const response=new Promise(resolve=>complete=resolve);
 const forbidden=()=>{throw Error('候选预览不得修改工程或保存');};
 const editor:any={project:{getActive:()=>project,loadProject:forbidden,saveCurrentProject:forbidden},scenes:{getActiveScene:()=>scene,getScenes:()=>project.scenes,setScenes:forbidden},media:{getAssets:()=>[media],isLoadingMedia:()=>false},playback:{getIsPlaying:()=>false,pause:forbidden},save:{getIsDirty:()=>false,pause:forbidden,resume:forbidden,flush:forbidden},command:{execute:forbidden},renderer:{exportProject(args:any){calls++;frozen=args.frozen;return response;}}};
 const candidate=structuredClone(tracks);candidate.main.elements[0].name='候选片段';
 const payload=async()=>({owner:{...nativeHost().owner},targetSceneId:scene.id,baseContextEpoch:currentNativeContextEpoch(),beforeDigest:await nativeDigest(tracks),candidateDigest:await nativeDigest({...nativeJson(scene) as object,tracks:candidate}),tracks:candidate,media:[{mediaId:media.id,assetId:media.assetId,assetFileId:media.assetFileId,file,name:media.name,type:media.type,size:file.size,lastModified:file.lastModified,duration:media.duration,hasAudio:media.hasAudio}]});
 return {file,scene,project,media,editor,candidate,payload,complete,get calls(){return calls;},get frozen(){return frozen;}};
}
test('只读候选经原renderer冻结完整project/media/tracks与真实派生duration，返回MP4 Blob且原工程未变',async()=>{const f=fixture(),original=structuredClone(f.project);const p=await f.payload();const work=previewNativeScene(f.editor,p);for(let i=0;i<100&&!f.calls;i++)await Bun.sleep(1);expect(f.calls).toBe(1);expect(isExportLocked()).toBe(true);expect(f.frozen.tracks.main.elements[0].name).toBe('候选片段');expect(f.frozen.project.scenes[0].tracks).toEqual(f.candidate);expect(f.frozen.project.scenes[1]).toEqual(original.scenes[1]);expect(f.frozen.mediaAssets[0].file).toBe(f.file);expect(f.frozen.duration).toBe(240000);f.complete({success:true,buffer:new Uint8Array([0,1,2,3]).buffer});const result=await work;expect(result.blob.type).toBe('video/mp4');expect(result.blob.size).toBe(4);expect(result).toMatchObject({fileName:'真实预览-preview.mp4',sceneId:f.scene.id,candidateDigest:p.candidateDigest,contextEpoch:p.baseContextEpoch,documentVersion:31});expect(f.project).toEqual(original);expect(isExportLocked()).toBe(false);},120000);
test('错误owner/epoch/前值/候选摘要均零渲染且原稿保留',async()=>{for(const key of ['owner','baseContextEpoch','beforeDigest','candidateDigest'] as const){const f=fixture();const p:any=await f.payload();p[key]=key==='owner'?{...p.owner,accountId:'foreign-account'}:key==='baseContextEpoch'?p.baseContextEpoch+1:'sha256:'+ '0'.repeat(64);await expect(previewNativeScene(f.editor,p)).rejects.toThrow();expect(f.calls).toBe(0);expect(isExportLocked()).toBe(false);}},120000);
test('真正registered文件字节/元信息漂移不得把别的file渲为原exact素材',async()=>{const f=fixture();const p=await f.payload();p.media[0].file=new File(['different bytes!!!'],'fixture.mp4',{type:'video/mp4',lastModified:100});await expect(previewNativeScene(f.editor,p)).rejects.toThrow();expect(f.calls).toBe(0);expect(isExportLocked()).toBe(false);},120000);
test('渲染期间context漂移与取消均拒绝Blob并释放锁',async()=>{for(const action of ['epoch','cancel','owner-dispose'] as const){const f=fixture(),signal=new AbortController();const p=await f.payload();const work=previewNativeScene(f.editor,p,()=>signal.signal.throwIfAborted());for(let i=0;i<100&&!f.calls;i++)await Bun.sleep(1);expect(f.calls).toBe(1);if(action==='epoch')invalidateNativeContext({sceneId:f.scene.id,selectedElements:[],documentChanged:false});else if(action==='cancel')signal.abort();else nativeHost().lifetime.cancel();f.complete({success:true,buffer:new ArrayBuffer(4)});await expect(work).rejects.toThrow();expect(isExportLocked()).toBe(false);if(action==='owner-dispose')break;}},120000);
test('等待原导入完成，等待中不提前锁或取消导入；完成发生context漂移明确拒绝',async()=>{const f=fixture(),p=await f.payload();let finish!:()=>void;const pending=new Promise<void>(resolve=>finish=resolve);const work=previewNativeScene(f.editor,p,()=>{},()=>pending);await Promise.resolve();expect(isExportLocked()).toBe(false);expect(f.calls).toBe(0);invalidateNativeContext({sceneId:f.scene.id,selectedElements:[],documentChanged:true});finish();await expect(work).rejects.toThrow();expect(f.calls).toBe(0);expect(isExportLocked()).toBe(false);},120000);

// 原controller与processMediaAssets/registerMediaFile/MediaManager公共导入源码都实际执行；仅视频解码和renderer端口是显式fixture。
test('T1070 公共控制器摘要窗口的新导入保原请求/信号/epoch并完整加入，不被只读预览取消',async()=>{
 let decoderStarted=false,decoderSignal:AbortSignal|undefined,finishDecoder!:(result:any)=>void,uploadSignal:AbortSignal|undefined,uploadCalls=0;
 const decoder=new Promise(resolve=>finishDecoder=resolve);
 mock.module('@/media/mediabunny',()=>({readVideoFile:({signal}:any)=>{decoderStarted=true;decoderSignal=signal;return new Promise((resolve,reject)=>{const abort=()=>{cleanup();reject(new DOMException('decode fixture canceled','AbortError'));};const cleanup=()=>signal.removeEventListener('abort',abort);signal.addEventListener('abort',abort,{once:true});decoder.then(value=>{cleanup();resolve(value);},reject);if(signal.aborted)abort();});}}));
 mock.module('@/services/video-cache/service',()=>({videoCache:{drain:async()=>{},clearAll(){}}}));
 mock.module('@/services/waveform-cache/service',()=>({waveformCache:{clearAll(){}}}));
 mock.module('@/services/renderer/nodes/image-node',()=>({clearImageSources(){}}));
 mock.module('@/services/renderer/compositor/wasm-compositor',()=>({wasmCompositor:{dispose(){}}}));
 mock.module('@/services/renderer/gpu-renderer',()=>({initializeGpuRenderer:async()=>{},isGpuAvailable:()=>true}));
 mock.module('@/timeline/scenes',()=>({buildDefaultScene(){return {id:'unused-default',tracks:{main:{id:'unused-main',type:'video',elements:[]},overlay:[],audio:[]}};}}));
 mock.module('@/components/editor/panels/assets/assets-panel-store',()=>({useAssetsPanelStore:{setState(){}}}));
 mock.module('@/timeline/timeline-store',()=>({useTimelineStore:{setState(){}}}));
 mock.module('@/actions/keybindings-store',()=>({useKeybindingsStore:{setState(){}}}));
 mock.module('@/commands',()=>({BatchCommand:class{},RemoveMediaAssetCommand:class{}}));
 const {MediaManager}=await import('@/core/managers/media-manager');
 const {storageService}=await import('@/services/storage/service');
 const {processMediaAssets}=await import('@/media/processing');
 const {createNativeController}=await import('../native-controller');
 const {getRegisteredMediaId}=await import('../media-registration');
 const {currentEditEpoch,currentEditSignal}=await import('../edit-lock');
 const f=fixture(),e=f.editor,lateFile=new File(['late import source'],'late.mp4',{type:'video/mp4',lastModified:222});
 nativeHost().importMedia=async(file,options)=>{expect(file).toBe(lateFile);uploadCalls++;uploadSignal=options?.signal;return{mediaId:'late-media'};};
 const no=()=>{};Object.assign(e.playback,{pause:no,dispose:no,getCurrentTime:()=>0,subscribe:()=>no,onSeek:()=>no});Object.assign(e.save,{stop:no,pause:no,resume:no,flush:async()=>{},markDirty:no});e.audio={dispose:async()=>{}};e.selection={getSelectedElements:()=>[],subscribe:()=>no};e.timeline={subscribe:()=>no};e.scenes={getScenes:()=>f.project.scenes,getActiveScene:()=>f.project.scenes.find((scene:any)=>scene.id===f.project.currentSceneId),subscribe:()=>no};
 Object.assign(e.project,{subscribe:()=>no,ratchetFpsForImportedMedia:no,loadProject:async({id}:any)=>{const loaded=await storageService.loadProject({id});if(!loaded)throw Error('actual transient project missing');Object.assign(f.project,loaded.project);await e.media.loadProjectMedia({projectId:id});}});e.renderer.setDegraded=no;e.media=new MediaManager(e);controllerEditor=e;
 const ctl=createNativeController(()=>{});let releaseFile!:(value:ArrayBuffer)=>void,bytesStarted=false;let importObserved:Promise<any>|undefined;
 try{
  const initial=await f.payload();await ctl.request('load',{outputId:f.project.metadata.id,document:nativeJson(f.project),media:initial.media}, {requestId:'public-race-load'});
  const p=await f.payload(),independent=new File([f.file],f.file.name,{type:f.file.type,lastModified:f.file.lastModified});
  Object.defineProperty(independent,'arrayBuffer',{value:()=>{bytesStarted=true;return new Promise<ArrayBuffer>(resolve=>releaseFile=resolve);}});p.media[0].file=independent;
  const editEpoch=currentEditEpoch(),editSignal=currentEditSignal();
  const previewObserved=ctl.request('preview-scene',p,{requestId:'public-race-preview'}).then(value=>({value}),error=>({error}));
  for(let i=0;i<100&&!bytesStarted;i++)await Bun.sleep(1);expect(bytesStarted).toBe(true);
  const importWork=processMediaAssets({files:[lateFile],onProcessed:async asset=>{const added=await e.media.addMediaAsset({projectId:f.project.metadata.id,asset});if(!added)throw Error('original imported asset was not accepted');}});importObserved=importWork.then(value=>({value}),error=>({error}));
  for(let i=0;i<100&&!decoderStarted;i++)await Bun.sleep(1);expect(decoderStarted).toBe(true);expect(uploadCalls).toBe(1);expect(decoderSignal?.aborted).toBe(false);
  f.complete({success:true,buffer:new ArrayBuffer(4)});releaseFile(await f.file.arrayBuffer());
  const preview=await previewObserved;
  expect(editSignal.aborted).toBe(false);expect(preview.error).toMatchObject({status:409,code:'ConflictError'});expect(f.calls).toBe(0);expect(isExportLocked()).toBe(false);expect(currentEditEpoch()).toBe(editEpoch);expect(decoderSignal?.aborted).toBe(false);expect(uploadSignal?.aborted).toBe(false);
  finishDecoder({duration:2,width:1280,height:720,fps:30,hasAudio:false,canDecode:true,codec:'h264',thumbnailUrl:null});const imported=await importObserved;
  expect(imported.error).toBeUndefined();expect(imported.value).toHaveLength(1);expect(getRegisteredMediaId(lateFile)).toBe('late-media');expect(e.media.getAssets().find((asset:any)=>asset.id==='late-media')?.file).toBe(lateFile);expect(uploadCalls).toBe(1);expect(currentEditEpoch()).toBe(editEpoch);expect(editSignal.aborted).toBe(false);expect(decoderSignal?.aborted).toBe(false);
 }finally{finishDecoder({duration:2,width:1280,height:720,fps:30,hasAudio:false,canDecode:true});if(importObserved)await importObserved;ctl.clear();controllerEditor=undefined;}
},120000);
