import React,{useEffect,useState} from 'react';
import { createRoot } from 'react-dom/client';
import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { EditorHeader } from '@/components/editor/editor-header';
import { EditorLayout } from './editor-layout';
import { EditorRuntimeBindings } from '@/components/providers/editor-provider';
import { startBridge } from './bridge';
import '../app/globals.css';
import './embedded.css';
function App(){const [generation,setGeneration]=useState(0);const [loaded,setLoaded]=useState(false);const [error,setError]=useState('');const [exporting,setExporting]=useState(false);useEffect(()=>{const onLoaded=()=>{setGeneration(n=>n+1);setLoaded(true);setError('');};const onLoading=()=>setLoaded(false);const onLock=(e:Event)=>setExporting((e as CustomEvent).detail);const onError=(e:Event)=>setError((e as CustomEvent).detail);window.addEventListener('creatoros-reference-loaded',onLoaded);window.addEventListener('creatoros-reference-loading',onLoading);window.addEventListener('creatoros-reference-error',onError);window.addEventListener('creatoros-reference-export-lock',onLock);startBridge();return()=>{window.removeEventListener('creatoros-reference-loaded',onLoaded);window.removeEventListener('creatoros-reference-loading',onLoading);window.removeEventListener('creatoros-reference-error',onError);window.removeEventListener('creatoros-reference-export-lock',onLock);};},[]);return <ThemeProvider attribute="class" defaultTheme="dark"><TooltipProvider><Toaster/>{exporting&&<div role="status" aria-live="polite" className="fixed inset-0 z-[99999] grid place-items-center bg-black/60 text-white"><p>正在导出当前稿，完成后可以继续编辑…</p></div>}{loaded?<div key={generation} className="bg-background flex h-screen w-screen flex-col overflow-hidden"><EditorRuntimeBindings/><EditorHeader/>{error&&<p role="alert" className="p-2 text-destructive">{error}</p>}<div className="min-h-0 min-w-0 flex-1"><EditorLayout/></div></div>:<div className="h-screen grid place-items-center bg-background text-foreground"><p role={error?'alert':undefined}>{error||'正在载入视频稿…'}</p></div>}</TooltipProvider></ThemeProvider>;}
createRoot(document.getElementById('root')!).render(<App/>);
