import {toast} from 'sonner';
import {nativeHost} from '@/embedded/native-host';
import {stopped} from '@/embedded/native-lifecycle';
export interface MediaUploadToastResult{uploadedCount:number;assetNames?:string[];}
function waitForNextPaint(signal:AbortSignal):Promise<void>{return new Promise((resolve,reject)=>{let frame=0;const cleanup=()=>signal.removeEventListener('abort',abort);const abort=()=>{cancelAnimationFrame(frame);cleanup();reject(stopped());};signal.addEventListener('abort',abort,{once:true});if(signal.aborted){abort();return;}frame=requestAnimationFrame(()=>{frame=requestAnimationFrame(()=>{cleanup();if(signal.aborted)reject(stopped());else resolve();});});});}
export function showMediaUploadToast<T extends MediaUploadToastResult>({filesCount,promise}:{filesCount:number;promise:Promise<T>|(()=>Promise<T>)}):Promise<T>{
 const host=nativeHost(),run=typeof promise==='function'?promise:()=>promise;
 return host.lifetime.run(async()=>{const id=toast.loading(`正在导入 ${filesCount} 个素材…`);try{await waitForNextPaint(host.lifetime.signal);host.lifetime.assertCurrent();const result=await run();host.lifetime.assertCurrent();toast.success(result.uploadedCount===1?`${result.assetNames?.[0]??'素材'} 已导入`:`已导入 ${result.uploadedCount} 个素材`,{id});return result;}catch(error){if(host.lifetime.signal.aborted)toast.dismiss(id);else toast.error('素材导入未完成。',{id});throw error;}});
}
