/** 仅管理原生实例执行寿命与机械资源lease，不作内容/创作选择。 */
export function stopped(){return new DOMException('编辑器已停止或作品已切换。','AbortError');}
export class NativeLifetime {
 readonly controller=new AbortController();readonly signal=this.controller.signal;
 private readonly running=new Set<Promise<unknown>>();private readonly detach:()=>void;
 constructor(parent:AbortSignal){const cancel=()=>this.cancel();parent.addEventListener('abort',cancel,{once:true});this.detach=()=>parent.removeEventListener('abort',cancel);if(parent.aborted)this.cancel();}
 assertCurrent(){if(this.signal.aborted)throw stopped();}
 cancel(){this.controller.abort();this.detach?.();}
 run<T>(task:()=>Promise<T>):Promise<T>{this.assertCurrent();const result=(async()=>{this.assertCurrent();const value=await task();this.assertCurrent();return value;})();this.running.add(result);void result.finally(()=>this.running.delete(result)).catch(()=>{});return result;}
 async drain(){while(this.running.size)await Promise.allSettled([...this.running]);}
}
export class DocumentLease {
 private tail=Promise.resolve();private active:{close:()=>Promise<void>;token:symbol}|null=null;
 acquire(signal:AbortSignal,close:()=>Promise<void>):Promise<()=>void>{const job=this.tail.then(async()=>{if(signal.aborted)throw stopped();const previous=this.active;if(previous){await previous.close();if(this.active===previous)this.active=null;}if(signal.aborted)throw stopped();const token=Symbol();this.active={close,token};return()=>{if(this.active?.token===token)this.active=null;};});this.tail=job.then(()=>{},()=>{});return job;}
}
export function abortable<T>(work:Promise<T>,signal:AbortSignal):Promise<T>{if(signal.aborted)return Promise.reject(stopped());return new Promise((resolve,reject)=>{const abort=()=>{cleanup();reject(stopped());};const cleanup=()=>signal.removeEventListener('abort',abort);signal.addEventListener('abort',abort,{once:true});work.then(value=>{cleanup();if(signal.aborted)reject(stopped());else resolve(value);},error=>{cleanup();reject(error);});});}
