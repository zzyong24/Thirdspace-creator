// Pinned upstream cf5e79e, native project schema version. No browser DB migration in the embed.
export const CURRENT_PROJECT_VERSION = 31;
