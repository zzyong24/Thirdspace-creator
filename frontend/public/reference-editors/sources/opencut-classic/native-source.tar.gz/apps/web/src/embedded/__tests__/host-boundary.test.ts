import {test,expect,beforeAll,beforeEach,afterEach} from 'bun:test';
import {NativeLifetime} from '../native-lifecycle';
import {installNativeHost,nativeHost,nativeChanged,nativeOwnerKey,currentNativeContextEpoch,currentNativeContextSignal,invalidateNativeContext,bindNativeContext,type NativeContextPort,pauseNativePlaybackForContext,withNativeOriginalAudioPreviewGuard} from '../native-host';
let StorageService:typeof import('../../services/storage/service').StorageService;let register:typeof import('../media-registration');
let changedEvents=0;let detach=()=>{};
const root=()=>({inert:false,style:{},contains(){return false;}} as unknown as HTMLElement);
beforeAll(async()=>{Object.assign(globalThis,{window:{},AudioBuffer:class{},indexedDB:new Proxy({},{get(){throw Error('No browser database permitted');}})});register=await import('../media-registration');({StorageService}=await import('../../services/storage/service'));});
beforeEach(()=>{register.resetMediaRegistration();detach=installNativeHost({container:root(),portalContainer:root(),owner:{groupId:null,projectId:'project-fixture',accountId:'account-fixture',outputId:'output-one',sourceVersionId:'version-fixture'},theme:{mode:'dark',tokens:{},fontFamily:'system-ui',fontSize:'14px',density:'comfortable'},lifetime:new NativeLifetime(new AbortController().signal),disabled:false,onChanged(){changedEvents++;},onError(){},importMedia:async()=>new Promise(()=>{})});});
afterEach(()=>{nativeHost().lifetime.cancel();register.resetMediaRegistration();detach();});
function owner(outputId:string){nativeHost().owner={...nativeHost().owner,outputId};}
test('原生变更直接报告host回调；不建立窗口消息监听',()=>{const before=changedEvents;nativeChanged();expect(changedEvents).toBe(before+1);expect(Object.keys(window)).toHaveLength(0);});
test('storage holds one current output and snapshots without runtime binaries/URLs',async()=>{const storage=new StorageService();const file=new File(['fixture'],'a.png',{type:'image/png'});register.rememberMediaFile(file,'asset-one');await storage.saveProject({project:{metadata:{id:'output-one',name:'稿件',createdAt:new Date(),updatedAt:new Date(),thumbnail:'blob:temporary'},scenes:[{tracks:{audio:[{elements:[{buffer:new AudioBuffer()}]}]}}],settings:{},version:31} as any});expect(await storage.loadProject({id:'other-output'})).toBeNull();await storage.saveMediaAsset({projectId:'output-one',mediaAsset:{id:'asset-one',file,name:'a.png',type:'image',url:'blob:temporary',thumbnailUrl:'blob:thumbnail'}});await expect(storage.saveMediaAsset({projectId:'wrong-output',mediaAsset:{id:'asset-one',file,name:'a.png',type:'image'}})).rejects.toThrow('不属于');await expect(storage.saveMediaAsset({projectId:'output-one',mediaAsset:{id:'wrong-asset',file,name:'a.png',type:'image'}})).rejects.toThrow('不匹配');const snapshot=storage.snapshot(),json=JSON.stringify(snapshot);expect(json).not.toContain('blob:');expect(json).not.toContain('thumbnail');expect(json).not.toContain('buffer');expect(json).not.toContain('"file"');expect(snapshot.mediaMetadata[0].mediaId).toBe('asset-one');storage.hostReset();expect(await storage.loadProject({id:'output-one'})).toBeNull();});


test('export returns the exact frozen render document and rejects delayed imported edits',async()=>{
 const lock=await import('../edit-lock');
 const {exportFrozenSnapshot}=await import('../frozen-export');
 const {storageService}=await import('../../services/storage/service');
 storageService.hostReset();
 owner('output-freeze');
 const project={metadata:{id:'output-freeze',name:'冻结标题',createdAt:new Date(),updatedAt:new Date()},scenes:[{id:'scene-one',tracks:{main:{elements:[{id:'clip-one',name:'冻结剪辑'}]},audio:[],overlay:[]},createdAt:new Date(),updatedAt:new Date()}],currentSceneId:'scene-one',settings:{fps:{numerator:30,denominator:1}},version:31};
 await storageService.saveProject({project:project as any});
 const imported={};const beforeEpoch=lock.currentEditEpoch();lock.stampImportedAsset(imported,beforeEpoch);
 let frozen:any;let finish!:(result:any)=>void;
 const deferred=new Promise(resolve=>finish=resolve);
 const editor={playback:{pause(){}},save:{pause(){},resume(){},async flush(){}},timeline:{getTotalDuration(){return 5000000;}},media:{getAssets(){return [];}},renderer:{exportProject(args:any){frozen=args.frozen;return deferred;}}};
 const pending=exportFrozenSnapshot(editor as any,'mp4');
 await Promise.resolve();await Promise.resolve();
 expect(lock.isExportLocked()).toBe(true);expect(()=>lock.assertEditable()).toThrow('正在处理');expect(()=>lock.assertImportedAssetCurrent(imported)).toThrow();
 project.metadata.name='晚到标题';project.scenes[0].tracks.main.elements[0].name='晚到剪辑';
 expect(frozen.project.metadata.name).toBe('冻结标题');expect(frozen.tracks.main.elements[0].name).toBe('冻结剪辑');
 finish({success:true,buffer:new ArrayBuffer(4)});
 const result=await pending;
 expect(result.document.metadata.name).toBe('冻结标题');expect(result.document.scenes[0].tracks.main.elements[0].name).toBe('冻结剪辑');expect(result.fileName).toBe('冻结标题.mp4');expect(result.blob.size).toBe(4);expect(lock.isExportLocked()).toBe(false);expect(()=>lock.assertImportedAssetCurrent(imported)).toThrow('已切换');
});
test('failed export releases editing and pending import replies cannot write during the freeze',async()=>{
 const lock=await import('../edit-lock');const {exportFrozenSnapshot}=await import('../frozen-export');
 owner('output-freeze');
 const upload=register.registerMediaFile(new File(['x'],'pending.png',{type:'image/png'}));
 const observedUpload=upload.catch(error=>error);
 const editor={playback:{pause(){}},save:{pause(){},resume(){},async flush(){}},timeline:{getTotalDuration(){return 1;}},media:{getAssets(){return [];}},renderer:{async exportProject(){return {success:false,error:'真实渲染失败'};}}};
 await expect(exportFrozenSnapshot(editor as any,'mp4')).rejects.toThrow('真实渲染失败');expect((await observedUpload).name).toBe('AbortError');expect(lock.isExportLocked()).toBe(false);expect(()=>lock.assertEditable()).not.toThrow();
});


test('load baseline suppresses autosave timestamps and identical snapshots but preserves editorial changes',async()=>{
 owner('output-clean');
 const storage=new StorageService();
 const project={metadata:{id:'output-clean',name:'原稿',createdAt:new Date(0),updatedAt:new Date(0)},scenes:[{id:'scene-clean',createdAt:new Date(0),updatedAt:new Date(0),tracks:{main:{elements:[{id:'text-one',content:'正文'}]},audio:[],overlay:[]}}],settings:{background:{type:'color',color:'#000000'}},version:31};
 const before=changedEvents;
 await storage.saveProject({project:project as any});storage.hostLoaded();
 expect(changedEvents).toBe(before);
 const timestampOnly=structuredClone(project);timestampOnly.metadata.updatedAt=new Date(1000);timestampOnly.scenes[0].updatedAt=new Date(2000);
 await storage.saveProject({project:timestampOnly as any});
 // Object key insertion order is not a document edit either.
 await storage.saveProject({project:{version:31,settings:timestampOnly.settings,scenes:timestampOnly.scenes,metadata:timestampOnly.metadata} as any});
 expect(changedEvents).toBe(before);
 timestampOnly.scenes[0].tracks.main.elements[0].content='真实改稿';
 await storage.saveProject({project:timestampOnly as any});expect(changedEvents).toBe(before+1);
 await storage.saveProject({project:timestampOnly as any});expect(changedEvents).toBe(before+1);
 timestampOnly.settings.background.color='#ffffff';
 await storage.saveProject({project:timestampOnly as any});expect(changedEvents).toBe(before+2);
 const file=new File(['asset'],'clean.png',{type:'image/png'});register.rememberMediaFile(file,'asset-clean');
 const asset={id:'asset-clean',file,name:'clean.png',type:'image' as const,url:'blob:temp-one'};
 await storage.saveMediaAsset({projectId:'output-clean',mediaAsset:asset});expect(changedEvents).toBe(before+3);
 await storage.saveMediaAsset({projectId:'output-clean',mediaAsset:{...asset,url:'blob:temp-two'}});expect(changedEvents).toBe(before+3);
 await storage.deleteMediaAsset({projectId:'output-clean',id:'asset-clean'});expect(changedEvents).toBe(before+4);
});

test('T1062 同组平台owner key稳定，实际native-context变化同步abort旧范围且未产生试听确认',()=>{
 const owner={...nativeHost().owner,groupId:'group-real',accountId:null};expect(nativeOwnerKey(owner)).toBe(nativeOwnerKey({...owner,accountId:'platform-other'}));expect(nativeOwnerKey(owner)).not.toBe(nativeOwnerKey({...owner,projectId:'foreign'}));expect(nativeOwnerKey(owner)).not.toBe(nativeOwnerKey({...owner,groupId:'foreign'}));
 const received:unknown[]=[];nativeHost().onChanged=event=>received.push(event);const oldSignal=currentNativeContextSignal(),oldEpoch=currentNativeContextEpoch();invalidateNativeContext({sceneId:'scene-real',selectedElements:[{elementId:'clip-real'}],documentChanged:false});expect(oldSignal.aborted).toBe(true);expect(currentNativeContextSignal().aborted).toBe(false);expect(currentNativeContextEpoch()).toBe(oldEpoch+1);expect(received).toEqual([{kind:'native-context',contextEpoch:oldEpoch+1,outputId:'output-one',sceneId:'scene-real',selectedElements:[{elementId:'clip-real'}],documentChanged:false}]);expect(received[0]).not.toHaveProperty('reviewed');expect(received[0]).not.toHaveProperty('played');
});
test('T1062 原storage相同内容/时间戳save不假造新的context epoch',async()=>{const storage=new StorageService();const p={metadata:{id:'output-one',createdAt:new Date(0),updatedAt:new Date(0)},scenes:[],settings:{},version:31};await storage.saveProject({project:p as any});storage.hostLoaded();const epoch=currentNativeContextEpoch();await storage.saveProject({project:{...p,metadata:{...p.metadata,updatedAt:new Date(1000)}} as any});await storage.saveProject({project:p as any});expect(currentNativeContextEpoch()).toBe(epoch);});

test('T1062 实际context relay连续播放帧不刷epoch；离散seek/state/selection/真实document各一次，重复storage通知无新增',()=>{
 let state={documentFingerprint:'original',sceneId:'scene-one',selectedElements:[] as unknown[],playing:true};const listeners=new Map<string,()=>void>();const on=(name:string)=>(callback:()=>void)=>{listeners.set(name,callback);return()=>listeners.delete(name);};
 const port:NativeContextPort={read:()=>structuredClone(state),onDocument:on('document'),onSelection:on('selection'),onSeek:on('seek'),onPlayback:on('playback')};const stop=bindNativeContext(port);const events:unknown[]=[];nativeHost().onChanged=event=>events.push(event);const epoch=currentNativeContextEpoch();
 for(let i=0;i<60;i++)listeners.get('playback')?.();expect(currentNativeContextEpoch()).toBe(epoch);expect(events).toEqual([]);
 listeners.get('seek')?.();expect(currentNativeContextEpoch()).toBe(epoch+1);expect(events[0]).toMatchObject({documentChanged:false});state={...state,playing:false};listeners.get('playback')?.();expect(currentNativeContextEpoch()).toBe(epoch+2);
 state={...state,selectedElements:[{elementId:'clip-one'}]};listeners.get('selection')?.();expect(currentNativeContextEpoch()).toBe(epoch+3);state={...state,documentFingerprint:'actual-edit'};listeners.get('document')?.();expect(currentNativeContextEpoch()).toBe(epoch+4);nativeChanged();listeners.get('document')?.();expect(currentNativeContextEpoch()).toBe(epoch+4);expect(events[3]).toMatchObject({documentChanged:true});stop();expect(listeners.size).toBe(0);expect(nativeHost().onDocumentChanged).toBeUndefined();
});

test('T1062 context显式pause先触发实际playing失效再返回暂停后epoch；原声playing保护零read且不暗暂停',async()=>{
 let state={documentFingerprint:'original',sceneId:'scene-one',selectedElements:[] as unknown[],playing:true};const listeners=new Map<string,()=>void>();const on=(name:string)=>(callback:()=>void)=>{listeners.set(name,callback);return()=>listeners.delete(name);};const stop=bindNativeContext({read:()=>structuredClone(state),onDocument:on('document'),onSelection:on('selection'),onSeek:on('seek'),onPlayback:on('playback')});let pauses=0,inputsAndDecodes=0;
 const playback={pause(){pauses++;state={...state,playing:false};listeners.get('playback')?.();}};const before=currentNativeContextEpoch(),oldSignal=currentNativeContextSignal();
 try{const guarded=await withNativeOriginalAudioPreviewGuard<'decoded'|'manual_review'>(()=>{inputsAndDecodes++;return 'decoded';},()=> 'manual_review');expect(guarded).toBe('manual_review');expect(inputsAndDecodes).toBe(0);expect(pauses).toBe(0);expect(state.playing).toBe(true);expect(currentNativeContextEpoch()).toBe(before);
  const pausedEpoch=pauseNativePlaybackForContext(playback,()=>nativeHost().lifetime.assertCurrent());expect(pauses).toBe(1);expect(state.playing).toBe(false);expect(oldSignal.aborted).toBe(true);expect(pausedEpoch).toBe(before+1);expect(pausedEpoch).toBe(currentNativeContextEpoch());
  const decoded=await withNativeOriginalAudioPreviewGuard<'decoded'|'manual_review'>(()=>{inputsAndDecodes++;return 'decoded';},()=> 'manual_review');expect(decoded).toBe('decoded');expect(inputsAndDecodes).toBe(1);expect(currentNativeContextEpoch()).toBe(pausedEpoch);
  state={...state,playing:true};listeners.get('playback')?.();expect(currentNativeContextEpoch()).toBe(pausedEpoch+1);expect(await withNativeOriginalAudioPreviewGuard<'decoded'|'manual_review'>(()=>{inputsAndDecodes++;return 'decoded';},()=> 'manual_review')).toBe('manual_review');expect(inputsAndDecodes).toBe(1);
 }finally{stop();}
});
test('T1062 显式pause保留Abort；已暂停再次pause不伪造新epoch，取消不得继续read',async()=>{
 let state={documentFingerprint:'original',sceneId:'scene-one',selectedElements:[] as unknown[],playing:false};const listeners=new Map<string,()=>void>();const on=(name:string)=>(callback:()=>void)=>{listeners.set(name,callback);return()=>listeners.delete(name);};const stop=bindNativeContext({read:()=>structuredClone(state),onDocument:on('document'),onSelection:on('selection'),onSeek:on('seek'),onPlayback:on('playback')});let pauses=0,reads=0;const playback={pause(){pauses++;listeners.get('playback')?.();}};const epoch=currentNativeContextEpoch();
 try{expect(pauseNativePlaybackForContext(playback,()=>nativeHost().lifetime.assertCurrent())).toBe(epoch);expect(currentNativeContextEpoch()).toBe(epoch);expect(pauses).toBe(1);const canceled=new AbortController();canceled.abort();expect(()=>pauseNativePlaybackForContext(playback,()=>canceled.signal.throwIfAborted())).toThrow();expect(pauses).toBe(1);nativeHost().lifetime.cancel();await expect(Promise.resolve().then(()=>withNativeOriginalAudioPreviewGuard<'decoded'|'manual_review'>(()=>{reads++;return 'decoded';},()=> 'manual_review'))).rejects.toMatchObject({name:'AbortError'});expect(reads).toBe(0);}finally{stop();}
});

test('T1069 隐藏工作台不接管快捷键事件，重新可见保持同一owner',async()=>{
 const {ownsNativeEvent}=await import('../native-host');const h=nativeHost();
 const event={composedPath:()=>[h.container]} as unknown as Event;
 expect(ownsNativeEvent(event)).toBe(true);h.visible=false;expect(ownsNativeEvent(event)).toBe(false);
 expect(h.owner.outputId).toBe('output-one');h.visible=true;expect(ownsNativeEvent(event)).toBe(true);
});
