import {test,expect,beforeAll,mock} from 'bun:test';
import {installNativeHost,nativeHost,currentNativeContextEpoch,invalidateNativeContext} from '../native-host';
import {NativeLifetime} from '../native-lifecycle';

// 合成PCM块仅校验真实range实现的机械覆盖/取消；不宣称浏览器AAC解码或真人试听证据。
class RangeFixtureBuffer {
 readonly length:number;readonly sampleRate:number;readonly numberOfChannels:number;readonly duration:number;private data:Float32Array[];
 constructor(options:{length:number;sampleRate:number;numberOfChannels:number}){this.length=options.length;this.sampleRate=options.sampleRate;this.numberOfChannels=options.numberOfChannels;this.duration=this.length/this.sampleRate;this.data=Array.from({length:this.numberOfChannels},()=>new Float32Array(this.length));}
 getChannelData(channel:number){return this.data[channel];}copyToChannel(values:Float32Array,channel:number){this.data[channel].set(values);}
}
let rangeBlocks:Array<{buffer:AudioBuffer;timestamp:number}>=[],videoFirst:number|null=0,audioFirst=0,rangeDisposeCount=0,rangeStarts:Array<[number|undefined,number|undefined]>=[],waitRange=false;
let rejectRead:((error:Error)=>void)|undefined,finishRead:(()=>void)|undefined;
class RangeInput {
 disposed=false;constructor(_options:unknown){}async getPrimaryVideoTrack(){return videoFirst===null?null:{getFirstTimestamp:async()=>videoFirst};}async getPrimaryAudioTrack(){return{input:this,getFirstTimestamp:async()=>audioFirst};}
 dispose(){if(this.disposed)return;this.disposed=true;rangeDisposeCount++;rejectRead?.(new Error('Input has been disposed.'));}
}
mock.module('mediabunny',()=>({ALL_FORMATS:[],BlobSource:class{constructor(_file:File){}},Input:RangeInput,AudioBufferSink:class{
 constructor(private track:{input:RangeInput}){}async *buffers(start?:number,end?:number){rangeStarts.push([start,end]);if(waitRange)await new Promise<void>((resolve,reject)=>{finishRead=resolve;rejectRead=reject;});for(const block of rangeBlocks){if(this.track.input.disposed)throw new Error('Input disposed');yield block;}}
}}));

// 此入口只测慢图片/上传取消，视频解码端口不用Bun不能加载的WebAssembly冒充真实解码。
mock.module('@/media/mediabunny',()=>({readVideoFile:async()=>{throw Error('此fixture不执行视频解码');}}));
const {processMediaAssets}=await import('@/media/processing');
import {advanceEditEpoch} from '../edit-lock';
import {registerMediaFile,getRegisteredMediaId,resetMediaRegistration,readOriginalAudioRange,type OriginalAudioRangeRequest} from '../media-registration';
import {showMediaUploadToast} from '@/media/upload-toast';
let images:any[]=[];let created:string[]=[];let revoked:string[]=[];let frameId=0;const frames=new Map<number,()=>void>();
class PendingImage{onload:any=null;onerror:any=null;src='';removeAttribute(name:string){if(name==='src')this.src='';}remove(){}}
beforeAll(()=>{Object.assign(globalThis,{window:{Image:class extends PendingImage{constructor(){super();images.push(this);}}},AudioBuffer:class{},requestAnimationFrame:(callback:()=>void)=>{const id=++frameId;frames.set(id,callback);return id;},cancelAnimationFrame:(id:number)=>frames.delete(id)});URL.createObjectURL=()=>{const url=`blob:fixture-${created.length}`;created.push(url);return url;};URL.revokeObjectURL=url=>revoked.push(url);});
function fixture(importMedia:(file:File)=>Promise<{mediaId:string}>=async()=>({mediaId:'registered'})){const parent=new AbortController(),lifetime=new NativeLifetime(parent.signal),detach=installNativeHost({container:{inert:false} as HTMLElement,portalContainer:{inert:false} as HTMLElement,owner:{groupId:null,projectId:'project-fixture',accountId:'account-fixture',outputId:'output-fixture',sourceVersionId:'version-fixture'},theme:{mode:'dark',tokens:{},fontFamily:'system-ui',fontSize:'14px',density:'comfortable'},lifetime,disabled:false,onChanged(){},onError(){},importMedia});return{lifetime,detach};}
test('慢图片解码取消释放临时Image与BlobURL，寿命排空后不能返回素材',async()=>{const host=fixture();images=[];created=[];revoked=[];try{const pending=processMediaAssets({files:[new File(['fixture'],'slow.png',{type:'image/png'})]});const observed=pending.catch(error=>error);await Promise.resolve();expect(images).toHaveLength(1);host.lifetime.cancel();advanceEditEpoch();expect((await observed).name).toBe('AbortError');await host.lifetime.drain();expect(images[0].src).toBe('');expect(images[0].onload).toBeNull();expect(images[0].onerror).toBeNull();expect(new Set(revoked)).toEqual(new Set(created));}finally{host.lifetime.cancel();host.detach();resetMediaRegistration();}});
test('换稿后迟到素材上传回执不注册到当前编辑器',async()=>{let finish!:(receipt:{mediaId:string})=>void;const host=fixture(()=>new Promise(resolve=>finish=resolve));const file=new File(['fixture'],'late.png',{type:'image/png'});try{const pending=registerMediaFile(file);const observed=pending.catch(error=>error);host.lifetime.cancel();expect((await observed).name).toBe('AbortError');await host.lifetime.drain();finish({mediaId:'late-owner'});await Promise.resolve();expect(()=>getRegisteredMediaId(file)).toThrow('尚未保存');}finally{host.detach();resetMediaRegistration();}});
test('上传提示等待绘制时换稿会取消RAF且不启动旧导入',async()=>{const host=fixture();let starts=0;try{const pending=showMediaUploadToast({filesCount:1,promise:async()=>{starts++;return{uploadedCount:1};}});const observed=pending.catch(error=>error);expect(frames.size).toBe(1);host.lifetime.cancel();expect((await observed).name).toBe('AbortError');await host.lifetime.drain();expect(frames.size).toBe(0);expect(starts).toBe(0);}finally{host.detach();resetMediaRegistration();}});

function block(timestamp:number,values:number[],sampleRate=8){const buffer=new RangeFixtureBuffer({length:values.length,numberOfChannels:1,sampleRate});buffer.copyToChannel(Float32Array.from(values),0);return{timestamp,buffer:buffer as unknown as AudioBuffer};}
function rangeFixture(){const host=fixture();const oldAudioBuffer=globalThis.AudioBuffer;Object.assign(globalThis,{AudioBuffer:RangeFixtureBuffer});rangeBlocks=[];videoFirst=0;audioFirst=0;rangeDisposeCount=0;rangeStarts=[];waitRange=false;rejectRead=undefined;finishRead=undefined;
 const p:OriginalAudioRangeRequest={owner:{...nativeHost().owner},clipId:'clip-exact',sceneId:'scene-exact',contextEpoch:currentNativeContextEpoch(),nonce:'nonce-exact',assetFileId:'asset-file-exact',sourceId:'source-exact',file:new File(['synthetic-not-media'],'fixture.bin'),sourceStartSeconds:.25,sourceEndSeconds:.75};
 return{...host,p,restore(){host.lifetime.cancel();host.detach();Object.assign(globalThis,{AudioBuffer:oldAudioBuffer});resetMediaRegistration();}};
}
test('T1062 实际range实现逐样本裁剪连续块并echo完整本地身份，decode不等于已听/采纳',async()=>{const f=rangeFixture();try{rangeBlocks=[block(0,[0,1,2,3]),block(.5,[4,5,6,7])];const response=await readOriginalAudioRange(f.p,undefined,()=>{});expect(response.status).toBe('decoded');expect(rangeStarts).toEqual([[.25,.75]]);expect(response).toMatchObject({owner:f.p.owner,nonce:f.p.nonce,clipId:f.p.clipId,sceneId:f.p.sceneId,contextEpoch:f.p.contextEpoch,assetFileId:f.p.assetFileId,sourceId:f.p.sourceId,rangeStartSeconds:.25,rangeEndSeconds:.75,videoFirstTimestamp:0,audioFirstTimestamp:0});expect(response.chunks.map(c=>c.timestamp)).toEqual([.25,.5]);expect(response.chunks.flatMap(c=>Array.from(c.buffer.getChannelData(0)))).toEqual([2,3,4,5]);expect(response).not.toHaveProperty('reviewed');expect(response).not.toHaveProperty('played');expect(rangeDisposeCount).toBe(1);}finally{f.restore();}});
test('T1062 合成负音频PTS不是视频zero；相邻解码重叠去重但不补零',async()=>{const f=rangeFixture();try{audioFirst=-.25;rangeBlocks=[block(-.25,[-2,-1,0,1,2,3]),block(.375,[3,4,5,6])];const response=await readOriginalAudioRange(f.p,undefined,()=>{});expect(response.status).toBe('decoded');expect(response.audioFirstTimestamp).toBe(-.25);expect(response.videoFirstTimestamp).toBe(0);expect(response.chunks.flatMap(c=>Array.from(c.buffer.getChannelData(0)))).toEqual([2,3,4,5]);expect(rangeDisposeCount).toBe(1);}finally{f.restore();}});
for(const mode of ['nonzero video','missing first coverage','hole','sample-rate change'] as const)test(`T1062 ${mode}仅该范围manual且Input释放，不伪造音频`,async()=>{const f=rangeFixture();try{if(mode==='nonzero video'){videoFirst=1;audioFirst=1.125;rangeBlocks=[block(1,[0,1,2,3])];}else if(mode==='missing first coverage')rangeBlocks=[block(.5,[4,5,6,7])];else if(mode==='hole'){f.p.sourceStartSeconds=0;f.p.sourceEndSeconds=1;rangeBlocks=[block(0,[0,1,2,3]),block(.75,[6,7])];}else rangeBlocks=[block(0,[0,1,2,3]),block(.5,[4,5,6,7],16)];const response=await readOriginalAudioRange(f.p,undefined,()=>{});expect(response.status).toBe('manual_review');expect(response.chunks).toEqual([]);expect(response).not.toHaveProperty('reviewed');expect(rangeDisposeCount).toBe(1);if(mode==='nonzero video')expect(rangeStarts).toEqual([]);}finally{f.restore();}});
for(const kind of ['request cancel','context seek','owner dispose'] as const)test(`T1062 ${kind}取消真实range实现；迟到块不得返回decoded/假完成`,async()=>{const f=rangeFixture();const signal=new AbortController();try{waitRange=true;rangeBlocks=[block(0,[0,1,2,3,4,5,6,7])];const pending=readOriginalAudioRange(f.p,signal.signal,()=>{});const observed=pending.catch(error=>error);for(let i=0;i<20&&!finishRead;i++)await Promise.resolve();expect(finishRead).toBeDefined();if(kind==='request cancel')signal.abort();else if(kind==='context seek')invalidateNativeContext({sceneId:'scene-exact',selectedElements:[],documentChanged:false});else f.lifetime.cancel();const error=await observed;expect(error.name).toBe('AbortError');expect(rangeDisposeCount).toBe(1);finishRead?.();await Promise.resolve();expect(error).not.toHaveProperty('chunks');}finally{f.restore();}});
test('T1062 foreign本地owner或当前真实scene/clip proof失败在读取Input之前拒绝',async()=>{const f=rangeFixture();try{await expect(readOriginalAudioRange({...f.p,owner:{...f.p.owner,projectId:'foreign-parent'}},undefined,()=>{})).rejects.toThrow('归属');await expect(readOriginalAudioRange(f.p,undefined,()=>{throw Error('真实scene或clip已改变');})).rejects.toThrow('已改变');expect(rangeStarts).toEqual([]);expect(rangeDisposeCount).toBe(0);}finally{f.restore();}});

test('T1062 纯组NULLaccount原声读取保持同group owner，平台账号筛选不改实际本地root',async()=>{const f=rangeFixture();try{nativeHost().owner={...nativeHost().owner,groupId:'group-a',accountId:null};f.p.owner={...nativeHost().owner};rangeBlocks=[block(0,[0,1,2,3,4,5,6,7])];const response=await readOriginalAudioRange(f.p,undefined,()=>{});expect(response.status).toBe('decoded');expect(response.owner).toEqual(f.p.owner);expect(response.owner.accountId).toBeNull();expect(nativeHost().owner).toEqual(f.p.owner);expect(rangeDisposeCount).toBe(1);}finally{f.restore();}});

test('T1069 第一份已完成素材立即交给编辑器，不等待第二份上传且取消不撤销已接管URL',async()=>{
 const first=new File(['one'],'one.mp4',{type:'video/mp4'}),second=new File(['two'],'two.mp4',{type:'video/mp4'});
 let secondStarted=false;const accepted:any[]=[];
 const host=fixture(async(file)=>{if(file===first)return{mediaId:'one'};secondStarted=true;return new Promise(()=>{});});
 created=[];revoked=[];
 const pending=processMediaAssets({files:[first,second],onProcessed:async(asset:any)=>{accepted.push(asset);}} as any);const observed=pending.catch(error=>error);
 try{for(let i=0;i<50&&!secondStarted;i++)await new Promise(resolve=>setTimeout(resolve,1));expect(secondStarted).toBe(true);expect(accepted.map(asset=>asset.name)).toEqual(['one.mp4']);
  host.lifetime.cancel();await observed;expect(revoked).not.toContain(accepted[0].url);
 }finally{host.lifetime.cancel();await observed;host.detach();resetMediaRegistration();}
});
test('T1069 原导入取消实际传递到宿主上传请求',async()=>{
 let uploadSignal:AbortSignal|undefined;
 const host=fixture(((_file:File,options?:{signal?:AbortSignal})=>{uploadSignal=options?.signal;return new Promise(()=>{});}) as any);
 const pending=registerMediaFile(new File(['x'],'cancel.mp4',{type:'video/mp4'}));const observed=pending.catch(error=>error);
 try{await Promise.resolve();host.lifetime.cancel();await observed;expect(uploadSignal).toBeDefined();expect(uploadSignal!.aborted).toBe(true);}
 finally{host.lifetime.cancel();await observed;host.detach();resetMediaRegistration();}
});
