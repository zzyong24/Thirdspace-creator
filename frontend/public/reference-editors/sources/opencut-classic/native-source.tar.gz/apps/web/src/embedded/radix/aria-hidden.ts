import {nativeHost} from '../native-host';
/** 无障碍隐藏只限定在原生工作面内部，应用其它区域保持可访问。 */
const hidden=new WeakMap<Element,{count:number;previous:string|null}>();
export function hideOthers(target:Element|Element[]){
 const targets=Array.isArray(target)?target:[target];const host=nativeHost();const selected:Element[]=[];
 function visit(node:Element){if(targets.some(target=>target===node||target.contains(node)))return;if(targets.some(target=>node.contains(target))){for(const child of node.children)visit(child);return;}const state=hidden.get(node)??{count:0,previous:node.getAttribute('aria-hidden')};state.count++;hidden.set(node,state);node.setAttribute('aria-hidden','true');selected.push(node);}
 visit(host.container);visit(host.portalContainer);
 let released=false;return()=>{if(released)return;released=true;for(const node of selected){const state=hidden.get(node);if(!state||--state.count>0)continue;if(state.previous===null)node.removeAttribute('aria-hidden');else node.setAttribute('aria-hidden',state.previous);hidden.delete(node);}};
}
export const suppressOthers=hideOthers;
export const inertOthers=hideOthers;
export const supportsInert=()=>false;
