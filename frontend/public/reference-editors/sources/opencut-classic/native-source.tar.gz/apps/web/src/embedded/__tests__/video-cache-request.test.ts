import {test,expect} from 'bun:test';
import {VideoCache} from '@/services/video-cache/service';

// 只替换 MediaBunny 解码器。原 VideoCache 请求队列、generation、帧校验与预取实际执行。
function fixture(initialTime=0){
 const cache=new VideoCache(),seeks:number[]=[];
 const frame=(timestamp:number)=>({timestamp,duration:1/24,canvas:{sourceFrame:Math.round(timestamp*24)}});
 const sink:any={currentFrame:frame(initialTime),nextFrame:null,iterator:null,lastTime:initialTime,prefetching:false,prefetchPromise:null,input:{dispose(){}},sink:{canvases(time:number){seeks.push(time);return(async function*(){for(let i=0;i<144;i++)yield frame((Math.round(time*24)+i)/24);})();}}};
 const state=cache as any;state.sinks.set('shared-media',sink);
 const file=new File(['decoder fixture'],'six-seconds.mp4',{type:'video/mp4'});
 const get=(time:number)=>cache.getFrameAt({mediaId:'shared-media',file,time});
 const valid=(actual:any,time:number)=>actual!==null&&actual.timestamp<=time&&time<actual.timestamp+actual.duration;
 async function concurrent(times:number[]){let release!:()=>void;state.frameChain.set('shared-media',new Promise<void>(resolve=>release=resolve));const work=times.map(get);await Promise.resolve();await Promise.resolve();release();return Promise.all(work);}
 return{cache,get,seeks,valid,concurrent};
}

test('候选首帧1秒与主画布0秒争用同媒体时，每个请求返回自己的时间范围',async()=>{
 const f=fixture(),frames=await f.concurrent([1,0]);
 console.log(JSON.stringify({probe:'trim-first-frame-shared-cache',requested:[1,0],returned:frames.map(frame=>frame?.timestamp),decoderSeeks:f.seeks}));
 expect(f.valid(frames[0],1)).toBe(true);expect(f.valid(frames[1],0)).toBe(true);
 await f.cache.drain();f.cache.clearAll();
},120000);

test('首尾、连续和重复时间的竞争都不能返回别的请求已缓存帧',async()=>{
 for(const times of [[1,0,2],[5.958333333333333,0,1],[1,1+1/24,1+2/24],[0,0,0]]){
  const f=fixture(),frames=await f.concurrent(times);
  for(let i=0;i<times.length;i++)expect(f.valid(frames[i],times[i])).toBe(true);
  await f.cache.drain();f.cache.clearAll();
 }
},120000);

test('同一已缓存帧仍复用；顺序播放保留原预取，只seek一次',async()=>{
 const f=fixture(),frames=await f.concurrent([0,0,0]);
 expect(frames[0]).toBe(frames[1]);expect(frames[1]).toBe(frames[2]);expect(f.seeks).toEqual([]);
 for(let i=24;i<48;i++){const time=i/24,frame=await f.get(time);expect(f.valid(frame,time)).toBe(true);}
 expect(f.seeks).toEqual([1]);await f.cache.drain();f.cache.clearAll();
},120000);
