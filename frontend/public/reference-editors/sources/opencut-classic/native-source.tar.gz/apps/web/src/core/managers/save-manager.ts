import type {EditorCore} from '@/core';
import {currentNativeHost} from '@/embedded/native-host';
export class SaveManager {
 private debounceMs:number;private editor:EditorCore;private isPaused=false;private stopped=false;private hasPendingSave=false;private saveTimer:ReturnType<typeof setTimeout>|null=null;private unsubscribers:Array<()=>void>=[];private work:Promise<void>|null=null;
 constructor({editor,debounceMs=800}:{editor:EditorCore;debounceMs?:number}){this.editor=editor;this.debounceMs=debounceMs;}
 start(){this.stopped=false;if(this.unsubscribers.length)return;this.unsubscribers=[this.editor.scenes.subscribe(()=>this.markDirty()),this.editor.timeline.subscribe(()=>this.markDirty())];}
 stop(){this.stopped=true;this.unsubscribers.forEach(fn=>fn());this.unsubscribers=[];this.clearTimer();this.hasPendingSave=false;}
 pause(){this.isPaused=true;this.clearTimer();}
 resume(){if(this.stopped)return;this.isPaused=false;if(this.hasPendingSave)this.queueSave();}
 markDirty({force=false}:{force?:boolean}={}){if(this.stopped||this.isPaused&&!force)return;this.hasPendingSave=true;this.queueSave();}
 async flush(){if(this.stopped)return;this.hasPendingSave=true;await this.saveNow();}
 getIsDirty(){return this.hasPendingSave||!!this.work;}
 private queueSave(){if(this.stopped||this.work)return;this.clearTimer();this.saveTimer=setTimeout(()=>{void this.saveNow().catch(error=>{const host=currentNativeHost();if(host&&!host.lifetime.signal.aborted)host.onError(error instanceof Error?error.message:'自动保存未完成。');});},this.debounceMs);}
 private async saveNow():Promise<void>{if(this.work){await this.work;if(this.hasPendingSave&&!this.stopped)await this.saveNow();return;}if(this.stopped||!this.hasPendingSave)return;const host=currentNativeHost();if(host?.lifetime.signal.aborted)return;const project=this.editor.project.getActiveOrNull();if(!project||this.editor.project.getIsLoading()||this.editor.project.getMigrationState().isMigrating)return;this.hasPendingSave=false;this.clearTimer();const execute=()=>this.editor.project.saveCurrentProject();this.work=host?host.lifetime.run(execute):execute();try{await this.work;}finally{this.work=null;if(this.hasPendingSave&&!this.stopped&&!this.isPaused)this.queueSave();}}
 private clearTimer(){if(this.saveTimer){clearTimeout(this.saveTimer);this.saveTimer=null;}}
}
