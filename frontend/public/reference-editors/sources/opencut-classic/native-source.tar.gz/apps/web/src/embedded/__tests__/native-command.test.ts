import {test,expect,mock} from 'bun:test';
Object.assign(globalThis,{location:{origin:'http://localhost',hash:'#/?session=test'},window:{parent:{postMessage(){}},addEventListener(){},removeEventListener(){},dispatchEvent(){return true;}}});
mock.module('@/wasm',()=>({TICKS_PER_SECOND:120000,ZERO_MEDIA_TIME:0,...Object.fromEntries(['mediaTime','roundMediaTime','mediaTimeFromSeconds','mediaTimeToSeconds','addMediaTime','subMediaTime','maxMediaTime','minMediaTime','clampMediaTime','roundFrameTime','roundFrameTicks','snapSeekMediaTime','lastFrameMediaTime','parseMediaTimecode'].map(name=>[name,(v:any)=>v.time??v.ticks??0]))}));
let editor:any;
mock.module('@/core',()=>({EditorCore:{getInstance:()=>editor}}));
const {ScenesManager}=await import('../../core/managers/scenes-manager');
const {CommandManager}=await import('../../core/managers/commands');
const {NativeTracksSnapshotCommand}=await import('../../commands/timeline/native-tracks-snapshot');
function tracks(id:string){return {main:{id:'main-'+id,type:'video',elements:[{id:'clip-'+id,type:'video',startTime:240000,duration:480000,mediaId:'same-media',trimStart:0,trimEnd:0,params:{position:{x:0,y:0}}}]},overlay:[{id:'text-'+id,type:'text',elements:[{id:'caption-'+id,content:'独立文字',startTime:300000,duration:120000}]}],audio:[]};}
function setup(){const project:any={metadata:{id:'output-one'},currentSceneId:'scene-a',scenes:[]};let selection={selectedElements:[{trackId:'main-a',elementId:'clip-a'}]};editor={media:{getAssets:()=>[]},project:{getActive:()=>project,setActiveProject:({project:p}:any)=>Object.assign(project,p)},save:{markDirty(){}},selection:{getSnapshot:()=>structuredClone(selection),applySelectionPatch(){throw Error('不得改选区');},restoreSnapshot(){throw Error('不得改选区');}},timeline:{updateTracks:(t:any)=>editor.scenes.updateSceneTracks({tracks:t})},playback:{getCurrentTime:()=>360000}};editor.scenes=new ScenesManager(editor);editor.scenes.setScenes({scenes:[{id:'scene-a',tracks:tracks('a'),bookmarks:[]},{id:'scene-b',tracks:tracks('b'),bookmarks:[]}],activeSceneId:'scene-a'});editor.command=new CommandManager(editor);return editor;}
test('采纳命令跨scene撤销只恢复目标scene，其他scene最新编辑、选区和播放头保留',async()=>{const e=setup(),before=structuredClone(e.scenes.getScenes()[0].tracks),after=structuredClone(before);after.main.elements=[];e.command.execute({command:new NativeTracksSnapshotCommand({sceneId:'scene-a',outputId:'output-one',before,after} as any)});await e.scenes.switchToScene({sceneId:'scene-b'});const sceneB=structuredClone(e.scenes.getScenes()[1]);sceneB.tracks.overlay[0].elements[0].content='另场景后来改稿';e.scenes.setScenes({scenes:[e.scenes.getScenes()[0],sceneB]});e.command.undo();expect(e.scenes.getScenes()[0].tracks).toEqual(before);expect(e.scenes.getScenes()[1].tracks.overlay[0].elements[0].content).toBe('另场景后来改稿');expect(e.scenes.getActiveScene().id).toBe('scene-b');expect(e.playback.getCurrentTime()).toBe(360000);expect(e.selection.getSnapshot().selectedElements[0].elementId).toBe('clip-a');e.command.redo();expect(e.scenes.getScenes()[0].tracks).toEqual(after);expect(e.scenes.getScenes()[1].tracks).toEqual(sceneB.tracks);});
test('已闭合的after不被原生ripple二次重排独立图层',()=>{const e=setup();e.command.isRippleEnabled=true;const before=structuredClone(e.scenes.getScenes()[0].tracks),after=structuredClone(before);after.main.elements[0].duration=120000;e.command.execute({command:new NativeTracksSnapshotCommand({sceneId:'scene-a',outputId:'output-one',before,after} as any)});expect(e.scenes.getScenes()[0].tracks).toEqual(after);e.command.undo();e.command.redo();expect(e.scenes.getScenes()[0].tracks).toEqual(after);});

const {NativePatchReplay,nativeDigest,nativeJson}=await import('../native-operations');
test('完整beforeTracks包含独立轨；后来文字修改时零Command且原输入保留',async()=>{const e=setup(),before=structuredClone(e.scenes.getScenes()[0].tracks),after=structuredClone(before);after.main.elements=[];const digest=await nativeDigest(before);e.scenes.getScenes()[0].tracks.overlay[0].elements[0].content='后来手工修改';const replay=new NativePatchReplay();await expect(replay.apply(e,'adopt-one',{outputId:'output-one',sceneId:'scene-a',expectedBeforeDigest:digest,beforeTracks:before,afterTracks:after})).rejects.toMatchObject({status:409,code:'ConflictError'});expect(e.command.canUndo()).toBe(false);expect(e.scenes.getScenes()[0].tracks.main.elements).toHaveLength(1);expect(e.scenes.getScenes()[0].tracks.overlay[0].elements[0].content).toBe('后来手工修改');});
test('相同ACK重播一次Command，撤销后重播不重新写入after',async()=>{const e=setup(),before=structuredClone(e.scenes.getScenes()[0].tracks),after=structuredClone(before);after.main.elements=[];const p={outputId:'output-one',sceneId:'scene-a',expectedBeforeDigest:await nativeDigest(before),beforeTracks:before,afterTracks:after};const replay=new NativePatchReplay();const receipt=await replay.apply(e,'adopt-once',p);expect(await replay.apply(e,'adopt-once',structuredClone(p))).toBe(receipt);e.command.undo();expect(e.scenes.getScenes()[0].tracks).toEqual(before);expect(await replay.apply(e,'adopt-once',p)).toBe(receipt);expect(e.scenes.getScenes()[0].tracks).toEqual(before);expect(e.command.canUndo()).toBe(false);expect(e.command.canRedo()).toBe(true);await expect(replay.apply(e,'adopt-once',{...p,sceneId:'scene-b'})).rejects.toMatchObject({code:'ConflictError'});});
test('错owner/scene回执均不写时间轴',async()=>{for(const wrong of [{outputId:'other-output'},{sceneId:'missing'}]){const e=setup(),before=structuredClone(e.scenes.getScenes()[0].tracks),replay=new NativePatchReplay();await expect(replay.apply(e,'wrong',{outputId:'output-one',sceneId:'scene-a',expectedBeforeDigest:await nativeDigest(before),beforeTracks:before,afterTracks:before,...wrong})).rejects.toMatchObject({status:409});expect(e.command.canUndo()).toBe(false);}});
test('原采纳摘要异步核对期间取消请求，零Command且完整轨道保留',async()=>{const e=setup(),before=structuredClone(e.scenes.getScenes()[0].tracks),after=structuredClone(before);after.main.elements=[];const input={outputId:'output-one',sceneId:'scene-a',expectedBeforeDigest:await nativeDigest(before),beforeTracks:before,afterTracks:after};const signal=new AbortController();const pending=new NativePatchReplay().apply(e,'cancel-digest',input,()=>{if(signal.signal.aborted)throw new DOMException('请求已取消','AbortError');});signal.abort();await expect(pending).rejects.toMatchObject({name:'AbortError'});expect(e.command.canUndo()).toBe(false);expect(e.scenes.getScenes()[0].tracks).toEqual(before);});

// T-1403: 通过真实采纳入口验证现行合同，旧扩展不整体迁移。
test('采纳合同拒绝非法变更且保原稿/撤销栈，不让Zod错误泄漏错误类别',async()=>{
 const e=setup();e.media={getAssets:()=>[]};
 const before=structuredClone(e.scenes.getScenes()[0].tracks),after=structuredClone(before);
 after.main.elements[0].params.opacity=2;
 await expect(new NativePatchReplay().apply(e,'invalid-opacity',{outputId:'output-one',sceneId:'scene-a',expectedBeforeDigest:await nativeDigest(before),beforeTracks:before,afterTracks:after})).rejects.toMatchObject({status:409,code:'ConflictError'});
 expect(e.scenes.getScenes()[0].tracks).toEqual(before);expect(e.command.canUndo()).toBe(false);expect(e.command.canRedo()).toBe(false);
});
test('采纳合同保留旧未知字段/缺素材和其他scene，仅应用合法已知参数变更',async()=>{
 const e=setup();e.media={getAssets:()=>[]};
 e.scenes.getScenes()[0].tracks.main.elements[0].opaque={legacy:'原值'};
 const before=structuredClone(e.scenes.getScenes()[0].tracks),other=structuredClone(e.scenes.getScenes()[1]),after=structuredClone(before);
 after.main.elements[0].params.opacity=.5;
 await new NativePatchReplay().apply(e,'valid-opacity',{outputId:'output-one',sceneId:'scene-a',expectedBeforeDigest:await nativeDigest(before),beforeTracks:before,afterTracks:after});
 expect(e.scenes.getScenes()[0].tracks).toEqual(after);expect(e.scenes.getScenes()[1]).toEqual(other);expect(e.command.canUndo()).toBe(true);e.command.undo();expect(e.scenes.getScenes()[0].tracks).toEqual(before);
});

test('采纳合同使用持久化前值，保runtime File/url和旧扩展，撤销仍恢复原对象',async()=>{
 const e=setup(),file=new File(['source'],'source.mp4',{type:'video/mp4'}),clip=e.scenes.getScenes()[0].tracks.main.elements[0];
 clip.file=file;clip.url='blob:existing-original';clip.buffer=new Uint8Array([7]);clip.opaque={legacy:'原值'};
 const before=nativeJson(e.scenes.getScenes()[0].tracks) as any,after=structuredClone(before);
 after.main.elements[0].params.opacity=.4;
 await new NativePatchReplay().apply(e,'runtime-projection',{outputId:'output-one',sceneId:'scene-a',expectedBeforeDigest:await nativeDigest(e.scenes.getScenes()[0].tracks),beforeTracks:before,afterTracks:after});
 const applied=e.scenes.getScenes()[0].tracks.main.elements[0];expect(applied.file).toBe(file);expect(applied.url).toBe('blob:existing-original');expect(applied.buffer).toBe(clip.buffer);expect(nativeJson(e.scenes.getScenes()[0].tracks)).toEqual(after);
 e.command.undo();expect(e.scenes.getScenes()[0].tracks.main.elements[0].file).toBe(file);expect(nativeJson(e.scenes.getScenes()[0].tracks)).toEqual(before);
});
