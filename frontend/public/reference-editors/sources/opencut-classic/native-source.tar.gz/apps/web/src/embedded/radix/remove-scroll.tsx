import React,{useRef,useEffect} from 'react';
import {Slot} from '@radix-ui/react-slot';
import {nativeHost} from '../native-host';
function Scroll({children,as,forwardProps,enabled=true,removeScrollBar,inert,shards,allowPinchZoom,noIsolation,...props}:any){const ref=useRef<HTMLElement|null>(null);useEffect(()=>{if(!enabled)return;const roots=[nativeHost().container,nativeHost().portalContainer],previous=roots.map(root=>root.style.overflow);roots.forEach(root=>root.style.overflow='hidden');return()=>roots.forEach((root,i)=>root.style.overflow=previous[i]);},[enabled]);const Comp=forwardProps?Slot:as??'div';return <Comp {...props} ref={ref}>{children}</Comp>;}
export const RemoveScroll=Object.assign(Scroll,{classNames:{fullWidth:'native-scroll-full-width',zeroRight:'native-scroll-zero-right'}});
