import { EditorCore } from '@/core';
import { storageService } from '@/services/storage/service';
import { initializeGpuRenderer,isGpuAvailable } from '@/services/renderer/gpu-renderer';
import { buildDefaultScene } from '@/timeline/scenes';
import { DEFAULT_FPS } from '@/fps/defaults';
import { DEFAULT_CANVAS_SIZE } from '@/canvas/sizes';
import { CURRENT_PROJECT_VERSION } from './native-version';
import { processMediaAssets } from '@/media/processing';
import { resetMediaRegistration,rememberMediaFile } from './media-registration';
import { validMessage,send } from './protocol';
import type { TProject } from '@/project/types';
import type { MediaAsset } from '@/media/types';
import { ZERO_MEDIA_TIME } from '@/wasm';
import {exportFrozenSnapshot} from './frozen-export';
import {advanceEditEpoch} from './edit-lock';
import {NativePatchReplay,readNativeContext,seekNative} from './native-operations';
const patchReplay=new NativePatchReplay();
let loaded=false;
let queue=Promise.resolve();
const responses=new Map<string,{operation:string,payload:unknown}>();
function hydrateDocument(document:any,outputId:string):TProject {
 if(!document||document.version!==CURRENT_PROJECT_VERSION||!Array.isArray(document.scenes)||!document.settings?.fps||!document.metadata||document.metadata.id!==outputId)throw new Error('此剪辑工程版本或作品归属不匹配，请保留原稿另建新稿。');
 const copy=structuredClone(document);copy.metadata.createdAt=new Date(copy.metadata.createdAt);copy.metadata.updatedAt=new Date(copy.metadata.updatedAt);
 copy.scenes=copy.scenes.map((scene:any)=>({...scene,createdAt:new Date(scene.createdAt),updatedAt:new Date(scene.updatedAt)}));
 return copy;
}
async function load(payload:any){
 if(typeof payload?.outputId!=='string'||!payload.outputId||!Array.isArray(payload.media))throw new Error('作品和素材输入缺失。');
 advanceEditEpoch();loaded=false;window.dispatchEvent(new Event('creatoros-reference-loading'));
 const old=EditorCore.getInstance();old.playback.pause();old.save.stop();old.media.clearAllAssets();
 resetMediaRegistration();storageService.hostReset();EditorCore.reset();
 const editor=EditorCore.getInstance();editor.save.pause();
 const scene=buildDefaultScene({name:'主画面',isMain:true});
 const project=payload.document?hydrateDocument(payload.document,payload.outputId):{metadata:{id:payload.outputId,name:payload.title||'视频稿',duration:ZERO_MEDIA_TIME,createdAt:new Date(),updatedAt:new Date()},scenes:[scene],currentSceneId:scene.id,settings:{fps:DEFAULT_FPS,canvasSize:DEFAULT_CANVAS_SIZE,canvasSizeMode:'preset' as const,lastCustomCanvasSize:null,originalCanvasSize:null,background:{type:'color' as const,color:'#000000'}},version:CURRENT_PROJECT_VERSION};
 await storageService.saveProject({project});
 for(const item of payload.media){if(typeof item?.mediaId!=='string'||!item.mediaId||!(item.file instanceof File)||!['video','audio','image'].includes(item.type))throw new Error('素材缺少真实文件、ID或类型。');rememberMediaFile(item.file,item.mediaId);await storageService.saveMediaAsset({projectId:payload.outputId,mediaAsset:{...item,id:item.mediaId,file:item.file,url:URL.createObjectURL(item.file),name:item.name||item.file.name} as MediaAsset});}
 await initializeGpuRenderer();editor.renderer.setDegraded(!isGpuAvailable());await editor.project.loadProject({id:payload.outputId});
 storageService.hostLoaded();loaded=true;window.dispatchEvent(new Event('creatoros-reference-loaded'));
 return {editor:'opencut-classic',documentVersion:CURRENT_PROJECT_VERSION};
}
async function operate(operation:string,payload:any,requestId:string){
 if(operation==='load')return load(payload);
 if(!loaded)throw new Error('请先载入当前作品。');
 const editor=EditorCore.getInstance();
 if(operation==='snapshot'){await editor.save.flush();return storageService.snapshot();}
 if(operation==='context'){await editor.save.flush();return readNativeContext(editor,storageService.snapshot());}
 if(operation==='seek')return seekNative(editor,payload);
 if(operation==='apply-tracks')return patchReplay.apply(editor,requestId,payload);
 if(operation==='export')return exportFrozenSnapshot(editor,payload?.format==='webm'?'webm':'mp4');
 if(operation==='insert-media'){if(!(payload?.file instanceof File)||typeof payload.mediaId!=='string'||!payload.mediaId)throw new Error('素材文件与ID缺失。');rememberMediaFile(payload.file,payload.mediaId);const assets=await processMediaAssets({files:[payload.file]});if(assets.length!==1)throw new Error('此素材无法处理。');const asset=await editor.media.addMediaAsset({projectId:editor.project.getActive().metadata.id,asset:assets[0]});if(!asset)throw new Error('加入素材失败。');return {mediaId:asset.id};}
 throw new Error('此编辑操作尚不支持。');
}
export function startBridge(){
 window.addEventListener('creatoros-reference-changed',()=>send('changed',{dirty:true}));
 window.addEventListener('message',(event)=>{if(!validMessage(event))return;const m=event.data;if(!['load','snapshot','export','insert-media','context','seek','apply-tracks'].includes(m.operation))return;
 queue=queue.then(async()=>{const old=m.operation==='apply-tracks'?undefined:responses.get(m.requestId);if(old){send(old.operation,old.payload,m.requestId);return;}let operation='result';let payload:unknown;try{payload={operation:m.operation,...await operate(m.operation,m.payload,m.requestId)};}catch(error){operation='error';payload={operation:m.operation,message:error instanceof Error?error.message:'编辑操作失败。',...((error as any)?.code?{code:(error as any).code,status:(error as any).status}:{})};window.dispatchEvent(new CustomEvent('creatoros-reference-error',{detail:(payload as any).message}));}responses.set(m.requestId,{operation,payload});if(responses.size>100)responses.delete(responses.keys().next().value!);send(operation,payload,m.requestId);});
 });
 send('ready',{editor:'opencut-classic',sourceCommit:'cf5e79e919144200294fb9fed22a222592a0aeea',documentVersion:CURRENT_PROJECT_VERSION});
}
