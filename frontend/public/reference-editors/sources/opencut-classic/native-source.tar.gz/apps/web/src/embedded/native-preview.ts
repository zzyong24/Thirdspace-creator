import type {EditorCore} from '@/core';
import type {TProject} from '@/project/types';
import type {MediaAsset} from '@/media/types';
import type {SceneTracks} from '@/timeline';
import {mediaTime,TICKS_PER_SECOND} from '@/wasm';
import {beginExportLock} from './edit-lock';
import {nativeHost,currentNativeContextEpoch,type NativeOwner} from './native-host';
import {getRegisteredMediaId} from './media-registration';
import {canonicalNative,nativeDigest,nativeJson,NativeOperationError} from './native-operations';
import {validateNativeSceneTracksCandidate,type NativeSerializedTimelineTracks} from './native-document-contract';
export type NativePreviewMedia={mediaId:string;assetId:string;assetFileId:string;file:File;name:string;type:'video'|'audio'|'image';size:number;lastModified:number;width?:number;height?:number;duration?:number;fps?:number;hasAudio?:boolean};
export type NativePreviewSceneRequest={owner:NativeOwner;targetSceneId:string;baseContextEpoch:number;beforeDigest:string;candidateDigest:string;tracks:SceneTracks;media:NativePreviewMedia[]};
export type NativePreviewSceneResult={blob:Blob;fileName:string;sceneId:string;candidateDigest:string;contextEpoch:number;documentVersion:31};
const conflict=(message:string)=>new NativeOperationError(message);
function descriptor(asset:MediaAsset){return {mediaId:asset.id,name:asset.name,type:asset.type,size:asset.file.size,lastModified:asset.file.lastModified,width:asset.width,height:asset.height,duration:asset.duration,fps:asset.fps,hasAudio:asset.hasAudio};}
async function fileDigest(file:File){return new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer())).join(',');}
// SEMANTIC_BOUNDARY_ALLOW: 仅核真实owner、完整前值、exact文件字节、typed变动和tick；不选择创作内容。
export async function previewNativeScene(editor:EditorCore,input:NativePreviewSceneRequest,check:()=>void=()=>{},waitForImports:()=>Promise<void>=async()=>{},hasPendingImports:()=>boolean=()=>false):Promise<NativePreviewSceneResult>{
 const p:NativePreviewSceneRequest={...input,owner:{...input.owner},tracks:structuredClone(nativeJson(input.tracks)) as SceneTracks,media:input.media.map(item=>({...item}))};
 const host=nativeHost();
 if(!Number.isSafeInteger(p.baseContextEpoch)||p.baseContextEpoch<0||![p.beforeDigest,p.candidateDigest].every(value=>typeof value==='string'&&/^sha256:[a-f0-9]{64}$/.test(value)))throw conflict('候选预览缺少真实上下文或摘要。');
 const assert=()=>{host.lifetime.assertCurrent();check();if(currentNativeContextEpoch()!==p.baseContextEpoch)throw conflict('预览选区或工程已改变，请重新读取当前稿件。');if(canonicalNative(p.owner)!==canonicalNative(host.owner))throw conflict('候选预览不属于当前作品。');};
 assert();await waitForImports();assert();
 if(editor.playback.getIsPlaying()||editor.media.isLoadingMedia()||editor.save.getIsDirty())throw conflict('请先完成原素材导入和保存，暂停预览后读取当前稿件。');
 const sourceProject=editor.project.getActive(),sourceScene=editor.scenes.getActiveScene();
 if(sourceProject.version!==31||sourceProject.metadata.id!==host.owner.outputId||sourceScene.id!==p.targetSceneId)throw conflict('候选预览工程或场景不匹配。');
 const originalProject=canonicalNative(nativeJson({...sourceProject,scenes:editor.scenes.getScenes()}));
 const beforeTracks=canonicalNative(nativeJson(sourceScene.tracks));
 const currentAssets=editor.media.getAssets().map(asset=>({...asset}));const originalMedia=canonicalNative(currentAssets.map(descriptor));
 if(!Array.isArray(p.media)||p.media.length!==currentAssets.length)throw conflict('候选预览素材目录已改变。');
 const mediaIds=new Set<string>();
 for(const item of p.media){
  assert();const actual=currentAssets.find(asset=>asset.id===item.mediaId);
  if(!actual||mediaIds.has(item.mediaId)||typeof item.assetId!=='string'||!item.assetId||typeof item.assetFileId!=='string'||!item.assetFileId||!(item.file instanceof File)||getRegisteredMediaId(actual.file)!==item.mediaId)throw conflict('候选预览缺少真实登记的素材文件。');
  mediaIds.add(item.mediaId);
  const {file,assetId,assetFileId,...metadata}=item;
  if(canonicalNative(metadata)!==canonicalNative(descriptor(actual))||file.type!==actual.file.type||file.size!==actual.file.size||file.lastModified!==actual.file.lastModified)throw conflict('候选预览素材元信息已改变。');
  // load携带的exact身份可比对；旧已挂载源没有该附加字段时仍核注册File的完整字节，不伪造服务器授权。
  const exact=actual as MediaAsset&{assetId?:string;assetFileId?:string};
  if(exact.assetId!==undefined&&exact.assetId!==assetId||exact.assetFileId!==undefined&&exact.assetFileId!==assetFileId)throw conflict('候选预览素材文件版本已改变。');
  if(file!==actual.file&&await fileDigest(file)!==await fileDigest(actual.file))throw conflict('候选预览素材字节与已登记原文件不同。');
  assert();
 }
 const tracks=structuredClone(nativeJson(p.tracks)) as SceneTracks;
 validateNativeSceneTracksCandidate(nativeJson(sourceScene.tracks) as NativeSerializedTimelineTracks,tracks as unknown as NativeSerializedTimelineTracks,currentAssets.map(asset=>({mediaId:asset.id,kind:asset.type,durationTick:typeof asset.duration==='number'?Math.round(asset.duration*TICKS_PER_SECOND):null})));
 if(p.beforeDigest!==await nativeDigest(sourceScene.tracks)||p.candidateDigest!==await nativeDigest({...nativeJson(sourceScene) as object,tracks}))throw conflict('候选预览摘要与当前完整场景不一致。');
 const assertFrozen=()=>{assert();if(hasPendingImports()||editor.media.isLoadingMedia())throw conflict('原素材导入仍在进行，候选预览未取得处理锁。请等待原导入完成后重新核对。');if(editor.scenes.getActiveScene().id!==p.targetSceneId||canonicalNative(nativeJson({...editor.project.getActive(),scenes:editor.scenes.getScenes()}))!==originalProject||canonicalNative(nativeJson(editor.scenes.getActiveScene().tracks))!==beforeTracks||canonicalNative(editor.media.getAssets().map(descriptor))!==originalMedia||editor.media.getAssets().some((asset,i)=>asset.file!==currentAssets[i]?.file))throw conflict('候选预览核对期间原工程或素材发生改变。');};
 assertFrozen();
 let duration=0;for(const track of [tracks.main,...tracks.overlay,...tracks.audio])for(const element of track.elements){const end=element.startTime+element.duration;if(!Number.isSafeInteger(end)||end<0)throw conflict('候选预览时间码无效。');duration=Math.max(duration,end);}
 const project=structuredClone({...sourceProject,scenes:editor.scenes.getScenes()}) as TProject;
 project.scenes=project.scenes.map(scene=>scene.id===p.targetSceneId?{...scene,tracks}:scene);
 project.metadata={...project.metadata,duration:mediaTime({ticks:duration})};
 const mediaAssets=currentAssets.map(asset=>({...asset}));
 const cancel=()=>{try{assertFrozen();return false;}catch{return true;}};
 // 文件和SHA核对之后必须同步重核真实导入状态；该检查与取得锁之间没有await，不取消原导入。
 assertFrozen();const unlock=beginExportLock();
 try{
  assertFrozen();const result=await editor.renderer.exportProject({options:{format:'mp4',quality:'high',includeAudio:true,fps:project.settings.fps},onCancel:cancel,frozen:{tracks,project,mediaAssets,duration:mediaTime({ticks:duration})}});
  assertFrozen();if(!result.success||!result.buffer)throw Error(result.error||'候选视频预览未生成，请保留原请求核对。');
  return{blob:new Blob([result.buffer],{type:'video/mp4'}),fileName:`${project.metadata.name}-preview.mp4`,sceneId:p.targetSceneId,candidateDigest:p.candidateDigest,contextEpoch:p.baseContextEpoch,documentVersion:31};
 }finally{unlock();}
}
