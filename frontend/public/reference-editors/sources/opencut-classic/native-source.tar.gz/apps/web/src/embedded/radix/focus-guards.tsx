import React,{useEffect} from 'react';
import {nativePortal} from '../native-host';
export function useFocusGuards(){useEffect(()=>{const portal=nativePortal();const guards=[0,1].map(()=>{const node=document.createElement('span');node.tabIndex=0;node.dataset.radixFocusGuard='';Object.assign(node.style,{outline:'none',opacity:'0',position:'absolute',pointerEvents:'none'});return node;});portal.prepend(guards[0]);portal.append(guards[1]);return()=>guards.forEach(node=>node.remove());},[]);}
export function FocusGuards({children}:{children:React.ReactNode}){useFocusGuards();return <>{children}</>;}
export const Root=FocusGuards;
