import {Command,type CommandResult} from '@/commands/base-command';
import {EditorCore} from '@/core';
import type {SceneTracks} from '@/timeline';
function cloneRuntime<T>(v:T):T {if(Array.isArray(v))return v.map(cloneRuntime) as T;if(v&&typeof v==='object'){if(v instanceof Date)return new Date(v) as T;if(Object.getPrototypeOf(v)!==Object.prototype)return v;return Object.fromEntries(Object.entries(v).map(([k,value])=>[k,cloneRuntime(value)])) as T;}return v;}
/** SEMANTIC_BOUNDARY_ALLOW: 明确scene的已采纳轨道回执；只机械替换该scene，不判断剪辑内容。 */
export class NativeTracksSnapshotCommand extends Command {
 readonly handlesRipple=true;
 private readonly before:SceneTracks;
 private readonly after:SceneTracks;
 constructor(private readonly scope:{outputId:string;sceneId:string;before:SceneTracks;after:SceneTracks}){super();this.before=cloneRuntime(scope.before);this.after=cloneRuntime(scope.after);}
 private replace(tracks:SceneTracks){
  const editor=EditorCore.getInstance();
  if(editor.project.getActive()?.metadata.id!==this.scope.outputId)throw Error('已切换作品，原剪辑命令停止。');
  const scenes=editor.scenes.getScenes();
  if(!scenes.some(s=>s.id===this.scope.sceneId))throw Error('原场景已不存在，当前工程保留。');
  editor.scenes.setScenes({scenes:scenes.map(s=>s.id===this.scope.sceneId?{...s,tracks:cloneRuntime(tracks),updatedAt:new Date()}:s)});
 }
 execute():CommandResult|undefined{this.replace(this.after);return undefined;}
 undo(){this.replace(this.before);}
}
