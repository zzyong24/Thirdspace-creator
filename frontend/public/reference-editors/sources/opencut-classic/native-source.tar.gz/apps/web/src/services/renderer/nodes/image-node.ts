import {currentNativeHost} from '@/embedded/native-host';
import {stopped} from '@/embedded/native-lifecycle';
import {
	VisualNode,
	type ResolvedVisualSourceNodeState,
	type VisualNodeParams,
} from "./visual-node";

export interface ImageNodeParams extends VisualNodeParams {
	url: string;
	maxSourceSize?: number;
}

export interface CachedImageSource {
	source: HTMLImageElement | OffscreenCanvas;
	width: number;
	height: number;
}

const imageSourceCache = new Map<string, Promise<CachedImageSource>>();
const imageSources=new Set<HTMLImageElement|OffscreenCanvas>();
export function clearImageSources(){imageSourceCache.clear();for(const source of imageSources){if(source instanceof HTMLImageElement){source.onload=null;source.onerror=null;source.removeAttribute('src');source.remove();}else{source.width=1;source.height=1;}}imageSources.clear();}

export function loadImageSource({
	url,
	maxSourceSize,
}: {
	url: string;
	maxSourceSize?: number;
}): Promise<CachedImageSource> {
	const cacheKey = `${url}::${maxSourceSize ?? "full"}`;

	const cached = imageSourceCache.get(cacheKey);
	if (cached) return cached;

	const promise = (async (): Promise<CachedImageSource> => {
		const image = new Image();imageSources.add(image);const signal=currentNativeHost()?.lifetime.signal;

		await new Promise<void>((resolve, reject) => {
			const cleanup=()=>{signal?.removeEventListener('abort',abort);image.onload=null;image.onerror=null;};const abort=()=>{cleanup();image.removeAttribute('src');image.remove();imageSources.delete(image);reject(stopped());};image.onload=()=>{cleanup();resolve();};image.onerror=()=>{cleanup();imageSources.delete(image);reject(new Error('Image load failed'));};signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted){abort();return;}image.src=url;
		});

		const naturalWidth = image.naturalWidth;
		const naturalHeight = image.naturalHeight;
		const exceedsLimit =
			maxSourceSize &&
			(naturalWidth > maxSourceSize || naturalHeight > maxSourceSize);

		if (exceedsLimit) {
			const scale = Math.min(
				maxSourceSize / naturalWidth,
				maxSourceSize / naturalHeight,
			);
			const scaledWidth = Math.round(naturalWidth * scale);
			const scaledHeight = Math.round(naturalHeight * scale);

			const offscreen = new OffscreenCanvas(scaledWidth, scaledHeight);imageSources.add(offscreen);
			const ctx = offscreen.getContext("2d");

			if (ctx) {
				ctx.drawImage(image, 0, 0, scaledWidth, scaledHeight);
				return { source: offscreen, width: scaledWidth, height: scaledHeight };
			}
		}

		return { source: image, width: naturalWidth, height: naturalHeight };
	})();

	imageSourceCache.set(cacheKey, promise);
	return promise;
}

export class ImageNode extends VisualNode<
	ImageNodeParams,
	ResolvedVisualSourceNodeState
> {}
