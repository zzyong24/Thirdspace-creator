import { useLayoutEffect, useSyncExternalStore, type ReactNode } from "react";
import {
  nativeWorkspaceSnapshot,
  subscribeNativeWorkspace,
  openNativeAddon,
  nativeHost,
  syncNativeInteractivity,
  type NativeAddonPanel,
} from "./native-host";
import { isExportLocked } from "./edit-lock";
export function WorkspacePanel({side,children,properties}:{side:"left"|"right";children?:ReactNode;properties?:ReactNode}) {
 const state=useSyncExternalStore(subscribeNativeWorkspace,nativeWorkspaceSnapshot,nativeWorkspaceSnapshot);
 useLayoutEffect(()=>syncNativeInteractivity(nativeHost(),isExportLocked()),[state]);
 const selected=state.split(':')[0];
 const panels:[NativeAddonPanel,string][]=[["assets","素材"],["transcript","转写"],["properties","属性"]];
 if(side==='right')return <div className="native-workspace-panel"><div id="native-panel-director" role="region" aria-label="AI 剪辑助手" className="native-workspace-content native-workspace-addon"><slot name="creatoros-director"/></div></div>;
 return <div className="native-workspace-panel">
  <div role="tablist" aria-label="素材、转写与属性" className="native-workspace-tabs">{panels.map(([panel,label],index)=><button key={panel} id={`native-tab-${panel}`} type="button" role="tab" aria-selected={selected===panel} aria-controls={`native-panel-${panel}`} tabIndex={selected===panel?0:-1} onClick={()=>openNativeAddon({panel})} onKeyDown={event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const nextIndex=event.key==='Home'?0:event.key==='End'?panels.length-1:(index+(event.key==='ArrowRight'?1:-1)+panels.length)%panels.length;const next=panels[nextIndex]![0];openNativeAddon({panel:next});event.currentTarget.parentElement?.querySelector<HTMLButtonElement>(`#native-tab-${next}`)?.focus();}}>{label}</button>)}</div>
  <p className="shrink-0 border-b border-border px-3 py-2 text-xs text-muted-foreground">素材选原片，转写看文字；选中时间轴片段后在属性调整。画面用于预览。</p>
  <div id="native-panel-assets" role="tabpanel" aria-labelledby="native-tab-assets" data-native-core-panel hidden={selected!=='assets'} inert={selected!=='assets'} className="native-workspace-content native-workspace-core-content"><div className="native-workspace-materials"><slot name="creatoros-materials"/></div><div className="native-workspace-core-body">{children}</div></div>
  <div id="native-panel-transcript" role="tabpanel" aria-labelledby="native-tab-transcript" hidden={selected!=='transcript'} inert={selected!=='transcript'} className="native-workspace-content native-workspace-addon"><slot name="creatoros-transcript"/></div>
  <div id="native-panel-properties" role="tabpanel" aria-labelledby="native-tab-properties" data-native-core-panel hidden={selected!=='properties'} inert={selected!=='properties'} className="native-workspace-content native-workspace-core-content"><div className="native-workspace-core-body">{properties}</div></div>
 </div>;
}
