import React from 'react';
import {NativeVisibilityContext} from './native-visibility';
import {EditorCore} from '@/core';
import {createRoot,type Root} from 'react-dom/client';
import {flushSync} from 'react-dom';
import {Toaster,toast} from 'sonner';
import {TooltipProvider} from '@/components/ui/tooltip';
import {EditorHeader} from '@/components/editor/editor-header';
import {EditorLayout} from './editor-layout';
import {EditorRuntimeBindings} from '@/components/providers/editor-provider';
import {DocumentLease,NativeLifetime,stopped} from './native-lifecycle';
import {installNativeHost,applyNativeTheme,type NativeOwner,type NativeTheme,type NativeHost} from './native-host';
import {createNativeController,destroyNativeCore} from './native-controller';
import {advanceEditEpoch,isExportLocked} from './edit-lock';
import {cancelPendingMediaImports} from './media-registration';
import './native.css';
const lease=new DocumentLease();
export type NativeOptions={owner:NativeOwner;theme:NativeTheme;portalContainer:HTMLElement;signal:AbortSignal;onChanged:NativeHost['onChanged'];onImportActivity?:NativeHost['onImportActivity'];onError:(message:string)=>void;importMedia:(file:File,options?:{signal?:AbortSignal})=>Promise<{mediaId:string}>};
function NativeApp({loaded,generation,exporting,theme,visible}:{loaded:boolean;generation:number;exporting:boolean;theme:NativeTheme;visible:boolean}){return <NativeVisibilityContext.Provider value={visible}><TooltipProvider><Toaster theme={theme.mode} position="bottom-right" toastOptions={{className:'native-toast'}}/>{loaded?<div key={generation} className="native-workbench"><EditorRuntimeBindings/><EditorHeader/><div className="min-h-0 min-w-0 flex-1"><EditorLayout/></div></div>:<div className="native-loading" role="status">正在载入视频稿…</div>}{exporting&&<div role="status" aria-live="polite" className="native-export-status">正在导出当前稿，完成后可以继续编辑…</div>}</TooltipProvider></NativeVisibilityContext.Provider>;}
export async function mount(container:HTMLElement,options:NativeOptions){
 if(!(container instanceof HTMLElement)||!(options.portalContainer instanceof HTMLElement)||container.getRootNode()!==options.portalContainer.getRootNode())throw Error('剪辑容器与弹层容器必须属于同一工作面。');
 if(!options.owner.projectId||!options.owner.outputId||!options.owner.sourceVersionId||(!options.owner.groupId&&!options.owner.accountId))throw Error('作品归属缺失。');
 const life=new NativeLifetime(options.signal);let release=()=>{},uninstall=()=>{},root:Root|null=null,closing:Promise<void>|null=null,ownsLease=false;let controller:ReturnType<typeof createNativeController>|null=null;
 const dispose=():Promise<void>=>{if(closing)return closing;closing=Promise.resolve().then(async()=>{if(root){flushSync(()=>root!.unmount());root=null;}const coreClosed=controller?destroyNativeCore():Promise.resolve();await life.drain();await coreClosed;if(controller){controller.clear();controller=null;toast.dismiss();(toast as typeof toast&{nativeReset?:()=>void}).nativeReset?.();}uninstall();if(ownsLease){options.portalContainer.replaceChildren();container.replaceChildren();container.inert=false;options.portalContainer.inert=false;}release();});life.cancel();if(controller){advanceEditEpoch();cancelPendingMediaImports('作品已切换。');}return closing;};
 try{release=await lease.acquire(life.signal,dispose);ownsLease=true;life.assertCurrent();const host:NativeHost={container,portalContainer:options.portalContainer,owner:Object.freeze({...options.owner}),theme:options.theme,lifetime:life,disabled:false,visible:true,onImportActivity:options.onImportActivity,onChanged:options.onChanged,onError:options.onError,importMedia:options.importMedia};uninstall=installNativeHost(host);container.dataset.nativeRoot='opencut';options.portalContainer.dataset.nativePortal='opencut';container.tabIndex=0;container.inert=false;options.portalContainer.inert=false;applyNativeTheme(container,host.theme);applyNativeTheme(options.portalContainer,host.theme);root=createRoot(container);let loaded=false,exporting=false,generation=0;const render=()=>{if(!root||life.signal.aborted)return;flushSync(()=>root!.render(<NativeApp loaded={loaded} exporting={exporting} generation={generation} theme={host.theme} visible={host.visible!==false}/>));};controller=createNativeController(state=>{const wasLoaded=loaded;loaded=state.loaded;exporting=state.exporting??false;if(loaded&&!wasLoaded)generation++;render();});render();
 const abort=()=>void dispose();life.signal.addEventListener('abort',abort,{once:true});
 return {request:(operation:string,payload?:unknown,requestOptions?:{requestId?:string;signal?:AbortSignal})=>{life.assertCurrent();return controller!.request(operation,payload,requestOptions).catch(error=>{if(!life.signal.aborted&&error?.name!=='AbortError')host.onError(error instanceof Error?error.message:'编辑操作未完成。');throw error;});},update(update:{theme?:NativeTheme;disabled?:boolean;visible?:boolean}){life.assertCurrent();if(update.visible!==undefined&&host.visible!==update.visible){host.visible=update.visible;if(!update.visible&&loaded)EditorCore.getInstance().playback.pause();render();}if(update.theme){host.theme=update.theme;applyNativeTheme(container,host.theme);applyNativeTheme(options.portalContainer,host.theme);render();}if(update.disabled!==undefined){host.disabled=update.disabled;}container.inert=host.disabled||host.visible===false||isExportLocked();options.portalContainer.inert=container.inert;},dispose};
 }catch(error){await dispose();throw error;}
}
