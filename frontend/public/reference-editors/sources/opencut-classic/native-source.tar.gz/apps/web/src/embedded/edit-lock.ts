import {nativeHost,currentNativeHost} from './native-host';
let exporting=false,epoch=0,epochController=new AbortController();const importedAssets=new WeakMap<object,number>();
export function isExportLocked(){return exporting;}
export function currentEditEpoch(){return epoch;}
export function currentEditSignal(){return epochController.signal;}
export function advanceEditEpoch(){epoch++;epochController.abort();epochController=new AbortController();}
export function assertEditable(){const host=currentNativeHost();host?.lifetime.assertCurrent();if(exporting)throw Error('当前剪辑稿正在处理，请完成后再编辑。');}
export function assertImportEpoch(captured:number){assertEditable();if(captured!==epoch)throw Error('作品已切换或正在导出，请重新加入素材。');}
export function stampImportedAsset(asset:object,captured:number){assertImportEpoch(captured);importedAssets.set(asset,captured);}
export function assertImportedAssetCurrent(asset:object){assertEditable();const captured=importedAssets.get(asset);if(captured!==undefined)assertImportEpoch(captured);}
export function beginExportLock(){assertEditable();const h=nativeHost();exporting=true;advanceEditEpoch();const roots=[h.container,h.portalContainer],old=roots.map(root=>root.inert);roots.forEach(root=>root.inert=true);let released=false;return()=>{if(released)return;released=true;exporting=false;advanceEditEpoch();roots.forEach(root=>root.inert=h.disabled);};}
