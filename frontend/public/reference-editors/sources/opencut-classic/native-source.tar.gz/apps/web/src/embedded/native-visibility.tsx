import {createContext,useContext} from 'react';
export const NativeVisibilityContext=createContext(true);
export const useNativeVisibility=()=>useContext(NativeVisibilityContext);
