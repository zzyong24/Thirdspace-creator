import {readFileSync,writeFileSync,mkdirSync,readdirSync,statSync} from 'node:fs';
import {resolve,dirname,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {build} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import wasm from 'vite-plugin-wasm';
import postcss from 'postcss';
const domFixture=process.argv.includes('--dom-fixture');
// SEMANTIC_BOUNDARY_ALLOW: 仅核原构建插件声明的虚拟模块身份，不做内容/创作选择。
const wasmPlugin=wasm();
const app=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const source=resolve(app,'src/embedded/native.css');
const require=createRequire(resolve(app,'package.json'));const sonnerSource=readFileSync(resolve(dirname(require.resolve('sonner')),'index.mjs'),'utf8');
const sonnerInjection=/\b[A-Za-z_$][\w$]*\(`(:where\(html[\s\S]*?)`\);/g;const sonnerMatches=[...sonnerSource.matchAll(sonnerInjection)].filter(match=>match[1].includes('data-sonner-toaster'));if(sonnerMatches.length!==1)throw Error('通知库样式注入形状已改变，不能安全完成原生作用域构建。');
const sonnerCss=sonnerMatches[0][1];
const sonnerStore=/[A-Za-z_$][\w$]*=\(\)=>([A-Za-z_$][\w$]*)\.toasts,/.exec(sonnerSource)?.[1],sonnerToast=/([A-Za-z_$][\w$]*) as toast/.exec(sonnerSource)?.[1];if(!sonnerStore||!sonnerToast)throw Error('通知库临时状态接口形状已改变，不能安全完成原生构建。');
const ast=postcss.parse(readFileSync(resolve(app,'src/app/globals.css'),'utf8'));
ast.walkRules(rule=>{if([':root','.panel','.dark','.dark .panel'].includes(rule.selector.trim()))rule.remove();else{rule.selector=rule.selector.replace(/\bbody\b/g,'[data-native-root]').replace(/\bhtml\b/g,':host').replace(/:root/g,':host');}});
let css=(ast.toString()+'\n'+sonnerCss).replace('@import "tailwindcss";','@import "tailwindcss" source(none);\n@source "../";');
css+=`\n:host,[data-native-root],[data-native-portal]{
 --background:var(--creatoros-canvas,#ffffff);--foreground:var(--creatoros-text,#181b23);
 --card:var(--creatoros-surface,#fff);--card-foreground:var(--foreground);
 --popover:var(--creatoros-surface,#fff);--popover-foreground:var(--foreground);--popover-hover:var(--creatoros-surface-subtle,#f5f5f5);
 --primary:var(--creatoros-brand,#7c5cff);--primary-foreground:var(--creatoros-brand-foreground,#fff);
 --secondary:var(--creatoros-brand-soft,#f2eeff);--secondary-border:var(--creatoros-border,#ddd);--secondary-foreground:var(--foreground);
 --muted:var(--creatoros-surface-subtle,#f5f5f5);--muted-foreground:var(--creatoros-text-muted,#667085);
 --accent:var(--creatoros-brand-soft,#f2eeff);--accent-foreground:var(--creatoros-brand,#7c5cff);
 --destructive:var(--creatoros-danger,#dc2626);--destructive-foreground:#fff;--constructive:var(--creatoros-success,#059669);--caution:var(--creatoros-warning,#d97706);
 --border:var(--creatoros-border,#ddd);--input:var(--creatoros-surface-subtle,#f5f5f5);--ring:var(--creatoros-brand,#7c5cff);
 --font-sans:var(--creatoros-font-sans,system-ui,sans-serif);--font-inter:var(--creatoros-font-sans,system-ui,sans-serif);
 --text-xs:var(--creatoros-text-xs,.75rem);--text-sm:var(--creatoros-text-sm,.875rem);--text-base:var(--creatoros-text-md,1rem);
 --radius-sm:var(--creatoros-radius-control,.375rem);--radius-md:var(--creatoros-radius-control,.375rem);--radius-lg:var(--creatoros-radius-card,.75rem);
 color:var(--foreground);font-family:var(--font-sans);
}
:host{display:block;min-width:0;min-height:0;height:100%;position:relative;}
[data-native-root]{height:100%;min-height:0;min-width:0;position:relative;background:var(--background);}
[data-native-portal]{position:absolute;inset:0;pointer-events:none;z-index:var(--creatoros-z-dialog,50);}
[data-native-portal]>*{pointer-events:auto;}
[data-native-dialog-overlay]{position:absolute!important;inset:0!important;}
[data-native-dialog-content]{position:absolute!important;}
.native-workbench{display:flex;flex-direction:column;min-width:0;min-height:0;height:100%;overflow:hidden;}
.native-loading{display:grid;place-items:center;height:100%;color:var(--muted-foreground);}
.native-export-status{position:absolute;inset:0;display:grid;place-items:center;z-index:100;background:color-mix(in srgb,var(--background) 80%,transparent);color:var(--foreground);pointer-events:none;}
[data-sonner-toaster]{position:absolute!important;font-family:var(--font-sans)!important;}\n.native-toast{background:var(--card)!important;color:var(--foreground)!important;border-color:var(--border)!important;font-family:var(--font-sans)!important;}
[data-density="compact"] [data-native-control="button"]{height:1.75rem;padding-block:.25rem;}
[data-density="comfortable"] [data-native-control="button"]{min-height:2rem;}
.native-workspace-panel{display:flex;flex-direction:column;height:100%;min-height:0;min-width:0;}
.native-workspace-tabs{display:flex;flex-shrink:0;gap:.25rem;padding:.5rem;border-bottom:1px solid var(--border);background:var(--card);}
.native-workspace-tabs [role="tab"]{padding:.5rem .75rem;border-radius:var(--radius-md);font-size:var(--text-sm);color:var(--muted-foreground);}
.native-workspace-tabs [role="tab"][aria-selected="true"]{background:var(--secondary);color:var(--primary);font-weight:600;}
.native-workspace-tabs [role="tab"]:focus-visible{outline:2px solid var(--ring);outline-offset:2px;}
.native-workspace-content{flex:1;min-height:0;min-width:0;overflow:hidden;}
.native-workspace-content[hidden]{display:none;}
.native-workspace-addon slot{display:block;height:100%;min-height:0;}
.native-workspace-addon ::slotted(*){display:block;height:100%;min-height:0;min-width:0;}
.native-workspace-preview{position:relative;height:100%;min-height:0;min-width:0;isolation:isolate;}
.native-workspace-preview-core{height:100%;min-height:0;min-width:0;}
.native-workspace-preview-projection{position:absolute;inset:0;z-index:1;min-height:0;min-width:0;overflow:hidden;background:var(--background);}
.native-workspace-preview-projection[hidden]{display:none;}
.native-workspace-preview-projection slot{display:block;height:100%;min-height:0;}
.native-workspace-preview-projection ::slotted(*){display:block;height:100%;min-height:0;min-width:0;}

.native-workspace-shell{flex:1;min-height:0;min-width:0;gap:.25rem;padding:0 .75rem .75rem;}
.native-workspace-editing{min-height:0;min-width:0;}
.native-workspace-editing>.native-workspace-vertical{height:100%;min-height:0;}
.native-workspace-right{border-left:1px solid var(--border);}
.native-director-divider{flex-shrink:0;}
[data-workspace-layout="single"] .native-workspace-shell{padding-inline:.5rem;}
[data-workspace-layout="single"] .native-workspace-right{border-left:0;}
[data-workspace-layout="single"] .native-workspace-horizontal{padding-inline:0;}
.native-responsive-workspace{height:100%;min-height:0;min-width:0;display:flex;flex-direction:column;}
.native-workspace-navigation{display:flex;flex-shrink:0;gap:.25rem;padding:.25rem .75rem .5rem;}
.native-workspace-navigation button{white-space:nowrap;padding:.5rem .65rem;border-radius:var(--radius-md);font-size:var(--text-sm);color:var(--muted-foreground);}
.native-workspace-navigation button[aria-pressed="true"]{color:var(--primary);background:var(--secondary);font-weight:600;}
.native-workspace-navigation button:focus-visible{outline:2px solid var(--ring);outline-offset:2px;}
[data-workspace-layout="wide"] .native-workspace-navigation{display:none;}
.native-responsive-workspace [hidden]{display:none;}
.native-responsive-workspace>.native-workspace-vertical{flex:1;min-height:0;}
.native-workspace-tabs button{white-space:nowrap;}
.native-workspace-core-content{display:flex;flex-direction:column;}
.native-workspace-core-body{flex:1;min-height:0;min-width:0;overflow:hidden;}
.native-workspace-materials{flex-shrink:0;min-width:0;}
.native-workspace-materials slot{display:block;}
.native-workspace-materials ::slotted(*){display:block;min-width:0;}
[data-workspace-layout="single"] .native-workspace-navigation{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));padding-inline:.5rem;gap:.25rem;}
[data-workspace-layout="single"] .native-workspace-navigation button{padding:.45rem .25rem;}
[data-workspace-layout="single"] .native-workspace-horizontal{padding-inline:0;}
[data-workspace-layout="single"] .native-workspace-main,[data-workspace-layout="single"] .native-workspace-timeline,[data-workspace-layout="single"] .native-workspace-horizontal>[data-panel]{min-width:0;min-height:0;}
[data-workspace-layout="single"] .native-workspace-timeline{padding-inline:.5rem;}
[data-workspace-layout="single"] .native-workspace-timeline>div{min-width:560px;}

/* 工具栏按真实预览容器宽度换行，保留时间编辑、播放、缩放与全屏操作。 */
.native-preview-panel{container-type:inline-size;container-name:native-preview;}
@container native-preview (max-width:380px){
 .native-preview-toolbar{grid-template-columns:minmax(0,1fr) auto;row-gap:4px;padding:8px;flex-shrink:0;}
 .native-preview-toolbar>div:first-child{grid-column:1/-1;justify-self:center;min-height:20px;}
 .native-preview-toolbar>button{justify-self:start;}
}
.reference-media-panel{container-type:inline-size;}
@container(max-width:260px){.reference-media-secondary{display:none;}}
`;
writeFileSync(source,css);
const {referenceLicenses}=await import('../reference-license-plugin.ts');
await build({configFile:false,root:app,esbuild:{supported:{'template-literal':false}},base:'./',mode:'production',define:{'process.env.NODE_ENV':JSON.stringify('production')},plugins:[...(domFixture?[{name:'explicit-dom-compositor-fixture',enforce:'pre',resolveId(id){if(id.endsWith('compositor/wasm-compositor'))return resolve(app,'src/embedded/__fixtures__/dom-compositor.ts');}}]:[]),{name:'native-radix-shadow-focus',enforce:'pre',transform(code,id){if(!id.includes('/@radix-ui/')||!id.includes('/dist/')||!code.includes('document.activeElement'))return;return {code:`import {nativeActiveElement as __nativeActiveElement} from ${JSON.stringify(resolve(app,'src/embedded/native-host.ts'))};\n`+code.replace(/document\.activeElement/g,'__nativeActiveElement()'),map:null};}},{name:'native-sonner-boundary',enforce:'pre',transform(code,id){if(!id.includes('/sonner/')||!id.endsWith('/index.mjs'))return;let scoped=code.replace(sonnerMatches[0][0],'').replace(/document\.activeElement/g,'__nativeActiveElement()').replace('window.removeEventListener("visibilitychange"','document.removeEventListener("visibilitychange"').replace(/document\.addEventListener\("keydown",(\w+)\)/g,'__nativeAddKeydown($1)').replace(/document\.removeEventListener\("keydown",(\w+)\)/g,'__nativeRemoveKeydown($1)');if(scoped===code||scoped.includes(sonnerMatches[0][0]))throw Error('通知库原生边界适配失败。');return {code:`import {nativeActiveElement as __nativeActiveElement,ownsNativeEvent,nativeFocused} from ${JSON.stringify(resolve(app,'src/embedded/native-host.ts'))};\nconst __nativeKeydowns=new Map();function __nativeAddKeydown(handler){const scoped=event=>{if(ownsNativeEvent(event)||nativeFocused())handler(event);};__nativeKeydowns.set(handler,scoped);document.addEventListener('keydown',scoped);}function __nativeRemoveKeydown(handler){const scoped=__nativeKeydowns.get(handler);if(scoped)document.removeEventListener('keydown',scoped);__nativeKeydowns.delete(handler);};\n`+scoped+`\nObject.assign(${sonnerToast},{nativeReset(){${sonnerStore}.toasts=[];${sonnerStore}.dismissedToasts.clear();}});`,map:null};}},react(),tailwindcss(),wasmPlugin,referenceLicenses(),{name:'native-rendered-module-graph',generateBundle(_options,bundle){const modules=[];for(const output of Object.values(bundle)){if(output.type!=='chunk')continue;for(const [id,module] of Object.entries(output.modules)){if(module.renderedLength===0||id.includes('/node_modules/'))continue;modules.push({module:id.startsWith('\0')?id:wasmPlugin.resolveId(id)===id?'\0'+id:relative(app,id.split('?')[0]).replace(/^.*apps\/web\//,''),renderedLength:module.renderedLength});}}this.emitFile({type:'asset',fileName:'NATIVE_BUILD_GRAPH.json',source:JSON.stringify({fixture:domFixture,entry:'src/embedded/native-entry.tsx',moduleCount:modules.length,modules:modules.sort((a,b)=>a.module.localeCompare(b.module))},null,2)});}}],resolve:{alias:{...(domFixture?{'@/services/renderer/compositor/wasm-compositor':resolve(app,'src/embedded/__fixtures__/dom-compositor.ts')}:{}),'@':resolve(app,'src'),...Object.fromEntries(['focus-guards','focus-scope','dismissable-layer'].map(name=>['@radix-ui/react-'+name,resolve(app,'src/embedded/radix/'+name+'.tsx')])), 'aria-hidden':resolve(app,'src/embedded/radix/aria-hidden.ts'),'react-remove-scroll':resolve(app,'src/embedded/radix/remove-scroll.tsx'),'next/image':resolve(app,'src/embedded/next-image.tsx'),'next/link':resolve(app,'src/embedded/next-link.tsx'),'next/navigation':resolve(app,'src/embedded/next-navigation.ts')}},build:{outDir:domFixture?'native-dom-fixture-dist':'native-dist',emptyOutDir:true,target:'esnext',lib:{entry:resolve(app,'src/embedded/native-entry.tsx'),formats:['es'],fileName:()=> 'native.js',cssFileName:'native'},rollupOptions:{output:{assetFileNames:asset=>asset.names?.some(name=>name.endsWith('.css'))?'native.css':'assets/[name]-[hash][extname]'}}},css:{postcss:{plugins:[]}}});
const output=resolve(app,domFixture?'native-dom-fixture-dist':'native-dist');
for(const name of readdirSync(output))if(name.endsWith('.css')){const dest=resolve(output,name);const built=postcss.parse(readFileSync(dest,'utf8'));built.walkRules(rule=>{rule.selector=rule.selector.replace(/:root/g,':host').replace(/\bhtml\b/g,':host').replace(/\bbody\b/g,'[data-native-root]');});writeFileSync(dest,built.toString());}
console.log('原生 ESM / CSS 已生成，未执行浏览器或MP4导出。');
