import React from "react";
export default function Image({fill,priority,unoptimized,loader,quality,placeholder,blurDataURL,...props}:any){return <img {...props} style={{...(fill?{position:"absolute",width:"100%",height:"100%"}:{}),...props.style}}/>;}
