/** 仅JSDOM结构测试：无真实GPU、无像素、不用于生产构建/PNG/MP4证据。 */
let canvas:HTMLCanvasElement|null=null;
export const wasmCompositor={ensureInitialized(){canvas??=document.createElement('canvas');},getCanvas(){if(!canvas)throw Error('fixture compositor尚未初始化');return canvas;},syncTextures(){},render(){},dispose(){canvas?.remove();canvas=null;}};
