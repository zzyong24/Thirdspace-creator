# OpenCut 原生 CreatorOS 工作面

来源为 OpenCut classic `cf5e79e919144200294fb9fed22a222592a0aeea`，基于 T1046 已集成的同轨命令、NativePatchReplay 和冻结导出源码继续修改。当前构建入口是 `apps/web/src/embedded/native-entry.tsx`，直接挂载原 React 素材区、预览、属性区与时间轴，不运行原独立网页入口。

```mermaid
flowchart LR
 A[CreatorOS 当前视频稿] --> B[原生 mount 与 owner lease]
 B --> C[OpenCut 原四区组件]
 C --> D[原命令 / 撤销 / MediaBunny 导出]
 D --> E[原宿主正式保存与真实素材回执]
```

`native-dist/native.js` 为可信本地 ESM，`native.css` 必须先装入宿主 ShadowRoot；container 与 portalContainer 同属这个工作面，宽高由宿主分配。

接口为 `await mount(container, {owner:{accountId,outputId,sourceVersionId},theme:{mode,tokens,fontFamily,fontSize,density},portalContainer,signal,onChanged,onError,importMedia})`。返回 `request(operation,payload,{requestId,signal})`、`update({theme,disabled})` 和异步 `dispose()`。

操作保留 `load/snapshot/insert-media/export/context/seek/apply-tracks` 以及原返回形状。load 接收版本31原生工程、真实 outputId 与已注册媒体 File；snapshot 不含 File、Blob、URL、buffer。export 继续原 MediaBunny/WebCodecs，返回与本次真实渲染同次冻结的原文档、媒体元信息、Blob 和文件名。context、seek 保留 120000 ticks/s；apply-tracks 保留完整 main/overlay/audio 前值与摘要、409冲突、单次真实命令及当前挂载寿命内不可淘汰的采纳回执，不二次 ripple。正式数据仍由 CreatorOS 宿主公共服务保存，编辑器只有暂存内存。

UI主题使用 `--creatoros-*`，原内容颜色/字体/版式不随应用主题改写。CSS只在工作面ShadowRoot生效；Radix门户、无障碍隐藏、焦点与滚动限定当前实例，原通知库CSS移入同一作用域，快捷键与粘贴只在工作面拥有焦点时处理。原菜单选择、复选、方向键、Escape、焦点恢复与外部点击保持真实交互。

同文档使用显式单实例lease。换稿先取消旧实例，再停保存/播放/RAF、导入/图片/音频元素/解码器，等待旧异步队列达到不可写状态；清理对象URL、图像缓存、媒体/音频sink、监听、订阅、React组件、临时通知与纹理，再交新owner。原核心重载后通过真实generation remount更新useEditor实例。

## 重建

本次实际工具链 Bun 1.4.0、Vite 6.4.3、TypeScript 6.0.2（原锁依赖）。原生Vite Library构建显式设置生产mode，并将process.env.NODE_ENV定义为production常量，避免浏览器依赖不存在的Node全局。

```bash
bun install --frozen-lockfile --ignore-scripts
bun apps/web/scripts/build-native.mjs
cd apps/web
bun ../../node_modules/typescript/bin/tsc --noEmit --project tsconfig.embedded.json
bun test src/embedded/__tests__/native-lifecycle.test.ts src/embedded/__tests__/native-command.test.ts src/embedded/__tests__/host-boundary.test.ts
bun test src/embedded/__tests__/native-resources.test.ts
```

产物为 `apps/web/native-dist`。`NATIVE_BUILD_GRAPH.json` 记录实际保留的原组件/引擎模块，不包含原消息bridge/全页入口。通知库和Radix在构建时应用窄适配；形状改变时明确报构建错误，避免悄悄恢复全页副作用。`--dom-fixture` 仅替换不能在JSDOM执行的compositor，产物置于独立 `native-dom-fixture-dist`，不得发布或冒充真实像素/MP4。

## 来源与许可

OpenCut 为 MIT，实际生产bundle包含59项依赖，逐项来源/许可及原文见 `THIRD_PARTY_LICENSES.json/txt`；不能将整个包统一称为MIT。MediaBunny 1.41.0为MPL-2.0（官方提交 `b285360563b754546cbfb7bbcf853f107e1dd3b9`），SoundTouchJS 0.3.0为LGPL-2.1（官方提交 `36b161bb7d69d801b6a81674ad0fc0c42082729f`），两库未修改，沿用原对应源码包。效果预览图保留固定上游来源；没有下载Google字体二进制。

## 本轮证据与限制

类型与生产构建通过，原采纳/冻结/归属/lease回归13项68断言通过；慢资源取消3项12断言通过。最终生产JS没有未替换的process.env.NODE_ENV或未守卫的全局process引用。原四区、同轨文字、Undo/Redo、真实Select与复选上下文菜单、焦点/外部点击、通知作用域和跨owner清理的JSDOM探针先移除process全局，再使用明确命名的compositor/Canvas fixture，不能证明WebGPU、真实像素、MP4或系统剪贴板。

原生产bundle两次JSDOM探针因环境没有WebGPU失败，原日志保留。连续生产重建记录见 `NATIVE_REBUILD_CONSISTENCY.json`；只说明同一已安装锁依赖树的重建，不声称跨OS/全工具链位复现。原opencut-wasm 0.2.10没有GPU device或compositor销毁API；dispose释放所有当前纹理并缩小/移除canvas，但其模块GPU初始化对象仍保留至浏览器文档关闭，不能声称完全free设备。
