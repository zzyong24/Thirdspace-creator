import type { IEditor } from '@kuaitu/core';

export const referenceSession =
  new URLSearchParams(location.hash.replace(/^#\/?\??/, '')).get('session') || '';
const TYPE = 'creatoros.reference-editor';
let editor: IEditor | null = null;
let title = '图文设计';
let loading = false;
let exportHold: { wait: Promise<void>; release: () => void } | undefined;
let documentEpoch = 0;
let sequence = Promise.resolve();
let lastPublishedDocument: string | undefined;
let publishTimer: ReturnType<typeof setTimeout> | undefined;
const imports = new Map<
  string,
  {
    resolve: (id: string) => void;
    reject: (err: Error) => void;
    timer: ReturnType<typeof setTimeout>;
  }
>();

function send(operation: string, payload?: unknown, requestId?: string) {
  if (!referenceSession || parent === window) return;
  parent.postMessage(
    { type: TYPE, version: 1, session: referenceSession, operation, payload, requestId },
    location.origin
  );
}

function snapshot() {
  if (!editor) throw new Error('编辑器还没准备好');
  return { document: editor.getJson() };
}

function publish() {
  if (!editor || loading || exportHold || !referenceSession) return;
  clearTimeout(publishTimer);
  publishTimer = setTimeout(() => {
    if (!loading && !exportHold && editor) {
      const current = snapshot();
      // SEMANTIC_BOUNDARY_ALLOW: exact native JSON comparison only deduplicates UI events; it never chooses content.
      const serialized = JSON.stringify(current.document);
      if (serialized === lastPublishedDocument) return;
      lastPublishedDocument = serialized;
      send('changed', current);
    }
  }, 180);
}

async function insertFile(file: File, mediaId?: string) {
  const epoch = documentEpoch;
  if (!editor) throw new Error('编辑器还没准备好');
  if (!(file instanceof File) || !file.type.startsWith('image/') || file.size > 40 * 1024 * 1024)
    throw new Error('请选择40MB以内的图片');
  const src = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('图片读取失败'));
    reader.readAsDataURL(file);
  });
  const img = new Image();
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error('图片加载失败'));
    img.src = src;
  });
  if (epoch !== documentEpoch || !editor) throw new Error('已切换图卡，请重新插入图片');
  const image = await editor.createImgByElement(img);
  if (epoch !== documentEpoch || !editor) throw new Error('已切换图卡，请重新插入图片');
  if (exportHold) await exportHold.wait;
  if (epoch !== documentEpoch || !editor) throw new Error('已切换图卡，请重新插入图片');
  if (mediaId) image.set('data', { creatorosMediaId: mediaId });
  editor.addBaseType(image, { scale: true });
  publish();
}

export async function importLocalImage(file: File) {
  const epoch = documentEpoch;
  if (!referenceSession) {
    await insertFile(file);
    return;
  }
  const requestId = crypto.randomUUID();
  const mediaId = await new Promise<string>((resolve, reject) => {
    const timer = setTimeout(() => {
      imports.delete(requestId);
      reject(new Error('图片上传超时，请重试'));
    }, 120000);
    imports.set(requestId, { resolve, reject, timer });
    send('import-media', { file }, requestId);
  });
  if (epoch !== documentEpoch) throw new Error('已切换图卡，请重新插入图片');
  await insertFile(file, mediaId);
}

function freezeExportInput() {
  let release!: () => void;
  exportHold = {
    wait: new Promise<void>((resolve) => {
      release = resolve;
    }),
    release: () => release(),
  };
  const hold = exportHold;
  clearTimeout(publishTimer);
  const shield = document.createElement('div');
  shield.setAttribute('role', 'status');
  shield.setAttribute('aria-live', 'polite');
  shield.textContent = '正在导出，请稍候…';
  shield.style.cssText =
    'position:fixed;inset:0;z-index:2147483647;background:#ffffffa8;display:flex;align-items:center;justify-content:center;font-size:16px;cursor:wait';
  document.body.appendChild(shield);
  const blockedEvents = [
    'keydown',
    'keyup',
    'beforeinput',
    'input',
    'change',
    'compositionstart',
    'compositionupdate',
    'compositionend',
    'paste',
    'cut',
    'drop',
    'dragstart',
    'pointerdown',
    'pointerup',
    'mousedown',
    'mouseup',
    'click',
    'wheel',
  ];
  const preventEdit = (event: Event) => {
    if (event.cancelable) event.preventDefault();
    event.stopImmediatePropagation();
  };
  blockedEvents.forEach((name) =>
    window.addEventListener(name, preventEdit, { capture: true, passive: false })
  );
  return () => {
    blockedEvents.forEach((name) => window.removeEventListener(name, preventEdit, true));
    shield.remove();
    if (exportHold === hold) exportHold = undefined;
    hold.release();
    publish();
  };
}

export function attachReferenceBridge(instance: IEditor) {
  editor = instance;
  const canvas = editor.fabricCanvas;
  ['object:added', 'object:modified', 'object:removed', 'text:changed', 'path:created'].forEach(
    (name) => canvas?.on(name, publish)
  );
  // Several upstream property controls mutate then render, without object:modified.
  canvas?.on('after:render', publish);
  const receive = (event: MessageEvent) => {
    const m = event.data;
    if (
      !referenceSession ||
      event.source !== parent ||
      event.origin !== location.origin ||
      !m ||
      m.type !== TYPE ||
      m.version !== 1 ||
      m.session !== referenceSession
    )
      return;
    if (typeof m.requestId !== 'string') return;
    const pending = imports.get(m.requestId);
    if (pending && (m.operation === 'result' || m.operation === 'error')) {
      clearTimeout(pending.timer);
      imports.delete(m.requestId);
      if (m.operation === 'result' && typeof m.payload?.mediaId === 'string' && m.payload.mediaId)
        pending.resolve(m.payload.mediaId);
      else
        pending.reject(
          new Error(
            typeof m.payload?.message === 'string' ? m.payload.message : '图片上传失败，请重试'
          )
        );
      return;
    }
    sequence = sequence.then(async () => {
      try {
        if (!editor) throw new Error('编辑器已关闭');
        let result: unknown;
        switch (m.operation) {
          case 'load': {
            documentEpoch++;
            imports.forEach((pending) => {
              clearTimeout(pending.timer);
              pending.reject(new Error('已切换图卡，请重新插入图片'));
            });
            imports.clear();
            clearTimeout(publishTimer);
            loading = true;
            try {
              title = typeof m.payload?.title === 'string' ? m.payload.title : '图文设计';
              const document = m.payload?.document;
              if (document != null) {
                if (typeof document !== 'object' || !Array.isArray(document.objects))
                  throw new Error('图文稿件格式不正确');
                await new Promise<void>((resolve, reject) => {
                  const timeout = setTimeout(
                    () => reject(new Error('稿件加载超时，请保留当前稿件后重试')),
                    30000
                  );
                  Promise.resolve(
                    editor!.loadJSON(document, () => {
                      clearTimeout(timeout);
                      resolve();
                    })
                  ).catch((error) => {
                    clearTimeout(timeout);
                    reject(error);
                  });
                });
              } else {
                const width = Number(m.payload?.width) || 900;
                const height = Number(m.payload?.height) || 1200;
                if (width < 1 || height < 1 || width > 10000 || height > 10000)
                  throw new Error('图文尺寸超出范围');
                editor.clear();
                editor.setSize(width, height);
                editor.setWorkspaseBg('#ffffff');
              }
              editor.getPlugin('HistoryPlugin')?.clearAndSaveState?.();
              result = snapshot();
              lastPublishedDocument = JSON.stringify((result as { document: unknown }).document);
            } finally {
              loading = false;
              clearTimeout(publishTimer);
            }
            break;
          }
          case 'snapshot':
            result = snapshot();
            break;
          case 'export': {
            if (m.payload?.format !== 'png') throw new Error('暂支持PNG导出');
            const resume = freezeExportInput();
            try {
              const rendered = await editor.previewDocument();
              const blob = await (await fetch(rendered.dataUrl)).blob();
              result = {
                blob,
                document: rendered.document,
                fileName: `${title.replace(/[\\/:*?"<>|]/g, '_').slice(0, 100) || '图文设计'}.png`,
              };
            } finally {
              resume();
            }
            break;
          }
          case 'insert-media':
            if (typeof m.payload?.mediaId !== 'string' || !m.payload.mediaId)
              throw new Error('图片缺少素材关联');
            await insertFile(m.payload?.file, m.payload?.mediaId);
            result = snapshot();
            break;
          default:
            return;
        }
        send('result', result, m.requestId);
      } catch (error) {
        send(
          'error',
          { message: error instanceof Error ? error.message : '操作失败，请重试' },
          m.requestId
        );
      }
    });
  };
  window.addEventListener('message', receive);
  lastPublishedDocument = JSON.stringify(snapshot().document);
  send('ready', { capabilities: ['load', 'snapshot', 'export', 'insert-media', 'import-media'] });
  return () => {
    window.removeEventListener('message', receive);
    clearTimeout(publishTimer);
    imports.forEach((pending) => {
      clearTimeout(pending.timer);
      pending.reject(new Error('编辑器已关闭'));
    });
    imports.clear();
    editor = null;
  };
}
