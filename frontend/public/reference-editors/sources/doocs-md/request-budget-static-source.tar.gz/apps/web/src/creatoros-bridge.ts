import type { ThemeName, PerThemeSettings } from '@md/shared/configs'
import { usePostStore } from '@/stores/post'
import { useEditorStore } from '@/stores/editor'
import { useThemeStore } from '@/stores/theme'
import { useCssEditorStore } from '@/stores/cssEditor'
import { getHtmlContent } from '@/services/export/html-content'
import { EXPORT_LAYOUT_CSS } from '@/services/export/apply-export-layout'
import { getStylesToAdd, SHARE_SHELL_VARS_CSS } from '@/services/export/share-styles'

const CHANNEL = 'creatoros-doocs'
const COMMIT = 'a7c17fc4cda92e3c13aa7e24f06615cfa4219b31'
const imageUrls = new Map<string, string>()
let parentOrigin = ''
function imageKey(assetId: string, fileId: string): string { return `${assetId}:${fileId}` }

export function resolveCreatorOSImages(markdown: string): string {
  return markdown.replace(/src=(['"])creatoros-asset:([^:\s'"]+):([^\s'"]+)\1/g, (_match, quote: string, assetId: string, fileId: string) => {
    const blobUrl = imageUrls.get(imageKey(assetId, fileId))
    return blobUrl ? `src=${quote}${blobUrl}${quote}` : `src=${quote}creatoros-asset:${assetId}:${fileId}${quote}`
  })
}

export function installCreatorOSBridge(): void {
  const postStore = usePostStore()
  const editorStore = useEditorStore()
  const themeStore = useThemeStore()
  const cssStore = useCssEditorStore()
  let sessionId = ''
  let initialized = false
  let lastState = ''
  const send = (type: string, body: Record<string, unknown> = {}) => window.parent.postMessage({ channel: CHANNEL, type, ...(sessionId ? { sessionId } : {}), ...body }, parentOrigin || '*')
  const currentLayout = () => ({
    schemaVersion: 1, editor: 'doocs-md', editorCommit: COMMIT,
    themeId: String(themeStore.theme),
    themeSettings: JSON.parse(JSON.stringify(themeStore.themeSettings[themeStore.theme] ?? {})),
    customCss: cssStore.getCurrentTabContent(),
    exportOptions: { useIndent: Boolean(themeStore.isUseIndent), useJustify: Boolean(themeStore.isUseJustify) },
  })
  const applyLayout = (layout: any) => {
    if (!layout) return
    if (layout.themeId) themeStore.theme = layout.themeId as ThemeName
    if (layout.themeId && layout.themeSettings) themeStore.themeSettings = { ...themeStore.themeSettings, [layout.themeId as ThemeName]: layout.themeSettings as PerThemeSettings }
    if (typeof layout.customCss === 'string') {
      const tab = cssStore.cssContentConfig.tabs[0]
      if (tab) { tab.content = layout.customCss; cssStore.cssContentConfig.active = tab.id; cssStore.setCssEditorValue(layout.customCss) }
    }
    if (layout.exportOptions) { themeStore.isUseIndent = layout.exportOptions.useIndent; themeStore.isUseJustify = layout.exportOptions.useJustify }
    void themeStore.applyCurrentTheme()
  }
  const applyDocument = (document: { markdown: string; layout: any }) => {
    applyLayout(document.layout)
    const post = postStore.currentPost
    if (post) postStore.updatePostContent(post.id, document.markdown)
    editorStore.importContent(document.markdown)
    lastState = ''
  }
  window.addEventListener('message', (event: MessageEvent) => {
    if (event.source !== window.parent) return
    const message = event.data
    if (!message || message.channel !== CHANNEL || typeof message.type !== 'string') return
    if (message.type === 'init') {
      if (initialized || typeof message.nonce !== 'string' || message.nonce.length < 16 || event.origin === 'null') return
      parentOrigin = event.origin
      sessionId = String(message.sessionId || '')
      if (!sessionId || !message.document || typeof message.document.markdown !== 'string') return
      initialized = true
      applyDocument(message.document)
      send('initialized', { nonce: message.nonce })
      return
    }
    if (!initialized || event.origin !== parentOrigin || message.sessionId !== sessionId) return
    if (message.type === 'set-document' && typeof message.document?.markdown === 'string') applyDocument(message.document)
    if (message.type === 'asset' && typeof message.assetId === 'string' && typeof message.assetFileId === 'string' && message.blob instanceof Blob) {
      const key = imageKey(message.assetId, message.assetFileId)
      const prior = imageUrls.get(key)
      if (prior) URL.revokeObjectURL(prior)
      imageUrls.set(key, URL.createObjectURL(message.blob))
      const post = postStore.currentPost
      if (post) editorStore.importContent(post.content)
    }
    if (message.type === 'export-html' && typeof message.nonce === 'string') {
      void (async () => {
        const styles = await getStylesToAdd()
        const html = `<style>${SHARE_SHELL_VARS_CSS}</style>${styles}<style>${EXPORT_LAYOUT_CSS}</style><div id="output">${getHtmlContent({ staticLayout: true })}</div>`
        send('export-html', { nonce: message.nonce, html, bindings: [...imageUrls].map(([key, url]) => ({ key, url })) })
      })().catch(() => send('export-html', { nonce: message.nonce, error: '公众号 HTML 生成失败，请先确认编辑器预览正常。' }))
    }
  })
  send('ready')
  window.setInterval(() => {
    if (!initialized) return
    const markdown = editorStore.getContent()
    const layout = currentLayout()
    const state = JSON.stringify([markdown, layout])
    if (state === lastState) return
    lastState = state
    send('changed', { markdown, layout })
  }, 500)
  window.addEventListener('pagehide', () => {
    for (const url of imageUrls.values()) URL.revokeObjectURL(url)
    imageUrls.clear()
    initialized = false
  }, { once: true })
}
