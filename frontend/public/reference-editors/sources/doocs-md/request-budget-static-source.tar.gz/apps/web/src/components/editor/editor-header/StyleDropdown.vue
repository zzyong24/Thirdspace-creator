<script setup lang="ts">
import type {
  ThemeName,
} from '@md/shared/configs'
import type { Format } from 'vue-pick-colors'
import { ALargeSmall, AlignVerticalSpaceAround, Code, Droplet, FileCode, ImageIcon, Link, Palette, Pipette, Quote, RotateCcw, Rows3, SquareCode, Store, Type } from '@lucide/vue'
import {
  codeBlockThemeOptions,
} from '@md/shared/configs'
import PickColors from 'vue-pick-colors'
import { useEditorRefresh } from '@/composables/useEditorRefresh'
import { useLocalizedStyleOptions } from '@/composables/useLocalizedStyleOptions'
import { isMarketplaceUiEnabled } from '@/services/marketplace/client'
import { useConfirmStore } from '@/stores/confirm'
import { useCssEditorStore } from '@/stores/cssEditor'
import { useThemeStore } from '@/stores/theme'
import { useUIStore } from '@/stores/ui'

const props = withDefaults(defineProps<{
  asSub?: boolean
}>(), {
  asSub: false,
})

const { asSub } = toRefs(props)
const { t } = useI18n()
const localizedStyleOptions = useLocalizedStyleOptions()

const confirmStore = useConfirmStore()
const cssEditorStore = useCssEditorStore()
const themeStore = useThemeStore()
const uiStore = useUIStore()
const { editorRefresh } = useEditorRefresh()

const { toggleShowCssEditor } = uiStore
const showMarketplaceUi = isMarketplaceUiEnabled()

const {
  theme,
  fontFamily,
  fontSize,
  lineHeight,
  blockSpacing,
  linkColor,
  blockquoteBackground,
  primaryColor,
  codeBlockTheme,
  legend,
} = storeToRefs(themeStore)

const { isDark } = storeToRefs(uiStore)

function themeChanged(newTheme: ThemeName) {
  themeStore.theme = newTheme

  themeStore.applyCurrentTheme()
  editorRefresh()
}

function fontChanged(fonts: string) {
  themeStore.fontFamily = fonts

  themeStore.applyCurrentTheme()
  editorRefresh()
}

function sizeChanged(size: string) {
  themeStore.fontSize = size

  themeStore.applyCurrentTheme()
  editorRefresh()
}

function lineHeightChanged(value: string) {
  themeStore.lineHeight = value

  themeStore.applyCurrentTheme()
  editorRefresh()
}

function blockSpacingChanged(value: string) {
  themeStore.blockSpacing = value

  themeStore.applyCurrentTheme()
  editorRefresh()
}

function linkColorChanged(value: string) {
  themeStore.linkColor = value

  themeStore.applyCurrentTheme()
  editorRefresh()
}

function blockquoteBackgroundChanged(value: string) {
  themeStore.blockquoteBackground = value

  themeStore.applyCurrentTheme()
  editorRefresh()
}

function colorChanged(newColor: string) {
  themeStore.primaryColor = newColor

  themeStore.applyCurrentTheme()
  editorRefresh()
}

function codeBlockThemeChanged(newTheme: string) {
  themeStore.codeBlockTheme = newTheme
  editorRefresh()
}

function legendChanged(newVal: string) {
  themeStore.legend = newVal
  editorRefresh()
}

function macCodeBlockChanged() {
  themeStore.isMacCodeBlock = !themeStore.isMacCodeBlock
  editorRefresh()
}

function resetStyleConfirm() {
  confirmStore.confirm({
    title: t(`confirm.tip`),
    description: t(`confirm.resetStyleDescription`),
    onConfirm: () => {
      themeStore.resetStyle()
      cssEditorStore.resetCssConfig()
      themeStore.applyCurrentTheme()
      editorRefresh()
      toast.success(t(`toast.styleReset`))
    },
  })
}

const colorPicker = ref<HTMLElement & { show: () => void } | null>(null)

function showPicker() {
  colorPicker.value?.show()
}

function customStyle() {
  toggleShowCssEditor()
}

function openMarketplaceDialog() {
  uiStore.openMarketplaceDialog({ tab: `theme`, view: `discover` })
}

const pickColorsContainer = useTemplateRef(`pickColorsContainer`)
const format = ref<Format>(`rgb`)
const formatOptions = ref<Format[]>([`rgb`, `hex`, `hsl`, `hsv`])
</script>

<template>
  <MenubarSub v-if="asSub">
    <MenubarSubTrigger>
      {{ t('menu.style') }}
    </MenubarSubTrigger>
    <MenubarSubContent class="min-w-56 max-h-56 overflow-auto">
      <StyleOptionMenu
        :title="t('menu.theme')"
        :options="localizedStyleOptions.themeOptions"
        :current="theme"
        :change="themeChanged"
        :icon="Palette"
      />
      <MenubarItem v-if="showMarketplaceUi" class="pl-2" @click="openMarketplaceDialog()">
        <Store class="mr-2 h-4 w-4" />
        {{ t('menu.marketplace') }}
      </MenubarItem>
      <MenubarSeparator />
      <StyleOptionMenu
        :title="t('menu.font')"
        style-key="font"
        :options="localizedStyleOptions.fontFamilyOptions"
        :current="fontFamily"
        :change="fontChanged"
        :icon="Type"
      />
      <StyleOptionMenu
        :title="t('menu.fontSize')"
        style-key="fontSize"
        :options="localizedStyleOptions.fontSizeOptions"
        :current="fontSize"
        :change="sizeChanged"
        :icon="ALargeSmall"
      />
      <StyleOptionMenu
        :title="t('menu.lineHeight')"
        style-key="lineHeight"
        :options="localizedStyleOptions.lineHeightOptions"
        :current="lineHeight"
        :change="lineHeightChanged"
        :icon="Rows3"
      />
      <StyleOptionMenu
        :title="t('menu.blockSpacing')"
        style-key="blockSpacing"
        :options="localizedStyleOptions.blockSpacingOptions"
        :current="blockSpacing"
        :change="blockSpacingChanged"
        :icon="AlignVerticalSpaceAround"
      />
      <StyleOptionMenu
        :title="t('menu.primaryColor')"
        style-key="color"
        :options="localizedStyleOptions.colorOptions"
        :current="primaryColor"
        :change="colorChanged"
        :icon="Droplet"
      />
      <StyleOptionMenu
        :title="t('menu.linkColor')"
        style-key="linkColor"
        :options="localizedStyleOptions.linkColorOptions"
        :current="linkColor"
        :change="linkColorChanged"
        :icon="Link"
      />
      <StyleOptionMenu
        :title="t('menu.blockquoteBackground')"
        style-key="blockquoteBackground"
        :options="localizedStyleOptions.blockquoteBackgroundOptions"
        :current="blockquoteBackground"
        :change="blockquoteBackgroundChanged"
        :icon="Quote"
      />
      <StyleOptionMenu
        :title="t('menu.codeBlockTheme')"
        :options="codeBlockThemeOptions"
        :current="codeBlockTheme"
        :change="codeBlockThemeChanged"
        :icon="Code"
      />
      <StyleOptionMenu
        :title="t('menu.legendFormat')"
        :options="localizedStyleOptions.legendOptions"
        :current="legend"
        :change="legendChanged"
        :icon="ImageIcon"
      />
      <MenubarSeparator />
      <MenubarCheckboxItem class="pl-2" @click.self.prevent="showPicker">
        <HoverCard :open-delay="100">
          <HoverCardTrigger class="w-full flex">
            <Pipette class="mr-2 h-4 w-4" />
            {{ t('menu.customPrimaryColor') }}
          </HoverCardTrigger>
          <HoverCardContent side="right" class="w-min">
            <div ref="pickColorsContainer">
              <PickColors
                v-model:value="primaryColor"
                show-alpha
                :format="format" :format-options="formatOptions"
                :theme="isDark ? 'dark' : 'light'"
                :popup-container="pickColorsContainer!"
                @change="colorChanged"
              />
            </div>
          </HoverCardContent>
        </HoverCard>
      </MenubarCheckboxItem>
      <MenubarCheckboxItem class="pl-2" @click="customStyle">
        <FileCode class="mr-2 h-4 w-4" />
        {{ t('menu.customCss') }}
      </MenubarCheckboxItem>
      <MenubarSeparator />
      <MenubarCheckboxItem class="pl-2" @click="macCodeBlockChanged">
        <SquareCode class="mr-2 h-4 w-4" />
        {{ t('menu.macCodeBlock') }}
      </MenubarCheckboxItem>
      <MenubarSeparator />
      <MenubarCheckboxItem class="pl-2" divided @click="resetStyleConfirm">
        <RotateCcw class="mr-2 h-4 w-4" />
        {{ t('menu.reset') }}
      </MenubarCheckboxItem>
    </MenubarSubContent>
  </MenubarSub>

  <MenubarMenu v-else>
    <MenubarTrigger>
      {{ t('menu.style') }}
    </MenubarTrigger>
    <MenubarContent class="min-w-56" align="start">
      <StyleOptionMenu
        :title="t('menu.theme')"
        :options="localizedStyleOptions.themeOptions"
        :current="theme"
        :change="themeChanged"
        :icon="Palette"
      />
      <MenubarItem v-if="showMarketplaceUi" class="pl-2" @click="openMarketplaceDialog()">
        <Store class="mr-2 h-4 w-4" />
        {{ t('menu.marketplace') }}
      </MenubarItem>
      <MenubarSeparator />
      <StyleOptionMenu
        :title="t('menu.font')"
        style-key="font"
        :options="localizedStyleOptions.fontFamilyOptions"
        :current="fontFamily"
        :change="fontChanged"
        :icon="Type"
      />
      <StyleOptionMenu
        :title="t('menu.fontSize')"
        style-key="fontSize"
        :options="localizedStyleOptions.fontSizeOptions"
        :current="fontSize"
        :change="sizeChanged"
        :icon="ALargeSmall"
      />
      <StyleOptionMenu
        :title="t('menu.lineHeight')"
        style-key="lineHeight"
        :options="localizedStyleOptions.lineHeightOptions"
        :current="lineHeight"
        :change="lineHeightChanged"
        :icon="Rows3"
      />
      <StyleOptionMenu
        :title="t('menu.blockSpacing')"
        style-key="blockSpacing"
        :options="localizedStyleOptions.blockSpacingOptions"
        :current="blockSpacing"
        :change="blockSpacingChanged"
        :icon="AlignVerticalSpaceAround"
      />
      <StyleOptionMenu
        :title="t('menu.primaryColor')"
        style-key="color"
        :options="localizedStyleOptions.colorOptions"
        :current="primaryColor"
        :change="colorChanged"
        :icon="Droplet"
      />
      <StyleOptionMenu
        :title="t('menu.linkColor')"
        style-key="linkColor"
        :options="localizedStyleOptions.linkColorOptions"
        :current="linkColor"
        :change="linkColorChanged"
        :icon="Link"
      />
      <StyleOptionMenu
        :title="t('menu.blockquoteBackground')"
        style-key="blockquoteBackground"
        :options="localizedStyleOptions.blockquoteBackgroundOptions"
        :current="blockquoteBackground"
        :change="blockquoteBackgroundChanged"
        :icon="Quote"
      />
      <StyleOptionMenu
        :title="t('menu.codeBlockTheme')"
        :options="codeBlockThemeOptions"
        :current="codeBlockTheme"
        :change="codeBlockThemeChanged"
        :icon="Code"
      />
      <StyleOptionMenu
        :title="t('menu.legendFormat')"
        :options="localizedStyleOptions.legendOptions"
        :current="legend"
        :change="legendChanged"
        :icon="ImageIcon"
      />
      <MenubarSeparator />
      <MenubarCheckboxItem class="pl-2" @click.self.prevent="showPicker">
        <HoverCard :open-delay="100">
          <HoverCardTrigger class="w-full flex">
            <Pipette class="mr-2 h-4 w-4" />
            {{ t('menu.customPrimaryColor') }}
          </HoverCardTrigger>
          <HoverCardContent side="right" class="w-min">
            <div ref="pickColorsContainer">
              <PickColors
                v-model:value="primaryColor"
                show-alpha
                :format="format" :format-options="formatOptions"
                :theme="isDark ? 'dark' : 'light'"
                :popup-container="pickColorsContainer!"
                @change="colorChanged"
              />
            </div>
          </HoverCardContent>
        </HoverCard>
      </MenubarCheckboxItem>
      <MenubarCheckboxItem class="pl-2" @click="customStyle">
        <FileCode class="mr-2 h-4 w-4" />
        {{ t('menu.customCss') }}
      </MenubarCheckboxItem>
      <MenubarSeparator />
      <MenubarCheckboxItem class="pl-2" @click="macCodeBlockChanged">
        <SquareCode class="mr-2 h-4 w-4" />
        {{ t('menu.macCodeBlock') }}
      </MenubarCheckboxItem>
      <MenubarSeparator />
      <MenubarCheckboxItem class="pl-2" divided @click="resetStyleConfirm">
        <RotateCcw class="mr-2 h-4 w-4" />
        {{ t('menu.reset') }}
      </MenubarCheckboxItem>
    </MenubarContent>
  </MenubarMenu>
</template>
