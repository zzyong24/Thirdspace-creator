<script setup lang="ts">
import type { Template } from '@md/shared'
import { Calendar, Clock, FileDown, FileInput, FileText, Package, Pencil, Plus, Search, Trash2 } from '@lucide/vue'
import { useConfirmStore } from '@/stores/confirm'
import { useEditorStore } from '@/stores/editor'
import { usePostStore } from '@/stores/post'
import { useTemplateStore } from '@/stores/template'
import { useUIStore } from '@/stores/ui'

const { t, locale } = useI18n()
const confirmStore = useConfirmStore()
const editorStore = useEditorStore()
const postStore = usePostStore()
const templateStore = useTemplateStore()
const uiStore = useUIStore()

const { toggleShowTemplateDialog } = uiStore

const searchKeyword = ref('')

const filteredTemplates = computed(() => {
  return templateStore.searchTemplates(searchKeyword.value)
})

const isShowForm = ref(false)
const formMode = ref<'create' | 'edit'>('create')
const editingTemplateId = ref<string>('')

const formData = reactive({
  name: '',
  description: '',
  content: '',
})

const formErrors = reactive({
  name: '',
})

function openCreateForm() {
  formMode.value = 'create'
  formData.name = ''
  formData.description = ''
  formData.content = editorStore.getContent()
  formErrors.name = ''
  isShowForm.value = true
}

function openEditForm(template: Template) {
  formMode.value = 'edit'
  editingTemplateId.value = template.id
  formData.name = template.name
  formData.description = template.description || ''
  formData.content = template.content
  formErrors.name = ''
  isShowForm.value = true
}

function validateForm(): boolean {
  formErrors.name = ''

  if (!formData.name.trim()) {
    formErrors.name = t('template.nameRequired')
    return false
  }

  if (formData.name.trim().length > 50) {
    formErrors.name = t('template.nameTooLong')
    return false
  }

  return true
}

function saveTemplate() {
  if (!validateForm())
    return

  if (formMode.value === 'create') {
    templateStore.createTemplate({
      name: formData.name.trim(),
      description: formData.description.trim() || undefined,
      content: formData.content,
    })
  }
  else {
    templateStore.updateTemplate(editingTemplateId.value, {
      name: formData.name.trim(),
      description: formData.description.trim() || undefined,
      content: formData.content,
    })
  }

  isShowForm.value = false
}

function cancelForm() {
  isShowForm.value = false
}

function applyTemplate(template: Template) {
  const currentPost = postStore.currentPost
  if (currentPost) {
    postStore.updatePostContent(currentPost.id, template.content)
    editorStore.importContent(template.content)
    toast.success(t('template.appliedToPost', { name: template.name }))
  }
  else {
    editorStore.importContent(template.content)
    toast.success(t('template.applied', { name: template.name }))
  }
  toggleShowTemplateDialog(false)
}

function insertTemplate(template: Template) {
  editorStore.insertAtCursor(template.content)

  const currentPost = postStore.currentPost
  if (currentPost) {
    postStore.updatePostContent(currentPost.id, editorStore.getContent())
  }

  toast.success(t('template.inserted', { name: template.name }))
  toggleShowTemplateDialog(false)
}

function openDeleteConfirm(template: Template) {
  confirmStore.confirm({
    title: t('template.confirmDelete'),
    description: t('confirm.deleteTemplate', { name: template.name }),
    onConfirm: () => { templateStore.deleteTemplate(template.id) },
  })
}

function formatDate(timestamp: number): string {
  const date = new Date(timestamp)
  return date.toLocaleString(locale.value, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function onUpdate(val: boolean) {
  if (!val) {
    toggleShowTemplateDialog(false)
    isShowForm.value = false
  }
}
</script>

<template>
  <Dialog :open="uiStore.isShowTemplateDialog" @update:open="onUpdate">
    <DialogContent class="max-w-4xl max-h-[85vh] flex flex-col p-0">
      <DialogHeader class="px-6 pt-6 pb-4 border-b">
        <DialogTitle class="flex items-center gap-2">
          <Package class="size-5" />
          {{ t('template.title') }}
        </DialogTitle>
        <DialogDescription>
          {{ t('template.description') }}
        </DialogDescription>
      </DialogHeader>

      <div class="flex-1 overflow-auto px-6 py-4">
        <div v-if="isShowForm" class="space-y-4 mb-6 p-4 border rounded-lg bg-muted/30">
          <div class="flex items-center justify-between">
            <h3 class="text-lg font-semibold">
              {{ formMode === 'create' ? t('template.create') : t('template.edit') }}
            </h3>
          </div>

          <div class="space-y-4">
            <div class="space-y-2">
              <Label for="template-name">{{ t('template.nameLabel') }}</Label>
              <Input
                id="template-name"
                v-model="formData.name"
                :placeholder="t('template.namePlaceholder')"
                :class="{ 'border-red-500': formErrors.name }"
              />
              <p v-if="formErrors.name" class="text-sm text-red-500">
                {{ formErrors.name }}
              </p>
            </div>

            <div class="space-y-2">
              <Label for="template-description">{{ t('template.descLabel') }}</Label>
              <Textarea
                id="template-description"
                v-model="formData.description"
                :placeholder="t('template.descPlaceholder')"
                class="resize-none h-20"
              />
            </div>

            <div class="space-y-2">
              <Label for="template-content">{{ t('template.contentLabel') }}</Label>
              <Textarea
                id="template-content"
                v-model="formData.content"
                :placeholder="t('template.contentPlaceholder')"
                class="resize-none h-40 font-mono text-sm"
              />
            </div>
          </div>

          <div class="flex gap-2 justify-end">
            <Button variant="outline" @click="cancelForm">
              {{ t('common.cancel') }}
            </Button>
            <Button @click="saveTemplate">
              {{ formMode === 'create' ? t('common.create') : t('common.save') }}
            </Button>
          </div>
        </div>

        <div v-if="!isShowForm" class="flex gap-2 mb-4">
          <div class="relative flex-1">
            <Search class="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              v-model="searchKeyword"
              :placeholder="t('template.searchPlaceholder')"
              class="pl-9"
            />
          </div>
          <Button @click="openCreateForm">
            <Plus class="mr-2 size-4" />
            {{ t('template.newTemplate') }}
          </Button>
        </div>

        <div v-if="!isShowForm" class="space-y-3">
          <div v-if="filteredTemplates.length === 0" class="text-center py-12">
            <Package class="mx-auto size-12 text-muted-foreground mb-4" />
            <p class="text-muted-foreground mb-2">
              {{ searchKeyword ? t('template.noMatch') : t('template.empty') }}
            </p>
            <p v-if="!searchKeyword" class="text-sm text-muted-foreground mb-4">
              {{ t('template.emptyHint') }}
            </p>
          </div>

          <div
            v-for="template in filteredTemplates"
            :key="template.id"
            class="border rounded-lg p-4 hover:bg-muted/50 transition-colors"
          >
            <div class="flex items-start justify-between gap-4">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-2">
                  <FileText class="size-4 text-muted-foreground flex-shrink-0" />
                  <h4 class="font-medium truncate">
                    {{ template.name }}
                  </h4>
                </div>

                <p v-if="template.description" class="text-sm text-muted-foreground mb-2 line-clamp-2">
                  {{ template.description }}
                </p>

                <div class="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                  <span class="flex items-center gap-1">
                    <Calendar class="size-3" />
                    {{ t('template.createdAt') }}{{ formatDate(template.createdAt) }}
                  </span>
                  <span class="flex items-center gap-1">
                    <Clock class="size-3" />
                    {{ t('template.updatedAt') }}{{ formatDate(template.updatedAt) }}
                  </span>
                </div>
              </div>

              <div class="flex gap-1 flex-shrink-0">
                <Button
                  variant="outline"
                  size="icon"
                  class="size-8"
                  :title="t('template.applyTitle')"
                  :aria-label="t('template.applyTitle')"
                  @click="applyTemplate(template)"
                >
                  <FileInput class="size-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  class="size-8"
                  :title="t('template.insertTitle')"
                  :aria-label="t('template.insertTitle')"
                  @click="insertTemplate(template)"
                >
                  <FileDown class="size-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  class="size-8"
                  :title="t('template.editTitle')"
                  :aria-label="t('template.editTitle')"
                  @click="openEditForm(template)"
                >
                  <Pencil class="size-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  class="size-8 text-destructive hover:text-destructive"
                  :title="t('template.deleteTitle')"
                  :aria-label="t('template.deleteTitle')"
                  @click="openDeleteConfirm(template)"
                >
                  <Trash2 class="size-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DialogContent>
  </Dialog>
</template>
