/** 单文档旧单例宿主的明确 lease。新实例只在旧实例完全关闭后取得写权。 */
export class NativeLease {
  private tail: Promise<void> = Promise.resolve()
  private active: (() => Promise<void>) | undefined
  async acquire(dispose: () => Promise<void>, signal?: AbortSignal): Promise<void> {
    const job=this.tail.then(async()=>{
      if(signal?.aborted)throw new Error('挂载已取消')
      if(this.active){const prior=this.active;this.active=undefined;await prior()}
      if(signal?.aborted)throw new Error('挂载已取消')
      this.active=dispose
    })
    this.tail=job.catch(()=>{})
    await job
  }
  release(dispose:()=>Promise<void>){if(this.active===dispose)this.active=undefined}
  async close(){await this.tail;const prior=this.active;this.active=undefined;await prior?.()}
}

export type NativeOwner={groupId:string|null;accountId:string|null;projectId:string;outputId:string;sourceVersionId:string};
export function nativeOwnerKey(owner:NativeOwner){return JSON.stringify([owner.groupId?['group',owner.groupId]:['account',owner.accountId],owner.projectId,owner.outputId,owner.sourceVersionId]);}
export function assertNativeOwner(owner:NativeOwner){if(!owner.projectId||!owner.outputId||!owner.sourceVersionId||(!owner.groupId&&!owner.accountId))throw new Error('稿件归属不完整');}

export function assertNativeRequestContext(expected:number,current:number,signal?:AbortSignal){if(signal?.aborted||expected!==current)throw new Error('稿件上下文已变化，原请求停止');}
