<script setup lang="ts">
import {nativePortal} from '@md/core/native-host'

import type { ContextMenuPortalProps } from 'reka-ui'
import { ContextMenuPortal } from 'reka-ui'

const props = defineProps<ContextMenuPortalProps>()
</script>

<template>
  <ContextMenuPortal v-bind="props" :to="nativePortal()">
    <slot />
  </ContextMenuPortal>
</template>
