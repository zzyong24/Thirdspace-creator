<script setup lang="ts">
import {defineAsyncComponent} from 'vue'
import EditorPanel from '@/components/editor/EditorPanel.vue'
import PreviewPanel from '@/components/editor/PreviewPanel.vue'
import NativeToolbar from './native-toolbar.vue'
import NativeMediaDialog from './native-media-dialog.vue'
import {useCursorSync} from '@/composables/useCursorSync'
import {useScrollSync} from '@/composables/useScrollSync'
import {useUIStore} from '@/stores/ui'
import {getNativeHost} from '@md/core/native-host'
import {Toaster} from '@/components/ui/sonner'
const CssEditor=defineAsyncComponent(()=>import('@/components/editor/CssEditor.vue'))
const RightSlider=defineAsyncComponent(()=>import('@/components/editor/RightSlider.vue'))
const TableEditDialog=defineAsyncComponent(()=>import('@/components/editor/dialogs/TableEditDialog.vue'))
const FormulaEditorDialog=defineAsyncComponent(()=>import('@/components/editor/dialogs/FormulaEditorDialog.vue'))
const TemplateDialog=defineAsyncComponent(()=>import('@/components/editor/dialogs/TemplateDialog.vue'))
const ConfirmDialog=defineAsyncComponent(()=>import('@/components/shared/confirm-dialog/ConfirmDialog.vue'))
const ui=useUIStore();const editor=ref<InstanceType<typeof EditorPanel>|null>(null);const preview=ref<InstanceType<typeof PreviewPanel>|null>(null)
const {handlePreviewContentClick}=useCursorSync(()=>editor.value?.codeMirrorView??null)
useScrollSync(()=>editor.value?.codeMirrorView??null,()=>preview.value?.previewRef??null,computed(()=>ui.enableScrollSync))
const host=getNativeHost()!
</script>
<template>
 <div class="creatoros-doocs-native" :class="{dark:ui.isDark}">
  <NativeToolbar/>
  <NativeMediaDialog :on-import="file=>editor?.uploadImage(file)"/>
  <div class="native-content" :class="{'native-edit-only':ui.viewMode==='edit','native-preview-only':ui.viewMode==='preview'}">
   <div class="native-editor-pane"><EditorPanel ref="editor"/></div>
   <div class="native-preview-pane"><PreviewPanel ref="preview" :back-light="false" :is-coping="false" :on-content-click="handlePreviewContentClick"/></div>
   <aside v-if="ui.isOpenRightSlider" class="native-style-pane"><RightSlider/></aside>
   <aside v-if="ui.isShowCssEditor" class="native-css-pane"><CssEditor/></aside>
  </div>
  <TableEditDialog v-if="ui.isShowTableEditDialog"/><FormulaEditorDialog v-if="ui.isShowFormulaEditorDialog"/><TemplateDialog v-if="ui.isShowTemplateDialog"/><ConfirmDialog/>
  <Teleport :to="host.portal"><Toaster rich-colors position="top-center" :duration="1800" :theme="ui.isDark?'dark':'light'"/></Teleport>
 </div>
</template>
