import {NativeRequestQueue} from './native-queue'
import {describe,it,expect} from 'vitest'
import {NativeLease,nativeOwnerKey,assertNativeOwner,assertNativeRequestContext} from './native-lease'
describe('Doocs 同文档原生 lease',()=>{
 it('下个实例要等旧 dispose 完成，并串行替换',async()=>{
  const lease=new NativeLease(); const log:string[]=[]; let close!:()=>void
  await lease.acquire(async()=>{log.push('a-close');await new Promise<void>(r=>{close=r});log.push('a-closed')})
  const acquired=lease.acquire(async()=>{log.push('b-close')}).then(()=>log.push('b'))
  await Promise.resolve();await Promise.resolve();expect(log).toEqual(['a-close']);close();await acquired
  expect(log).toEqual(['a-close','a-closed','b']);await lease.close();expect(log[log.length-1]).toBe('b-close')
 })
 it('被取消的等待挂载不取得新 lease',async()=>{
  const lease=new NativeLease();const cancel=new AbortController();cancel.abort()
  await expect(lease.acquire(async()=>{},cancel.signal)).rejects.toThrow('已取消')
 })
})

describe('T1062 公众号 owner/真实queue guard候选（不代替原DOM验证）',()=>{
 it('组归属可空account且平台切换key稳定，空根/错父/新原基点不伪装同一owner',()=>{const owner={groupId:'group-a',accountId:null,projectId:'project',outputId:'output',sourceVersionId:'original-version'};expect(()=>assertNativeOwner(owner)).not.toThrow();expect(nativeOwnerKey(owner)).toBe(nativeOwnerKey({...owner,accountId:'platform-account'}));expect(nativeOwnerKey(owner)).not.toBe(nativeOwnerKey({...owner,groupId:'group-b'}));expect(nativeOwnerKey(owner)).not.toBe(nativeOwnerKey({...owner,sourceVersionId:'new-version'}));expect(()=>assertNativeOwner({...owner,groupId:null,accountId:null})).toThrow('归属');expect(()=>assertNativeOwner({...owner,projectId:''})).toThrow('归属');});
 it('真实queue迟到操作由entry共用guard拒绝，取消后不执行旧snapshot读取',async()=>{const queue=new NativeRequestQueue();let release!:()=>void,epoch=1,reads=0;const first=queue.run(()=>new Promise<void>(resolve=>release=resolve));const issued=epoch;const stale=queue.run(async()=>{assertNativeRequestContext(issued,epoch);reads++;return 'snapshot'});const observed=stale.catch(error=>error);await Promise.resolve();epoch++;release();await first;expect(await observed).toBeInstanceOf(Error);expect(reads).toBe(0);const signal=new AbortController();signal.abort();await expect(queue.run(async()=>{assertNativeRequestContext(epoch,epoch,signal.signal);reads++;})).rejects.toThrow('上下文');expect(reads).toBe(0);await queue.settled();});
});
