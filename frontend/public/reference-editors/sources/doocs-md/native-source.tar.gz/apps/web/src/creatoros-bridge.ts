export {resolveNativeImages as resolveCreatorOSImages} from '@md/core/native-host'
/** 原生入口直接调用 handle，不接收 window 消息。 */
export function installCreatorOSBridge():void{}
