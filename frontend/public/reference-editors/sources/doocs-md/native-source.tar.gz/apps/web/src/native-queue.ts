/** 原模块单例请求串行执行，每次 await 后由操作检查实例与取消状态。 */
export class NativeRequestQueue {
  private tail: Promise<unknown> = Promise.resolve()
  run<T>(job: () => Promise<T>): Promise<T> {
    const next = this.tail.then(job)
    this.tail = next.catch(() => {})
    return next
  }
  async settled() { await this.tail }
}
