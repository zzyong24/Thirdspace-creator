export type NativeTheme = {
  mode: 'light' | 'dark'
  tokens: Record<string, string>
  fontFamily: string
  fontSize: string
  density: string
}
const aliases: Record<string, string> = {
  foreground: 'text', background: 'surface', card: 'surface', 'card-foreground': 'text',
  popover: 'surface', 'popover-foreground': 'text', border: 'border', input: 'border-strong',
  ring: 'brand', primary: 'brand', 'primary-foreground': 'brand-foreground', accent: 'brand-soft',
  'accent-foreground': 'text', secondary: 'surface-subtle', 'secondary-foreground': 'text',
  muted: 'surface-subtle', 'muted-foreground': 'text-muted', destructive: 'danger',
}
/** Both surfaces inherit hex colors directly; article styles are scoped to #output. */
export function applyNativeTheme(surfaces: HTMLElement[], theme: NativeTheme) {
  for (const surface of surfaces) {
    surface.classList.toggle('dark', theme.mode === 'dark')
    surface.setAttribute('data-density', theme.density)
    for (let i = surface.style.length - 1; i >= 0; i--) {
      const property = surface.style.item(i)
      if (property.startsWith('--creatoros-')) surface.style.removeProperty(property)
    }
    for (const [key, value] of Object.entries(theme.tokens)) {
      if (key.startsWith('--creatoros-')) surface.style.setProperty(key, value)
    }
    for (const [alias, token] of Object.entries(aliases)) {
      surface.style.setProperty(`--${alias}`, `var(--creatoros-${token}${alias === 'primary-foreground' ? ',#fff' : ''})`)
    }
    surface.style.setProperty('--radius', 'var(--creatoros-radius-control,8px)')
    surface.style.setProperty('--native-ui-font', theme.fontFamily)
    surface.style.setProperty('--native-ui-size', theme.fontSize)
    surface.style.color = 'var(--creatoros-text)'
    surface.style.fontFamily = theme.fontFamily
    surface.style.fontSize = theme.fontSize
  }
}
