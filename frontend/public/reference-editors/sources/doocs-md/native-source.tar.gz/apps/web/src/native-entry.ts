import {Compartment,StateEffect} from '@codemirror/state'
import {EditorView} from '@codemirror/view'
import { createApp, nextTick, watch, type App } from 'vue'
import { createPinia, setActivePinia, disposePinia } from 'pinia'
import { getNativeHost, setNativeHost, trackNativeJob, type NativeDomHost } from '@md/core/native-host'
import { resetThemeInjector } from '@md/core/theme'
import { initNativeStorage, documentRepo } from '@/storage'
import { setupI18n, setAppI18n } from '@/i18n'
import { usePostStore } from '@/stores/post'
import { useEditorStore } from '@/stores/editor'
import { useRenderStore } from '@/stores/render'
import { useThemeStore } from '@/stores/theme'
import { useCssEditorStore } from '@/stores/cssEditor'
import { useUIStore } from '@/stores/ui'
import { getHtmlContent } from '@/services/export/html-content'
import { getStylesToAdd, SHARE_SHELL_VARS_CSS } from '@/services/export/share-styles'
import { EXPORT_LAYOUT_CSS } from '@/services/export/apply-export-layout'
import {NativeLease,assertNativeOwner,assertNativeRequestContext,type NativeOwner} from './native-lease'
export {nativeOwnerKey} from './native-lease'
import { NativeRequestQueue } from './native-queue'
import { applyNativeTheme, type NativeTheme } from './native-theme'
import NativeApp from './NativeApp.vue'
import './assets/index.css'
import './assets/less/codemirror-global.less'
import './assets/less/theme.less'
import './native.css'

const COMMIT = 'a7c17fc4cda92e3c13aa7e24f06615cfa4219b31'
const lease = new NativeLease()
type Asset = { assetId: string; assetFileId: string; blob: Blob }
type NativeDocument = { title: string; markdown: string; layout?: any }
type Options = {
  owner: NativeOwner
  theme: NativeTheme
  portalContainer: HTMLElement
  signal: AbortSignal
  onChanged: (value: unknown) => void
  onError: (message: string) => void
  importMedia: (file: File) => Promise<{ mediaId: string }>
}
export async function mount(container: HTMLElement, options: Options) {
  if (options.signal.aborted) throw new Error('挂载已取消')
  if (!(container.getRootNode() instanceof ShadowRoot) || container.getRootNode() !== options.portalContainer.getRootNode()) {
    throw new Error('公众号编辑器需要同一组件样式容器')
  }
  assertNativeOwner(options.owner)
  for (const value of [options.owner?.projectId,options.owner?.outputId,options.owner?.sourceVersionId]) {
    if (typeof value !== 'string' || !value) throw new Error('稿件归属不完整')
  }
  const cancel = new AbortController()
  const queue = new NativeRequestQueue()
  let closed = false
  let app: App | undefined
  let pinia: ReturnType<typeof createPinia> | undefined
  let stopChanged: (() => void) | undefined
  let disposing: Promise<void> | undefined
  let loading = false
  let last = ''; let contextEpoch=0
  const host: NativeDomHost = {
    root: container, portal: options.portalContainer, signal: cancel.signal,
    mode: options.theme.mode, live: true, imageUrls: new Map(), imageBlobs: new Map(),
    jobs: new Set(), cleanups: new Set(),
    importMedia: async (file) => {
      check()
      if(!(file instanceof Blob)||!file.type.startsWith('image/')||file.size>25*1024*1024)throw new Error('图片文件无效或超过25 MiB')
      const result = await trackNativeJob(host, options.importMedia(file))
      check()
      if (!/^creatoros-asset:([^:\s]+):([^:\s]+)$/.test(result.mediaId)) throw new Error('素材归属回执无效')
      return result
    },
    onError: message => { if (!closed) options.onError(message) },
  }
  host.ready = new Promise<void>((resolve, reject) => { host.readyResolve = resolve; host.readyReject = reject })
  void host.ready.catch(() => {})
  function check(signal?: AbortSignal) {
    if (closed || cancel.signal.aborted || signal?.aborted) throw new Error('稿件已关闭或操作已取消')
  }
  function dispose(): Promise<void> {
    if (disposing) return disposing
    closed = true
    host.live = false
    cancel.abort()
    host.readyReject?.(new Error('稿件已关闭'))
    options.signal.removeEventListener('abort', abort)
    stopChanged?.()
    for (const cleanup of host.cleanups) { try { cleanup() } catch {} }
    host.cleanups.clear()
    app?.unmount()
    app = undefined
    if (pinia) {
      useEditorStore(pinia).editor?.destroy()
      useEditorStore(pinia).editor = null
      useCssEditorStore(pinia).cssEditor?.destroy()
      useCssEditorStore(pinia).cssEditor = null
      disposePinia(pinia)
    }
    disposing = (async () => {
      await Promise.allSettled([...host.jobs])
      await queue.settled()
      await documentRepo.whenIdle()
      if (getNativeHost() === host) { resetThemeInjector(); setNativeHost(undefined) }
      for (const url of host.imageUrls.values()) URL.revokeObjectURL(url)
      host.imageUrls.clear()
      host.imageBlobs.clear()
      container.replaceChildren()
      options.portalContainer.replaceChildren()
      for (const surface of [container, options.portalContainer]) {
        surface.removeAttribute('inert')
        surface.removeAttribute('aria-disabled')
      }
      lease.release(dispose)
    })()
    return disposing
  }
  const abort = () => { void dispose() }
  options.signal.addEventListener('abort', abort, { once: true })
  try {
    await lease.acquire(dispose, options.signal)
    check()
    setNativeHost(host)
    await initNativeStorage()
    check()
    const i18n = await setupI18n('zh-CN')
    check()
    setAppI18n(i18n)
    pinia = createPinia()
    setActivePinia(pinia)
    app = createApp(NativeApp)
    app.use(pinia)
    app.use(i18n)
    applyNativeTheme([container, options.portalContainer], options.theme)
    app.mount(container)
    let startupTimer: ReturnType<typeof setTimeout> | undefined
    try {
      await trackNativeJob(host, Promise.race([
        host.ready,
        new Promise<never>((_, reject) => { startupTimer = setTimeout(() => reject(new Error('公众号编辑器初始化超时')), 20000) }),
      ]))
      check()
    } finally { clearTimeout(startupTimer) }
    const post = usePostStore(pinia)
    const editor = useEditorStore(pinia)
    const render = useRenderStore(pinia)
    const theme = useThemeStore(pinia)
    const css = useCssEditorStore(pinia)
    post.replacePosts([{ id: options.owner.outputId, title: '', content: '', history: [], createDatetime: new Date(), updateDatetime: new Date() }])
    post.currentPostId = options.owner.outputId
    editor.importContent('')
    const layout = () => ({
      schemaVersion: 1, editor: 'doocs-md', editorCommit: COMMIT, themeId: String(theme.theme),
      themeSettings: JSON.parse(JSON.stringify(theme.themeSettings[theme.theme] ?? {})),
      customCss: css.getCurrentTabContent(),
      exportOptions: { useIndent: Boolean(theme.isUseIndent), useJustify: Boolean(theme.isUseJustify) },
    })
    const snapshot = () => ({ markdown: editor.getContent(), layout: layout() })
    function changed(documentChanged:boolean,selectedElements:unknown[]=[]){
      if(closed||loading)return;const state=snapshot();last=JSON.stringify(state);contextEpoch++;
      options.onChanged({...state,kind:'native-context',contextEpoch,outputId:options.owner.outputId,sceneId:null,selectedElements,documentChanged})
    }
    const view=editor.editor
    if(view){const contextExtension=new Compartment();view.dispatch({effects:StateEffect.appendConfig.of(contextExtension.of(EditorView.updateListener.of(update=>{
      if(update.docChanged||update.selectionSet)changed(update.docChanged,update.state.selection.ranges.map(range=>({from:range.from,to:range.to})))
    })))});host.cleanups.add(()=>{if(editor.editor===view)view.dispatch({effects:contextExtension.reconfigure([])})})}
    stopChanged = watch(
      () => [render.output, theme.theme, JSON.stringify(theme.themeSettings), css.getCurrentTabContent(), theme.isUseIndent, theme.isUseJustify],
      () => {
        if (closed || loading) return
        const state = snapshot()
        const encoded = JSON.stringify(state)
        if (encoded !== last) changed(true)
      }, { flush: 'sync' },
    )
    function register(image: Asset) {
      check()
      if (!image || typeof image.assetId!=='string' || typeof image.assetFileId!=='string' || !/^[^:\s]+$/.test(image.assetId) || !/^[^:\s]+$/.test(image.assetFileId)
        || !(image.blob instanceof Blob) || !image.blob.type.startsWith('image/') || image.blob.size > 25 * 1024 * 1024) {
        throw new Error('精确图片素材无效或超过25 MiB')
      }
      const key = `${image.assetId}:${image.assetFileId}`
      const prior = host.imageUrls.get(key)
      host.imageBlobs.set(key, image.blob)
      host.imageUrls.set(key, URL.createObjectURL(image.blob))
      if (prior) URL.revokeObjectURL(prior)
    }
    async function execute(operation: string, payload?: any, request?: { requestId?: string; signal?: AbortSignal }) {
      check(request?.signal)
      setActivePinia(pinia!)
      if (operation === 'load') {
        contextEpoch++
        const doc: NativeDocument = payload?.document ?? payload
        if (typeof doc?.markdown !== 'string') throw new Error('公众号稿件输入无效')
        const incoming = doc.layout
        if (incoming && incoming.editor !== 'doocs-md') throw new Error('版式属于其它编辑器')
        loading = true
        try {
          for (const image of payload?.assets ?? []) register(image)
          if (incoming) {
            if (incoming.themeId) theme.theme = incoming.themeId
            if (incoming.themeId && incoming.themeSettings) theme.themeSettings = { ...theme.themeSettings, [incoming.themeId]: incoming.themeSettings }
            if (typeof incoming.customCss === 'string') { const tab = css.getCurrentTab(); tab.content = incoming.customCss; css.setCssEditorValue(tab.content) }
            if (incoming.exportOptions) { theme.isUseIndent = !!incoming.exportOptions.useIndent; theme.isUseJustify = !!incoming.exportOptions.useJustify }
          }
          if (post.currentPost) post.currentPost.title = doc.title ?? ''
          editor.importContent(doc.markdown)
          editor.flushContentToPostStore()
          await theme.applyCurrentTheme()
          check(request?.signal)
          render.render(doc.markdown, { force: true })
          await nextTick()
          check(request?.signal)
          last = JSON.stringify(snapshot())
          return snapshot()
        } finally { loading = false }
      }
      if (operation === 'asset' || operation === 'insert-media') {
        register(payload)
        if (operation === 'insert-media') editor.insertAtCursor(`\n<img src="creatoros-asset:${payload.assetId}:${payload.assetFileId}" alt="图片">\n`)
        render.render(editor.getContent(), { force: true })
        await nextTick()
        check(request?.signal)
        return { mediaId: `creatoros-asset:${payload.assetId}:${payload.assetFileId}` }
      }
      if (operation === 'snapshot') { editor.flushContentToPostStore(); return snapshot() }
      if (operation === 'export-html') {
        const frozen = JSON.stringify(snapshot())
        await theme.applyCurrentTheme()
        check(request?.signal)
        render.render(editor.getContent(), { force: true, themeMode: 'light' })
        await nextTick()
        check(request?.signal)
        const styles = await getStylesToAdd()
        check(request?.signal)
        if (JSON.stringify(snapshot()) !== frozen) throw new Error('稿件已改变，请重新导出')
        const html = `<style>${SHARE_SHELL_VARS_CSS}</style>${styles}<style>${EXPORT_LAYOUT_CSS}</style><div id="output">${getHtmlContent({ staticLayout: true, themeMode: 'light' })}</div>`
        return { html, bindings: [...host.imageUrls].map(([key, url]) => ({ key, url })) }
      }
      throw new Error(`公众号编辑器不支持此操作：${operation}`)
    }
    return {
      async request(operation: string, payload?: unknown, request?: { requestId?: string; signal?: AbortSignal }) {
        const issuedEpoch=contextEpoch
        check(request?.signal)
        return trackNativeJob(host, queue.run(async()=>{
          check(request?.signal);assertNativeRequestContext(issuedEpoch,contextEpoch,request?.signal)
          const result=await execute(operation,payload,request);check(request?.signal)
          if((operation==='snapshot'||operation==='export-html')&&issuedEpoch!==contextEpoch)throw new Error('稿件上下文已变化，原结果停止')
          return result
        }))
      },
      update(value: { theme?: NativeTheme; disabled?: boolean }) {
        if (closed) return
        if (value.theme) { host.mode = value.theme.mode; applyNativeTheme([container, options.portalContainer], value.theme); useUIStore(pinia!).isDark = value.theme.mode === 'dark' }
        if (value.disabled !== undefined) {
          for (const surface of [container, options.portalContainer]) { surface.toggleAttribute('inert', value.disabled); surface.setAttribute('aria-disabled', String(value.disabled)) }
        }
      },
      dispose,
    }
  } catch (error) { await dispose(); throw error }
}

