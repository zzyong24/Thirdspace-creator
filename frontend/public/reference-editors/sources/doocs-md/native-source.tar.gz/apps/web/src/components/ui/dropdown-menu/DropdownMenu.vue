<script setup lang="ts">
import {isNativeHost} from '@md/core/native-host'
import type { DropdownMenuRootEmits, DropdownMenuRootProps } from 'reka-ui'
import { DropdownMenuRoot, useForwardPropsEmits } from 'reka-ui'

const props = defineProps<DropdownMenuRootProps>()
const emits = defineEmits<DropdownMenuRootEmits>()

const forwarded = useForwardPropsEmits(props, emits)
</script>

<template>
  <DropdownMenuRoot v-bind="forwarded" :modal="isNativeHost()?false:props.modal">
    <slot />
  </DropdownMenuRoot>
</template>
