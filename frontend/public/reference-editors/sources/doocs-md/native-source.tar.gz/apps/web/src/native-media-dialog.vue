<script setup lang="ts">
import {getNativeHost} from '@md/core/native-host'
import {useUIStore} from '@/stores/ui'
const props=defineProps<{onImport:(file:File)=>Promise<void>|undefined}>()
const ui=useUIStore()
const host=getNativeHost()!
const uploading=ref(false)
async function choose(event:Event){
 const input=event.target as HTMLInputElement
 const files=Array.from(input.files??[])
 input.value=''
 uploading.value=true
 try{for(const file of files){if(!host.live||host.signal.aborted)return;await props.onImport(file);if(!host.live||host.signal.aborted)return}ui.isShowUploadImgDialog=false}
 catch(error){host.onError(error instanceof Error?error.message:'图片导入失败')}
 finally{if(host.live&&!host.signal.aborted)uploading.value=false}
}
</script>
<template>
 <Dialog v-model:open="ui.isShowUploadImgDialog">
  <DialogContent>
   <DialogHeader><DialogTitle>插入图片</DialogTitle><DialogDescription>选择图片后会先保存到当前作品素材，再插入正文。</DialogDescription></DialogHeader>
   <input type="file" accept="image/*" multiple :disabled="uploading" aria-label="选择图片文件" @change="choose">
   <span v-if="uploading" role="status">图片正在保存到作品素材…</span>
  </DialogContent>
 </Dialog>
</template>
