<script setup lang="ts">
import type {EditorView} from '@codemirror/view'
import {undo,redo} from '@md/shared/editor'
import {useEditorStore} from '@/stores/editor'
import {useUIStore} from '@/stores/ui'
const editor=useEditorStore();const ui=useUIStore()
function wrap(prefix:string,suffix=prefix){const view=editor.editor;if(!view)return;const s=view.state.selection.main;view.dispatch(view.state.replaceSelection(`${prefix}${view.state.doc.sliceString(s.from,s.to)||'文字'}${suffix}`));view.focus()}
function command(action:'undo'|'redo'){if(editor.editor)(action==='undo'?undo:redo)(toRaw(editor.editor) as EditorView)}
</script>
<template>
 <div class="native-toolbar" aria-label="公众号正文编辑工具">
  <button type="button" @click="command('undo')">撤销</button><button type="button" @click="command('redo')">重做</button>
  <button type="button" @click="wrap('**')">加粗</button><button type="button" @click="wrap('*')">斜体</button><button type="button" @click="wrap('## ','')">标题</button><button type="button" @click="wrap('- ','')">列表</button><button type="button" @click="wrap('> ','')">引用</button>
  <select aria-label="编辑预览布局" :value="ui.viewMode" @change="ui.setViewMode(($event.target as HTMLSelectElement).value as 'edit'|'split'|'preview')"><option value="split">编辑与预览</option><option value="edit">只看正文</option><option value="preview">只看预览</option></select>
  <button type="button" @click="ui.isShowUploadImgDialog=true">插入图片</button>
  <button type="button" :aria-pressed="ui.isOpenRightSlider" @click="ui.isOpenRightSlider=!ui.isOpenRightSlider">排版设置</button>
  <button type="button" :aria-pressed="ui.isShowCssEditor" @click="ui.isShowCssEditor=!ui.isShowCssEditor">自定义 CSS</button>
 </div>
</template>
