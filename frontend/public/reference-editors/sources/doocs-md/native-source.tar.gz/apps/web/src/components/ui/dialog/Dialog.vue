<script setup lang="ts">
import type { DialogRootEmits, DialogRootProps } from 'reka-ui'
import { DialogRoot, useForwardPropsEmits } from 'reka-ui'
import {isNativeHost} from '@md/core/native-host'
import { useModalOpenFocusBlur } from '@/lib/a11y/dialog-focus'

const props = defineProps<DialogRootProps>()
const emits = defineEmits<DialogRootEmits>()

const forwarded = useForwardPropsEmits(props, emits)

useModalOpenFocusBlur(() => props.open)
</script>

<template>
  <DialogRoot v-bind="forwarded" :modal="isNativeHost()?false:props.modal">
    <slot />
  </DialogRoot>
</template>
