import {nativeById} from '@md/core/native-host'
import { dismissInitialLoader } from '@/lib/bootstrap/dismiss-initial-loader'
import { delay } from '@/lib/delay'
import { waitForPreviewReady } from '@/lib/preview/preview-ready'

const INITIAL_PREVIEW_TIMEOUT_MS = 20_000
const OUTPUT_WAIT_TIMEOUT_MS = 5_000
const OUTPUT_POLL_INTERVAL_MS = 50

let initialPreviewBootstrapped = false

/** Wait for PreviewPanel mount and #output in the DOM. */
async function waitForOutputElement(timeoutMs = OUTPUT_WAIT_TIMEOUT_MS) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const output = nativeById(`output`)
    if (output)
      return output
    await delay(OUTPUT_POLL_INTERVAL_MS)
  }
  return nativeById(`output`)
}

/** After first preview render, wait for async diagrams/math before dismissing loader. */
export async function completeInitialPreviewBoot() {
  if (initialPreviewBootstrapped)
    return
  initialPreviewBootstrapped = true

  await waitForOutputElement()
  await waitForPreviewReady(INITIAL_PREVIEW_TIMEOUT_MS)
  dismissInitialLoader()
}
