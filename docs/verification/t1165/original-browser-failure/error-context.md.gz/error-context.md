# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/t1159-wechat-native-report.spec.ts >> T1159 两微信账号从组成员进入真实0报告，刷新返回与身份拒绝
- Location: tests/e2e/t1159-wechat-native-report.spec.ts:22:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "SCOPE_MISSING"
Received: undefined
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - complementary "主侧栏" [ref=e3]:
      - generic [ref=e4]:
        - generic [ref=e5]:
          - img [ref=e7]
          - generic [ref=e10]: CreatorOS
        - button "收起侧栏" [ref=e11]:
          - img [ref=e12]
      - navigation "主要导航" [ref=e16]:
        - link "首页" [ref=e17] [cursor=pointer]:
          - /url: /
          - img [ref=e18]
          - generic [ref=e23]: 首页
        - link "创作者总览" [ref=e24] [cursor=pointer]:
          - /url: /overview
          - img [ref=e25]
          - generic [ref=e27]: 创作者总览
        - link "定位中心" [ref=e28] [cursor=pointer]:
          - /url: /positioning
          - img [ref=e29]
          - generic [ref=e31]: 定位中心
        - link "内容雷达" [ref=e32] [cursor=pointer]:
          - /url: /intelligence
          - img [ref=e33]
          - generic [ref=e40]: 内容雷达
        - link "选题" [ref=e41] [cursor=pointer]:
          - /url: /topics
          - img [ref=e42]
          - generic [ref=e45]: 选题
        - link "项目" [ref=e46] [cursor=pointer]:
          - /url: /projects
          - img [ref=e47]
          - generic [ref=e49]: 项目
        - link "知识库" [ref=e50] [cursor=pointer]:
          - /url: /knowledge
          - img [ref=e51]
          - generic [ref=e53]: 知识库
        - link "素材中心" [ref=e54] [cursor=pointer]:
          - /url: /assets
          - img [ref=e55]
          - generic [ref=e60]: 素材中心
        - link "创作画布" [ref=e61] [cursor=pointer]:
          - /url: /canvases
          - img [ref=e62]
          - generic [ref=e66]: 创作画布
        - link "发布中心" [ref=e67] [cursor=pointer]:
          - /url: /publishing
          - img [ref=e68]
          - generic [ref=e71]: 发布中心
        - link "运营分析" [ref=e72] [cursor=pointer]:
          - /url: /daily-report
          - img [ref=e73]
          - generic [ref=e75]: 运营分析
        - link "自动化" [ref=e76] [cursor=pointer]:
          - /url: /automations
          - img [ref=e77]
          - generic [ref=e81]: 自动化
        - link "设置" [ref=e82] [cursor=pointer]:
          - /url: /settings
          - img [ref=e83]
          - generic [ref=e86]: 设置
      - generic [ref=e87]:
        - generic [ref=e88]:
          - generic [ref=e89]:
            - img [ref=e91]
            - generic [ref=e94]: AI 助手
          - paragraph [ref=e95]: 创作者，今天想先做点什么？
          - link "打开 AI 助手" [ref=e96] [cursor=pointer]:
            - /url: "?copilot=open&scope=global"
        - button "帮助与反馈" [ref=e97]:
          - img [ref=e98]
          - generic [ref=e107]: 帮助与反馈
        - button "当前账号组：微信报表入口验收" [ref=e109] [cursor=pointer]:
          - img [ref=e111]
          - generic [ref=e115]:
            - generic [ref=e116]: 当前账号组
            - generic [ref=e117]: 微信报表入口验收
          - img [ref=e118]
        - generic [ref=e121]:
          - generic [ref=e123]: "?"
          - generic [ref=e125]: 创作者
          - generic [ref=e126]: 个人版
    - generic [ref=e127]:
      - banner:
        - generic:
          - generic: 平台作品
          - paragraph: 按账号查看已采集作品、目录完整性与真实指标
      - main [ref=e133]:
        - link "返回账号" [ref=e134] [cursor=pointer]:
          - /url: /accounts
        - generic [ref=e135]:
          - generic [ref=e136]:
            - heading "中性视频号账号的作品与数据" [level=1] [ref=e137]
            - paragraph [ref=e138]: 视频号 · 后台原生报表
            - paragraph [ref=e139]: 最近采集：尚未采集
          - button "同步数据" [ref=e140]
        - alert [ref=e141]:
          - paragraph [ref=e142]: 此账号需要重新完成平台身份核验
        - paragraph [ref=e143]: 尚无后台报表，可点击“同步数据”读取当前账号数据。
        - region "后台原生报表"
  - generic [ref=e148] [cursor=pointer]:
    - button "Open Next.js Dev Tools" [ref=e149]:
      - img [ref=e150]
    - generic [ref=e153]:
      - button "Open issues overlay" [ref=e154]:
        - generic [ref=e155]:
          - generic [ref=e156]: "0"
          - generic [ref=e157]: "1"
        - generic [ref=e158]: Issue
      - button "Collapse issues badge" [ref=e159]:
        - img [ref=e160]
  - alert [ref=e162]
```

# Test source

```ts
  1  | import type { BrowserContext, Page } from "@playwright/test";
  2  | import { mkdirSync, writeFileSync } from "node:fs";
  3  | import { resolve } from "node:path";
  4  | import type { AccountGroupResource, PlatformAccountResource } from "@creatoros/contract";
  5  | import { expect, test } from "../helpers/test-environment";
  6  | 
  7  | const output = resolve("../docs/verification/t1159");
  8  | const wait = { timeout: 120_000 };
  9  | const viewports = [{ width: 1366, height: 900 }, { width: 900, height: 900 }, { width: 390, height: 900 }];
  10 | async function dispatch<T>(page: Page, id: string, input: unknown, groupId?: string, accountId?: string): Promise<T> {
  11 |   const response = await page.request.post("/api/v1/dispatch", {
  12 |     ...wait, headers: { "content-type": "application/json", ...(groupId ? { "x-group-id": groupId } : {}), ...(accountId ? { "x-account-id": accountId } : {}) }, data: { id, input },
  13 |   });
  14 |   expect(response.ok(), `${id}: HTTP ${response.status()}`).toBe(true);
  15 |   return (await response.json()).data;
  16 | }
  17 | async function selectGroup(page: Page, context: BrowserContext, baseURL: string, groupId: string) {
  18 |   await context.addCookies([{ name: "creatoros_current_group", value: encodeURIComponent(groupId), url: baseURL }]);
  19 |   await page.addInitScript(id => { localStorage.setItem("creatoros:current-group", id); localStorage.removeItem("creatoros:current-account"); }, groupId);
  20 | }
  21 | 
  22 | test("T1159 两微信账号从组成员进入真实0报告，刷新返回与身份拒绝", async ({ page, context, baseURL }) => {
  23 |   test.setTimeout(1_500_000);
  24 |   page.setDefaultTimeout(120_000); page.setDefaultNavigationTimeout(120_000);
  25 |   mkdirSync(resolve(output, "screenshots"), { recursive: true });
  26 |   const group = await dispatch<AccountGroupResource>(page, "accountGroups.create", { body: { name: "微信报表入口验收", idempotencyKey: crypto.randomUUID() } });
  27 |   await dispatch<AccountGroupResource>(page, "accountGroups.create", { body: { name: "管理操作验收目标组", idempotencyKey: crypto.randomUUID() } });
  28 |   const accounts: PlatformAccountResource[] = [];
  29 |   for (const [platform, name] of [["wechatVideo", "中性视频号账号"], ["wechatOfficial", "中性公众号账号"]] as const) {
  30 |     const account = await dispatch<PlatformAccountResource>(page, "accounts.create", { body: { platform, accountHandle: name, idempotencyKey: crypto.randomUUID() } }, group.id);
  31 |     expect(account.externalAccountId).toBeNull(); accounts.push(account);
  32 |   }
  33 |   await selectGroup(page, context, baseURL!, group.id);
  34 |   const captures: { name: string; text: string; viewport: { width: number; height: number } | null; check_ids: string[] }[] = [];
  35 |   const observations: unknown[] = [];
  36 |   let bindingStarts = 0;
  37 |   page.on("request", request => {
  38 |     if (!request.url().endsWith("/api/v1/dispatch") || request.method() !== "POST") return;
  39 |     const id = request.postDataJSON()?.id;
  40 |     if (id === "accounts.bind.start" || id === "platforms.bind.begin") bindingStarts++;
  41 |   });
  42 |   for (const account of accounts) {
  43 |     const read = () => dispatch<{ items: unknown[]; total: number; nextCursor: string | null }>(page, "platforms.reports.list", { params: { accountId: account.id }, query: { pageSize: 20, cursor: null } }, group.id, account.id);
  44 |     const before = await read(); expect(before).toEqual({ items: [], total: 0, nextCursor: null });
  45 |     for (const viewport of viewports) {
  46 |       await page.setViewportSize(viewport); await page.goto("/accounts", wait);
  47 |       await expect(page.getByRole("heading", { name: "账号组与绑定账号", exact: true })).toBeVisible(wait);
  48 |       const link = page.getByRole("link", { name: `查看${account.accountHandle}的数据`, exact: true });
  49 |       await expect(link).toHaveAttribute("href", `/accounts/works?accountId=${encodeURIComponent(account.id)}`, wait);
  50 |       const member = link.locator("xpath=ancestor::li[1]");
  51 |       await member.locator("summary").click(wait);
  52 |       await expect(member.getByRole("button", { name: "隐藏", exact: true })).toBeVisible(wait);
  53 |       await member.getByRole("button", { name: "转组", exact: true }).click(wait);
  54 |       const dialog = page.getByRole("dialog"); await expect(dialog).toBeVisible(wait);
  55 |       await expect(dialog.getByRole("button", { name: "查看转组影响", exact: true })).toBeVisible(wait);
  56 |       await page.keyboard.press("Escape"); await expect(dialog).toBeHidden(wait);
  57 |       await link.click(wait);
  58 |       const panel = page.getByTestId("native-report-panel");
  59 |       await expect(panel).toHaveAttribute("data-account-id", account.id, wait);
  60 |       await expect(panel.getByRole("heading", { name: `${account.accountHandle}的作品与数据`, exact: true })).toBeVisible(wait);
  61 |       await expect(panel.getByText("尚无后台报表，可点击“同步数据”读取当前账号数据。", { exact: true })).toBeVisible(wait);
  62 |       await expect(panel.getByRole("button", { name: "同步数据", exact: true })).toBeEnabled(wait);
  63 |       const name = `${account.platform}-empty-${viewport.width}`;
  64 |       await page.screenshot({ path: resolve(output, "screenshots", `${name}.png`) });
  65 |       captures.push({ name, viewport, text: await panel.innerText(), check_ids: ["AC-REPORT-ENTRY", "AC-UI"] });
  66 |       await page.reload(wait); await expect(panel).toHaveAttribute("data-account-id", account.id, wait); expect(await read()).toEqual(before);
  67 |       await panel.getByRole("link", { name: "返回账号", exact: true }).click(wait); await expect(link).toBeVisible(wait);
  68 |     }
  69 |     // 公共start实际拒绝：不替换成功或失败响应，不开始扫码/采集/下载。
  70 |     await page.setViewportSize(viewports[0]!); await page.goto(`/accounts/works?accountId=${encodeURIComponent(account.id)}`, wait);
  71 |     const panel = page.getByTestId("native-report-panel");
  72 |     const responsePromise = page.waitForResponse(response => response.url().endsWith("/api/v1/dispatch") && response.request().postDataJSON()?.id === "platforms.collections.start", wait);
  73 |     await panel.getByRole("button", { name: "同步数据", exact: true }).click(wait);
  74 |     const response = await responsePromise; expect(response.status()).toBeGreaterThanOrEqual(400); expect(response.status()).toBeLessThan(500);
> 75 |     const failure = await response.json(); expect(failure.error.code).toBe("SCOPE_MISSING");
     |                                                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  76 |     await expect(panel.getByRole("alert")).toContainText("请先扫码绑定这个账号，再同步数据。", wait);
  77 |     await expect(panel.getByRole("button", { name: "扫码绑定账号", exact: true })).toBeVisible(wait);
  78 |     expect(await read()).toEqual(before);
  79 |     const name = `${account.platform}-identity-required`;
  80 |     await page.screenshot({ path: resolve(output, "screenshots", `${name}.png`) });
  81 |     captures.push({ name, viewport: page.viewportSize(), text: await panel.innerText(), check_ids: ["AC-REPORT-ENTRY", "AC-UI"] });
  82 |     await page.reload(wait); await expect(panel.getByRole("alert")).toContainText("请先扫码绑定这个账号，再同步数据。", wait); expect(await read()).toEqual(before);
  83 |     observations.push({ accountId: account.id, platform: account.platform, externalAccountId: account.externalAccountId, before, after: await read(), refusal: { httpStatus: response.status(), code: failure.error.code }, refresh: true, repeat: true, back: true });
  84 |   }
  85 |   expect(bindingStarts).toBe(0);
  86 |   writeFileSync(resolve(output, "public-read-observation.json"), JSON.stringify({ surface: "browser", mode: "non-fixture", witnesses: { groupId: group.id, accountIds: accounts.map(account => account.id) }, domainResponsesReplaced: false, manualAccountsIdentityVerified: false, realWechatCalled: false, bindingStarts, observations, captures }, null, 2) + "\n");
  87 | });
  88 | 
```